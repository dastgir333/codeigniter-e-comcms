  jQuery (function ($) {
	  $('.images a').click(function(event) {
		  event.preventDefault();
		  linkLocation = this.href;
		  stuffa = '<a class="image-popup-no-margins" href="';
		  stuffb = '">';
		  stuff1 = '<img src="';
		  stuff2 = '" width="150px" /></a>';
		  $("textarea").jqteVal($('textarea').val()+stuffa+linkLocation+stuffb+stuff1+linkLocation+stuff2);
	  });
  });
    $(document).ready(function(){
    $("#imagesButton").click(function(){
        $("#imagesBox").toggle(500);
    });
});