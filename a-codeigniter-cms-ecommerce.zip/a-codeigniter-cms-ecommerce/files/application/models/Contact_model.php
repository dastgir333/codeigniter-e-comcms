<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact_model extends CI_Model {
	
	public function get_records()
	{
		$this->db->select('content, title, slug'); 
		$query = $this->db->get_where('pages', array('slug' => 'contact'));
		return $query->result(); 
	}
	public function get_header()
	{
		$this->db->select('description, title, keywords'); 
		$query = $this->db->get_where('pages', array('slug' => 'contact'));
		return $query->result(); 
	}
	
    public function send($data4) 
	{
		$this->db->insert('msg', $data4);
		return;
	}
	public function get_capture()
	{
	    $this->db->order_by("id", "random"); 
		$this->db->select("one"); 
		$query = $this->db->get('capture', 1);
		return $query->result(); 
	}
	public function get_settings()
	{
		$query = $this->db->get_where('settings', array('id' => 1));
		return $query->result(); 

	}

}