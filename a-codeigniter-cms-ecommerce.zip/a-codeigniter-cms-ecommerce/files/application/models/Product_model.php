<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_model extends CI_Model {
	
	public function get_products()
	{
		//$this->db->select('content, title, videolink, slug');
		$query = $this->db->get_where('products', array('slug' => $this->uri->segment(2)));
		return $query->result(); 
	}
	public function get_productheader()
	{
		$this->db->select('description, title, keywords');
		$query = $this->db->get_where('products', array('slug' => $this->uri->segment(2)));
		return $query->result(); 
	}
	
	public function get_productcats()
	{
		$query = $this->db->get_where('productcategory', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_allproducts()
	{
		$this->db->select('name, slug');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}