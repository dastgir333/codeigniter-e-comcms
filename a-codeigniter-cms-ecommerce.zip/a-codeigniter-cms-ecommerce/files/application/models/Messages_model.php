<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages_model extends CI_Model {


	public function get_messages($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, email, message, date, status');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('msg', array('status' => '0'));
		return $query->result(); 
	}
	public function messages_count() {
	    $this->db->like('status', '0');
        $this->db->from('msg');
		return $this->db->count_all_results();
	}
	public function get_messagessaved($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, email, message, date, status');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('msg', array('status' => '2'));
		return $query->result(); 
	}
	public function messagessaved_count() {
	    $this->db->like('status', '2');
        $this->db->from('msg');
		return $this->db->count_all_results();
	}
	public function get_messagestrash($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, email, message, date, status');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('msg', array('status' => '1'));
		return $query->result(); 
	}
	public function messagestrash_count() {
	    $this->db->like('status', '1');
        $this->db->from('msg');
		return $this->db->count_all_results();
	}
	public function get_messagessent($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, email, message, date, status');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('msg', array('status' => '3'));
		return $query->result(); 
	}
	public function messagessent_count() {
	    $this->db->like('status', '3');
        $this->db->from('msg');
		return $this->db->count_all_results();
	}
	public function save_row()
	{
	$data = array(
               'status' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('msg', $data);
	}
	public function trash_row()
	{
	$data = array(
               'status' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('msg', $data);
	}
	public function restore_row()
	{
	$data = array(
               'status' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('msg', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('msg');
	}
	public function get_message()
	{
		$query = $this->db->get_where('msg', array('id' => $this->uri->segment(4)));
		return $query->result();
		
	}
	public function get_settingsemail()
	{
		$query = $this->db->get_where('settings', array('id' => 1));
		return $query->result(); 

	}
	public function send($messagedata) 
	{
		$this->db->insert('msg', $messagedata);
		return;
	}

}