<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shipping_model extends CI_Model {
	
	public function get_shippingrules()
	{
		$query = $this->db->get_where('shippingzones', array('status' => '0'));
		return $query->result();
	}
	public function get_shippingrulestrash()
	{
		$query = $this->db->get_where('shippingzones', array('status' => '1'));
		return $query->result();
	}
	public function get_shippingzone()
	{
		$query = $this->db->get_where('shippingzones', array('id' => $this->uri->segment(4)));
		return $query->result();
	}
	public function add_record($data) 
	{
		$this->db->insert('shippingzones', $data);
		return;
	}
	public function update_record($data)
	{
		$this->db->where('id', $data['id']);
		$this->db->update('shippingzones', $data);
	}
	public function trash_row()
	{
		$data = array(
               'status' => 1
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('shippingzones', $data);
	}
	public function restore_row()
	{
		$data = array(
               'status' => 0
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('shippingzones', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('shippingzones');
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}