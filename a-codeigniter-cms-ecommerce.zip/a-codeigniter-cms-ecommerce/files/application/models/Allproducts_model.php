<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Allproducts_model extends CI_Model {
	
	public function get_products($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}
	
	public function product_count() {
	        $this->db->like('trash', '0');
			$this->db->from('products');
			return $this->db->count_all_results();
	}
}