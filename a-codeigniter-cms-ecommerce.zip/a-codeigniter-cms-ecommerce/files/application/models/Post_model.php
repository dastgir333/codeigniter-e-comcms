<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Post_model extends CI_Model {
	

	public function get_posts()
	{
		$this->db->select('title, content, videolink, slug, comments');
		$query = $this->db->get_where('posts', array('slug' => $this->uri->segment(2)));
		return $query->result(); 
	}
	public function get_postcomments()
	{
	    $this->db->order_by('id', 'asc'); 
		$query = $this->db->get_where('comments', array('slug' => $this->uri->segment(2), 'moderate' => '2'));
		return $query->result(); 
	}
	public function get_postheader()
	{
		$this->db->select('title, description, keywords');
		$query = $this->db->get_where('posts', array('slug' => $this->uri->segment(2)));
		return $query->result(); 
	}
	public function get_capture()
	{
	    $this->db->order_by("id", "random"); 
		$this->db->select("one"); 
		$query = $this->db->get('capture', 1);
		return $query->result(); 
	}
	public function get_postcats()
	{
		$query = $this->db->get_where('postcategory', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_allposts()
	{
		$this->db->select('name, slug');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result(); 
	}
	public function save_comment($data)
	{
		$this->db->insert('comments', $data);
		return;
	}
}