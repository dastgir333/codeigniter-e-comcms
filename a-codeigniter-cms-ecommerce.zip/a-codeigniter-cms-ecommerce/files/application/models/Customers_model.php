<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customers_model extends CI_Model {

	public function get_subscribers($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$this->db->where('status', null);
		$query = $this->db->get('customers');
		return $query->result(); 
	}
	public function subscribers_count() {
		$this->db->like('status', null);
        $this->db->from('customers');
		return $this->db->count_all_results();
	}
	public function get_subscriberstrash($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$this->db->where('status', '1');
		$query = $this->db->get('customers');
		return $query->result(); 
	}
	public function subscriberstrash_count() {
		$this->db->like('status', '1');
        $this->db->from('customers');
		return $this->db->count_all_results();
	}
	public function get_subscriber()
	{
		$this->db->where('id', $this->uri->segment(4));
		$query = $this->db->get('customers');
		return $query->result(); 
	}
	public function get_subscriberinvoice()
	{
		$this->db->where('customerid', $this->uri->segment(4));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get('orders');
		return $query->result(); 
	}
	public function save_notes($data)
	{
		$this->db->where('id', $data['id']);
		$this->db->update('customers', $data);
	}
	public function get_subscriberslogs($per_page, $uri)
	{
		$this->db->where('customerid', $this->uri->segment(4));
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get('statslog');
		return $query->result(); 
	}
	public function subscribers_logcount() 
	{
		$this->db->like('customerid', $this->uri->segment(4));
        $this->db->from('statslog');
		return $this->db->count_all_results();
	}
	public function trash_row()
	{
	$data = array(
               'status' => '1'
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('customers', $data);
	}
	public function restore_row()
	{
	$data = array(
               'status' => null
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('customers', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('customers');
	}
}