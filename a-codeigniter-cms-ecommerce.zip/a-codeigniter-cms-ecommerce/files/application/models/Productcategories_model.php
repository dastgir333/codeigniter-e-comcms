<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Productcategories_model extends CI_Model {


	public function get_productcategories($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('productcategory', array('trash' => '0'));
		return $query->result(); 
	}
	public function productcategories_count() {
	    $this->db->like('trash', '0');
        $this->db->from('productcategory');
		return $this->db->count_all_results();
	}
	public function get_productcategoriesdrafts($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('productcategory', array('trash' => '2'));
		return $query->result(); 
	}
	public function productcategoriesdrafts_count() {
	    $this->db->like('trash', '2');
        $this->db->from('productcategory');
		return $this->db->count_all_results();
	}
	public function get_productcategoriestrash($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('productcategory', array('trash' => '1'));
		return $query->result(); 
	}
	public function productcategoriestrash_count() {
	    $this->db->like('trash', '1');
        $this->db->from('productcategory');
		return $this->db->count_all_results();
	}

	public function get_categoriesheader()
	{
		$category = $this->uri->segment(3);
		$this->db->select('description, title, keywords'); 
		$query = $this->db->get_where('productcategory', array('slug' => $category));
		return $query->result(); 
	}
	public function draft_row()
	{
	$data = array(
               'trash' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('productcategory', $data);
	}
	public function trash_row()
	{
	$data = array(
               'trash' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('productcategory', $data);
	}
	public function restore_row()
	{
	$data = array(
               'trash' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('productcategory', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('productcategory');
	}

}