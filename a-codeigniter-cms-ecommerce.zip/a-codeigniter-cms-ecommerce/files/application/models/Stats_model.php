<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stats_model extends CI_Model {
	
	public function get_statslogs($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$this->db->not_like('user_agent', 'bot');
		$this->db->not_like('user_agent', '-Bot/');
		$this->db->not_like('user_agent', 'crawler');
		$this->db->not_like('user_agent', 'Google Favicon');
		$this->db->not_like('user_agent', 'spider');
		$query = $this->db->get('statslog');
		return $query->result(); 
	}
	public function stats_logcount() 
	{
		$this->db->not_like('user_agent', 'bot');
		$this->db->not_like('user_agent', '-Bot/');
		$this->db->not_like('user_agent', 'crawler');
		$this->db->not_like('user_agent', 'Google Favicon');
		$this->db->not_like('user_agent', 'spider');
        $this->db->from('statslog');
		return $this->db->count_all_results();
	}
	
	public function get_statslogsall($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get('statslog');
		return $query->result(); 
	}
	public function stats_logcountall() 
	{
        $this->db->from('statslog');
		return $this->db->count_all_results();
	}
}