<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Discounts_model extends CI_Model {
	
	public function get_discountcodes()
	{
		$query = $this->db->get_where('discountcodes', array('status' => '0'));
		return $query->result();
	}
	public function get_discountcodestrash()
	{
		$query = $this->db->get_where('discountcodes', array('status' => '1'));
		return $query->result();
	}
	public function get_code()
	{
		$query = $this->db->get_where('discountcodes', array('id' => $this->uri->segment(4)));
		return $query->result();
	}
	public function add_record($data) 
	{
		$this->db->insert('discountcodes', $data);
		return;
	}
	public function update_record($data)
	{
		$this->db->where('id', $data['id']);
		$this->db->update('discountcodes', $data);
	}
	public function trash_row()
	{
		$data = array(
               'status' => 1
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('discountcodes', $data);
	}
	public function restore_row()
	{
		$data = array(
               'status' => 0
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('discountcodes', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('discountcodes');
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
	public function get_allcodes()
	{
		$this->db->select('code');
		$query = $this->db->get('discountcodes');
		return $query->result_array();
	}
	public function check_codes()
	{
		$this->db->select('code');
		$query = $this->db->get('discountcodes');
		return $query->result_array();
	}
	public function get_allcodes_edit($editid)
	{
		$this->db->select('code');
		$this->db->where('id !=', $editid);
		$query = $this->db->get('discountcodes');
		return $query->result_array();
	}
	public function check_codes_edit($editid)
	{
		$this->db->select('code');
		$this->db->where('id !=', $editid);
		$query = $this->db->get('discountcodes');
		return $query->result_array();
	}
}