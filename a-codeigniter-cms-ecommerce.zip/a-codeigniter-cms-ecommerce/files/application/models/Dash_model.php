<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dash_model extends CI_Model {
	
	public function get_posts()
	{
		$this->db->limit(5);
		$this->db->order_by('date', 'desc');
		$this->db->select('id, name, slug');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result();
	}
	public function get_products()
	{
		$this->db->limit(5);
		$this->db->order_by('date', 'desc');
		$this->db->select('id, name, slug');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result();
	}
	public function get_pages()
	{
		$this->db->limit(5);
		$this->db->select('id, name, slug');
		$query = $this->db->get_where('pages', array('trash' => '0'));
		return $query->result();
	}
	public function get_messages()
	{
		$this->db->limit(5);
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('msg', array('status' => '0'));
		return $query->result();
	}
	
}