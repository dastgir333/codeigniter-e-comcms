<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Recentposts_model extends CI_Model {
	
	public function get_posts($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result(); 
	}
	
	public function post_count() {
	        $this->db->like('trash', '0');
			$this->db->from('posts');
			return $this->db->count_all_results();
	}
}