<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkout_model extends CI_Model {
	
	public function get_details()
	{
		$query = $this->db->get_where('customers', array('id' => $this->session->userdata('customerid')));
		return $query->result();
	}
	
	public function get_emailsedit($userid)
	{
		$this->db->select('email');
		$this->db->where('id !=', $userid);
		$query = $this->db->get('customers');
		return $query->result_array();
	}
	public function get_timezone()
	{
		$this->db->select('timezone');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result();
	}
	public function get_siterecords()
	{
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result();
	}
	public function get_invoice($invoice)
	{
		$query = $this->db->get_where('orders', array('invoice' => $invoice));
		return $query->result();
	}
	public function update_user($data) 
	{
		$this->db->where('id', $data['id']);
		$this->db->update('customers', $data);
		return;
	}
	public function get_lastinvoice()
	{
		$this->db->limit(1, 0);
	    $this->db->order_by('id', 'desc'); 
		$query = $this->db->get('orders');
		return $query->result();
	}
	public function addorder($data)
	{
		$this->db->insert('orders', $data);
		return;
	}
	public function additemordered($productsordered)
	{
		$this->db->insert('orderedproducts', $productsordered);
		return;
	}
	public function updatepaid($invoice) 
	{
		$data = array(
               'paid' => 1
            );

		$this->db->where('invoice', $invoice);
		$this->db->update('orders', $data);
	}
	public function get_invoicenumber()
	{
		$query = $this->db->get_where('invoicenumber', array('id' => '1'));
		return $query->result();
	}
	public function get_invoiceprefix()
	{
		$query = $this->db->get_where('invoiceprefix', array('id' => '1'));
		return $query->result();	
	}
	public function update_invoicenumber($newnumber)
	{
		$data = array(
               'number' => $newnumber
            );

		$this->db->where('id', '1');
		$this->db->update('invoicenumber', $data);
	}
	public function check_discountcode($discountcode)
	{
		$query = $this->db->get_where('discountcodes', array('code' => $discountcode));
		return $query->result();
	}
	public function add_customercode($data) 
	{
		$this->db->insert('discountstemp', $data);
		return;
	}
	public function get_customercode($customerid)
	{
		$query = $this->db->get_where('discountstemp', array('customerid' => $customerid));
		return $query->result();
	}
	public function remove_code($customerid)
	{
		$this->db->where('customerid', $customerid);
		$this->db->delete('discountstemp');
	}
	public function get_code($code)
	{
		$query = $this->db->get_where('discountcodes', array('code' => $code));
		return $query->result();
	}
	public function update_uses($data, $code)
	{
		$this->db->where('code', $code);
		$this->db->update('discountcodes', $data);
	}
	public function getstocklevel($productid)
	{
		$this->db->select('id, name, stock');
		$this->db->where('id', $productid);
		$query = $this->db->get('products');
		return $query->result();
	}
	public function alterstocklevel($product)
	{
		$this->db->where('id', $product['id']);
		$this->db->update('products', $product);
	}
	public function getcountrycode()
	{
		$customerdetails = $this->get_details();
		foreach($customerdetails as $details){
			$country = strtolower($details->country);
		}
		if($country == 'united kingdom' or $country == 'england' or $country == 'scotland' or $country == 'wales'){
		$countrycode = 'GB';
		} elseif($country == 'united states' or $country == 'united states of america' or $country == 'usa'){
		$countrycode = 'US';
		} elseif($country == 'albania'){
		$countrycode = 'AL';
		} elseif($country == 'algeria'){
		$countrycode = 'DZ';
		} elseif($country == 'andorra'){
		$countrycode = 'AD';
		} elseif($country == 'angola'){
		$countrycode = 'AO';
		} elseif($country == 'anguilla'){
		$countrycode = 'AI';
		} elseif($country == 'antigua and barbuda'){
		$countrycode = 'AG';
		} elseif($country == 'antigua'){
		$countrycode = 'AG';
		} elseif($country == 'barbuda'){
		$countrycode = 'AG';
		} elseif($country == 'argentina'){
		$countrycode = 'AR';
		} elseif($country == 'armenia'){
		$countrycode = 'AM';
		} elseif($country == 'aruba'){
		$countrycode = 'AW';
		} elseif($country == 'australia'){
		$countrycode = 'AU';
		} elseif($country == 'austria'){
		$countrycode = 'AT';
		} elseif($country == 'azerbaijan'){
		$countrycode = 'AZ';
		} elseif($country == 'bahamas'){
		$countrycode = 'BS';
		} elseif($country == 'bahrain'){
		$countrycode = 'BH';
		} elseif($country == 'barbados'){
		$countrycode = 'BB';
		} elseif($country == 'belarus'){
		$countrycode = 'BY';
		} elseif($country == 'belgium'){
		$countrycode = 'BE';
		} elseif($country == 'belize'){
		$countrycode = 'BZ';
		} elseif($country == 'benin'){
		$countrycode = 'BJ';
		} elseif($country == 'bermuda'){
		$countrycode = 'BM';
		} elseif($country == 'bhutan'){
		$countrycode = 'BT';
		} elseif($country == 'bolivia'){
		$countrycode = 'BO';
		} elseif($country == 'bosnia'){
		$countrycode = 'BA';
		} elseif($country == 'herzegovinia'){
		$countrycode = 'BA';
		} elseif($country == 'botswana'){
		$countrycode = 'BW';
		} elseif($country == 'brazil'){
		$countrycode = 'BR';
		} elseif($country == 'british virgin islands'){
		$countrycode = 'VG';
		} elseif($country == 'brunei'){
		$countrycode = 'BN';
		} elseif($country == 'bulgaria'){
		$countrycode = 'BG';
		} elseif($country == 'burkina faso'){
		$countrycode = 'BF';
		} elseif($country == 'burundi'){
		$countrycode = 'BI';
		} elseif($country == 'cambodia'){
		$countrycode = 'KH';
		} elseif($country == 'cameroon'){
		$countrycode = 'CM';
		} elseif($country == 'canada'){
		$countrycode = 'CA';
		} elseif($country == 'cape verde'){
		$countrycode = 'CV';
		} elseif($country == 'cayman islands'){
		$countrycode = 'KY';
		} elseif($country == 'chad'){
		$countrycode = 'TD';
		} elseif($country == 'chile'){
		$countrycode = 'CL';
		} elseif($country == 'china'){
		$countrycode = 'C2';
		} elseif($country == 'colombia'){
		$countrycode = 'CO';
		} elseif($country == 'comoros'){
		$countrycode = 'KM';
		} elseif($country == 'congo brazzaville'){
		$countrycode = 'CG';
		} elseif($country == 'congo kinshasa'){
		$countrycode = 'CD';
		} elseif($country == 'cook islands'){
		$countrycode = 'CK';
		} elseif($country == 'costa rica'){
		$countrycode = 'CR';
		} elseif($country == 'croatia'){
		$countrycode = 'HR';
		} elseif($country == 'cyprus'){
		$countrycode = 'CY';
		} elseif($country == 'czech republic'){
		$countrycode = 'CZ';
		} elseif($country == 'denmark'){
		$countrycode = 'DK';
		} elseif($country == 'djibouti'){
		$countrycode = 'DJ';
		} elseif($country == 'dominica'){
		$countrycode = 'DM';
		} elseif($country == 'dominican republic'){
		$countrycode = 'DO';
		} elseif($country == 'ecuador'){
		$countrycode = 'EC';
		} elseif($country == 'egypt'){
		$countrycode = 'EG';
		} elseif($country == 'el salvador'){
		$countrycode = 'SV';
		} elseif($country == 'eritrea'){
		$countrycode = 'ER';
		} elseif($country == 'estonia'){
		$countrycode = 'EE';
		} elseif($country == 'ethiopia'){
		$countrycode = 'ET';
		} elseif($country == 'falkland islands'){
		$countrycode = 'FK';
		} elseif($country == 'faroe islands'){
		$countrycode = 'FO';
		} elseif($country == 'fiji'){
		$countrycode = 'FJ';
		} elseif($country == 'finland'){
		$countrycode = 'FI';
		} elseif($country == 'france'){
		$countrycode = 'FR';
		} elseif($country == 'french guiana'){
		$countrycode = 'GF';
		} elseif($country == 'french polynesia'){
		$countrycode = 'PF';
		} elseif($country == 'gabon'){
		$countrycode = 'GA';
		} elseif($country == 'gambia'){
		$countrycode = 'GM';
		} elseif($country == 'georgia'){
		$countrycode = 'GE';
		} elseif($country == 'germany'){
		$countrycode = 'DE';
		} elseif($country == 'gibraltar'){
		$countrycode = 'GI';
		} elseif($country == 'greece'){
		$countrycode = 'GR';
		} elseif($country == 'greenland'){
		$countrycode = 'GL';
		} elseif($country == 'grenada'){
		$countrycode = 'GD';
		} elseif($country == 'guadeloupe'){
		$countrycode = 'GP';
		} elseif($country == 'guatimala'){
		$countrycode = 'GT';
		} elseif($country == 'guinea'){
		$countrycode = 'GN';
		} elseif($country == 'guinea bissau'){
		$countrycode = 'GW';
		} elseif($country == 'guyana'){
		$countrycode = 'GY';
		} elseif($country == 'honduras'){
		$countrycode = 'HN';
		} elseif($country == 'hong kong'){
		$countrycode = 'HK';
		} elseif($country == 'hong kong sar china'){
		$countrycode = 'HK';
		} elseif($country == 'hungary'){
		$countrycode = 'HU';
		} elseif($country == 'iceland'){
		$countrycode = 'IS';
		} elseif($country == 'india'){
		$countrycode = 'IN';
		} elseif($country == 'indonesia'){
		$countrycode = 'ID';
		} elseif($country == 'ireland'){
		$countrycode = 'IE';
		} elseif($country == 'israel'){
		$countrycode = 'IL';
		} elseif($country == 'italy'){
		$countrycode = 'IT';
		} elseif($country == 'jamaica'){
		$countrycode = 'JM';
		} elseif($country == 'japan'){
		$countrycode = 'JP';
		} elseif($country == 'jordan'){
		$countrycode = 'JO';
		} elseif($country == 'kazakhstan'){
		$countrycode = 'KZ';
		} elseif($country == 'kenya'){
		$countrycode = 'KE';
		} elseif($country == 'kiribati'){
		$countrycode = 'KI';
		} elseif($country == 'kuwait'){
		$countrycode = 'KW';
		} elseif($country == 'kyrgystan'){
		$countrycode = 'KG';
		} elseif($country == 'laos'){
		$countrycode = 'LA';
		} elseif($country == 'latvia'){
		$countrycode = 'LV';
		} elseif($country == 'lesotho'){
		$countrycode = 'LS';
		} elseif($country == 'liechtenstein'){
		$countrycode = 'LI';
		} elseif($country == 'lithuania'){
		$countrycode = 'LT';
		} elseif($country == 'luxembourg'){
		$countrycode = 'LU';
		} elseif($country == 'macedonia'){
		$countrycode = 'MK';
		} elseif($country == 'madagascar'){
		$countrycode = 'MG';
		} elseif($country == 'malawi'){
		$countrycode = 'MW';
		} elseif($country == 'malaysia'){
		$countrycode = 'MY';
		} elseif($country == 'maldives'){
		$countrycode = 'MV';
		} elseif($country == 'mali'){
		$countrycode = 'ML';
		} elseif($country == 'malta'){
		$countrycode = 'MT';
		} elseif($country == 'marshall islands'){
		$countrycode = 'MH';
		} elseif($country == 'martinique'){
		$countrycode = 'MQ';
		} elseif($country == 'mauritania'){
		$countrycode = 'MR';
		} elseif($country == 'mauritius'){
		$countrycode = 'MU';
		} elseif($country == 'mayotte'){
		$countrycode = 'YT';
		} elseif($country == 'mexico'){
		$countrycode = 'MX';
		} elseif($country == 'micronesia'){
		$countrycode = 'FM';
		} elseif($country == 'moldova'){
		$countrycode = 'MD';
		} elseif($country == 'monaco'){
		$countrycode = 'MC';
		} elseif($country == 'mongolia'){
		$countrycode = 'MN';
		} elseif($country == 'montenegro'){
		$countrycode = 'ME';
		} elseif($country == 'montserrat'){
		$countrycode = 'MS';
		} elseif($country == 'morocco'){
		$countrycode = 'MA';
		} elseif($country == 'mozambique'){
		$countrycode = 'MZ';
		} elseif($country == 'namibia'){
		$countrycode = 'NA';
		} elseif($country == 'nauru'){
		$countrycode = 'NR';
		} elseif($country == 'nepal'){
		$countrycode = 'NP';
		} elseif($country == 'netherlands'){
		$countrycode = 'NL';
		} elseif($country == 'new caledonia'){
		$countrycode = 'NC';
		} elseif($country == 'new zealand'){
		$countrycode = 'NZ';
		} elseif($country == 'nicaragua'){
		$countrycode = 'NI';
		} elseif($country == 'niger'){
		$countrycode = 'NE';
		} elseif($country == 'nigeria'){
		$countrycode = 'NG';
		} elseif($country == 'niue'){
		$countrycode = 'NU';
		} elseif($country == 'norfolk island'){
		$countrycode = 'NF';
		} elseif($country == 'norway'){
		$countrycode = 'NO';
		} elseif($country == 'oman'){
		$countrycode = 'OM';
		} elseif($country == 'palau'){
		$countrycode = 'PW';
		} elseif($country == 'panama'){
		$countrycode = 'PA';
		} elseif($country == 'panpua new guinea'){
		$countrycode = 'PG';
		} elseif($country == 'paraguay'){
		$countrycode = 'PY';
		} elseif($country == 'peru'){
		$countrycode = 'PE';
		} elseif($country == 'philippines'){
		$countrycode = 'PH';
		} elseif($country == 'pitcairn islands'){
		$countrycode = 'PN';
		} elseif($country == 'poland'){
		$countrycode = 'PL';
		} elseif($country == 'portugal'){
		$countrycode = 'PT';
		} elseif($country == 'qatar'){
		$countrycode = 'QA';
		} elseif($country == 'reunion'){
		$countrycode = 'RE';
		} elseif($country == 'romania'){
		$countrycode = 'RO';
		} elseif($country == 'russia'){
		$countrycode = 'RU';
		} elseif($country == 'rwanda'){
		$countrycode = 'RW';
		} elseif($country == 'samoa'){
		$countrycode = 'WS';
		} elseif($country == 'san marino'){
		$countrycode = 'SM';
		} elseif($country == 'saudi arabia'){
		$countrycode = 'SA';
		} elseif($country == 'senegal'){
		$countrycode = 'SN';
		} elseif($country == 'serbia'){
		$countrycode = 'RS';
		} elseif($country == 'seychelles'){
		$countrycode = 'SH';
		} elseif($country == 'sierra leone'){
		$countrycode = 'SL';
		} elseif($country == 'singapore'){
		$countrycode = 'SG';
		} elseif($country == 'slovakia'){
		$countrycode = 'SK';
		} elseif($country == 'slovenia'){
		$countrycode = 'SI';
		} elseif($country == 'solomon islands'){
		$countrycode = 'SB';
		} elseif($country == 'somalia'){
		$countrycode = 'SO';
		} elseif($country == 'south africa'){
		$countrycode = 'ZA';
		} elseif($country == 'south korea'){
		$countrycode = 'KR';
		} elseif($country == 'spain'){
		$countrycode = 'ES';
		} elseif($country == 'sri lanka'){
		$countrycode = 'LK';
		} elseif($country == 'st. helena' or $country == 'st helena'){
		$countrycode = 'SH';
		} elseif($country == 'st. kitts and nevis' or $country == 'st kitts and nevis'){
		$countrycode = 'KN';
		} elseif($country == 'st. lucia' or $country == 'st lucia'){
		$countrycode = 'LC';
		} elseif($country == 'st. pierre and miquelon' or $country == 'st pierre and miquelon'){
		$countrycode = 'PM';
		} elseif($country == 'st. vincent and grenadines' or $country == 'st vincent and grenadines'){
		$countrycode = 'VC';
		} elseif($country == 'suriname'){
		$countrycode = 'SR';
		} elseif($country == 'svalbard and jan mayen'){
		$countrycode = 'SJ';
		} elseif($country == 'swaziland'){
		$countrycode = 'SZ';
		} elseif($country == 'sweden'){
		$countrycode = 'SE';
		} elseif($country == 'switzerland'){
		$countrycode = 'CH';
		} elseif($country == 'taiwan'){
		$countrycode = 'TW';
		} elseif($country == 'tajikistan'){
		$countrycode = 'TJ';
		} elseif($country == 'tanzania'){
		$countrycode = 'TZ';
		} elseif($country == 'thailand'){
		$countrycode = 'TH';
		} elseif($country == 'togo'){
		$countrycode = 'TG';
		} elseif($country == 'tonga'){
		$countrycode = 'TO';
		} elseif($country == 'trinidad and tobago'){
		$countrycode = 'TT';
		} elseif($country == 'tunisia'){
		$countrycode = 'TN';
		} elseif($country == 'turkmenistan'){
		$countrycode = 'TM';
		} elseif($country == 'turks and caicos islands'){
		$countrycode = 'TC';
		} elseif($country == 'tuvalu'){
		$countrycode = 'TV';
		} elseif($country == 'uganda'){
		$countrycode = 'UG';
		} elseif($country == 'ukraine'){
		$countrycode = 'UA';
		} elseif($country == 'united arab emirates'){
		$countrycode = 'AE';
		} elseif($country == 'uruguay'){
		$countrycode = 'UY';
		} elseif($country == 'vanuatu'){
		$countrycode = 'VU';
		} elseif($country == 'vatican city'){
		$countrycode = 'VA';
		} elseif($country == 'venezuela'){
		$countrycode = 'VE';
		} elseif($country == 'vietnam'){
		$countrycode = 'VN';
		} elseif($country == 'wallis and futuna'){
		$countrycode = 'WF';
		} elseif($country == 'yemen'){
		$countrycode = 'YE';
		} elseif($country == 'zambia'){
		$countrycode = 'ZM';
		} elseif($country == 'zimbabwe'){
		$countrycode = 'ZW';
		} else {
			$countrycode = $country;
		}
		return $countrycode;
	}
}