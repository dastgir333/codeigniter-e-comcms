<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account_model extends CI_Model {
	
	public function get_invoices($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('orders', array('customerid' => $this->session->userdata('customerid')));
		return $query->result(); 
	}
	public function invoices_count() 
	{
	    $this->db->like('customerid', $this->session->userdata('customerid'));
		$this->db->from('orders');
		return $this->db->count_all_results();
	}
	public function get_downloads($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$this->db->where('customerid', $this->session->userdata('customerid'));
		$this->db->where('download !=', '');
		$this->db->where('download !=', 'none');
		$query = $this->db->get('orderedproducts');
		return $query->result(); 
	}
	
	public function downloads_count() 
	{
		$this->db->where('customerid', $this->session->userdata('customerid'));
		$this->db->where('download !=', '');
		$this->db->where('download !=', 'none');
		$query = $this->db->get('orderedproducts');
		return $this->db->count_all_results();
	}
	public function get_singleinvoice()
	{
		$query = $this->db->get_where('orders', array(
				'id' => $this->uri->segment(3), 
				'customerid' => $this->session->userdata('customerid')
			));
		return $query->result(); 
	}
	public function get_orderedproducts($invoicenumber)
	{
		$query = $this->db->get_where('orderedproducts', array(
				'invoice' => $invoicenumber
			));
		return $query->result(); 
	}
	
}