<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editpage_model extends CI_Model {
	
	
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	public function get_page()
	{
		$query = $this->db->get_where('pages', array('id' => $this->uri->segment(4)));
		return $query->result();
		
	}
	public function update_record($data2) 
	{
		$this->db->where('id', $data2['id']);
		$this->db->update('pages', $data2);
	}
}