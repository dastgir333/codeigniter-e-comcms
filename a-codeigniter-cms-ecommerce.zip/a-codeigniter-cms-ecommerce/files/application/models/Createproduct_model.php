<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createproduct_model extends CI_Model {

	public function add_record($data) 
	{
		$this->db->insert('products', $data);
		return;
	}
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	public function get_slugnames()
	{
		$this->db->select('slug');
		$query = $this->db->get('products');
		return $query->result_array();
	}
	public function get_productnames()
	{
		$this->db->select('name');
		$query = $this->db->get('products');
		return $query->result_array();
	}
	public function get_productscategory()
	{
	    $this->db->order_by("sort", "asc");
	    $query = $this->db->get_where('productcategory', array('trash' => 0));
		return $query->result(); 
	}
	public function get_downloads() 
	{
		$query = $this->db->get_where('downloads', array('trash' => '0'));
		return $query->result();
	}
	public function get_shippingtype() 
	{
		$query = $this->db->get_where('shippingzones', array('zone' => '1'));
		return $query->result();
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}