<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createpost_model extends CI_Model {

	public function add_record($data) 
	{
		$this->db->insert('posts', $data);
		return;
	}
	public function get_settings()
	{
		$query = $this->db->get_where('settings', array('id' => 1));
		return $query->result(); 

	}
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	
	public function get_slugnames()
	{
		$this->db->select('slug');
		$query = $this->db->get('posts');
		return $query->result_array();
	}
	public function get_postnames()
	{
		$this->db->select('name');
		$query = $this->db->get('posts');
		return $query->result_array();
	}
	public function get_postscategory()
	{
	    $this->db->order_by("sort", "asc");
	    $query = $this->db->get_where('postcategory', array('trash' => 0));
		return $query->result(); 
	}
}