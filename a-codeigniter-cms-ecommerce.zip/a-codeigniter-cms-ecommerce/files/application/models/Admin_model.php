<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model {

	public function check()
	{
		$clean = $this->security->xss_clean($this->input->post('password'));
		$pass = hash('sha256', $clean);
		$email = $this->security->xss_clean($this->input->post('email'));
		$this->db->where('email', $email);
		$this->db->where('password', $pass);
		$query = $this->db->get('admin');
		return $query->result();
	}
}