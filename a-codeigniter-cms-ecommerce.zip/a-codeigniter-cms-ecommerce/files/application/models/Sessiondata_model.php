<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sessiondata_model extends CI_Model {
	
	public function delete_data()
	{
		$this->db->empty_table('ci_sessions');
	}
	
}