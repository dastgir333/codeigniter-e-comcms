<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model {
	
	public function check()
	{
		$pass1 = $this->input->post('password');
		$pass = hash('sha256', $pass1);
		$email = $this->input->post('email');
		$this->db->where('email', $email);
		$this->db->where('password', $pass);
		$query = $this->db->get('customers');
		return $query->result();
	}
	public function remove_code($userid)
	{
		$this->db->where('customerid', $userid);
		$this->db->delete('discountstemp');
	}
	public function get_emails()
	{
		$this->db->select('email');
		$query = $this->db->get('customers');
		return $query->result_array();
	}
	
	public function create_user($data) 
	{
		$this->db->insert('customers', $data);
		return;
	}
	
	public function check_user($email)
	{
		$this->db->where('email', $email);
		$query = $this->db->get('customers');
		return $query->result();
	}
	public function get_countries()
	{
		$this->db->select('country');
		$this->db->where('status', '0');
		$query = $this->db->get('shippingzones');
		return $query->result();
	}
}