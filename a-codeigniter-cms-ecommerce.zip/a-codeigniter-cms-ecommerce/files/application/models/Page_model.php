<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_model extends CI_Model {


	function get_pagedata()
	{
		$this->db->select('content, title, videolink');
		$this->db->where('id =', '1');
		$query = $this->db->get('pages');
		return $query->result(); 
	}
	function get_pageheader()
	{
		$this->db->select('description, title, keywords');
		$this->db->where('id =', '1');
		$query = $this->db->get('pages');
		return $query->result(); 
	}
	function get_sitetitle()
	{
		$this->db->select('title');
		$this->db->where('id =', '1');
		$query = $this->db->get('settings');
		return $query->result(); 
	}
	public function get_pages()
    {
		$this->db->select('content, title, videolink, slug');
		$query = $this->db->get_where('pages', array('slug' => $this->uri->segment(1)));
		return $query->result(); 
	}
		public function get_header()
    {
		$this->db->select('description, title, keywords');
		$query = $this->db->get_where('pages', array('slug' => $this->uri->segment(1)));
		return $query->result(); 
	}
	public function get_allpages()
	{
		$this->db->select('name, slug');
		$query = $this->db->get_where('pages', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_mpm_sliderposts()
    {
		$this->db->limit(3);
		$this->db->order_by('date', 'desc');
		$this->db->select('content, title, description, slug');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_mpm_sliderproducts()
    {
		$this->db->limit(3);
		$this->db->order_by('date', 'desc');
		$this->db->select('content, title, description, price, slug');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_slideroption()
	{
		$query = $this->db->get('slideroption');
		return $query->result(); 
	}
	public function get_mpm_slidercustom()
    {
		$this->db->limit(3);
		$this->db->order_by('id', 'asc');
		$query = $this->db->get('slider');
		return $query->result(); 
	}
	public function get_mpm_post()
    {
		$this->db->limit(1);
		$this->db->order_by('date', 'desc');
		$this->db->select('content, description, title, slug');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_mpm_product()
    {
		$this->db->limit(1);
		$this->db->order_by('date', 'desc');
		$this->db->select('content, description, title, slug');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}
	public function get_mpm_product2()
    {
		$this->db->limit(1);
		$this->db->order_by('id', 'RANDOM');
		$this->db->select('content, description, title, slug');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}

}