<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Downloadfiles_model extends CI_Model {
	
	public function __construct()
	{
		parent::__construct();
		$thing = BASEPATH;
		$replace = 'downloads';
		$remove = 'system';
		$new = str_replace($remove, $replace, $thing);
		$this->downloads_path = $new;
	}
	
	public function do_upload(){
	
	   $config = array (
	    'allowed_types' => 'zip',
		'upload_path' => $this->downloads_path,
		'max_size' => 500000,
	    );
	   
	   $this->load->library('upload', $config);
	   $this->upload->do_upload();
	   $filedata = $this->upload->data();
	   $this->upload->initialize($config); 
	   
	   $data = array (
	   'file' => $filedata['file_name'],
	   'trash' => '0'
	   );
		$this->db->insert('downloads', $data);
		return;
	}
	public function get_downloads()
	{
		$query = $this->db->get_where('downloads', array('trash' => '0'));
		return $query->result();
	}
	public function get_downloadstrash()
	{
		$query = $this->db->get_where('downloads', array('trash' => '1'));
		return $query->result();
	}
	public function trash_row()
	{
		$data = array(
               'trash' => 1
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('downloads', $data);
	}
	public function restore_row()
	{
		$data = array(
               'trash' => 0
            );
		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('downloads', $data);
	}
	public function delete_row()
	{
		$this->db->where('file', $this->uri->segment(4));
		$this->db->delete('downloads');
		unlink($this->downloads_path . '/' . $this->uri->segment(4));
	}
}