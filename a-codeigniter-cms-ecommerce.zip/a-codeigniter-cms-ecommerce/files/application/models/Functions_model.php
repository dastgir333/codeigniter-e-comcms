<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Functions_model extends CI_Model {
	
	function get_template()
	{
		$this->db->where('id =', '1');
		$query = $this->db->get('active_template');
		return $query->result(); 
	}
	function get_sitestatus()
	{
		$this->db->select('status');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
	public function get_logo()
	{
		$this->db->where('id =', '1');
		$query = $this->db->get('logo');
		return $query->result(); 
	}
	function get_menu()
	{
		$this->db->select('name, slug');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->where('trash', '0');
		$query = $this->db->where('sort !=', '0');
		$query = $this->db->get('pages');
		return $query->result(); 
	}
	function get_postmenu()
	{
		$this->db->select('name, slug');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->where('trash', '0');
		$query = $this->db->where('sub', 'none');
		$query = $this->db->get('postcategory');
		return $query->result(); 
	}
	function get_productmenu()
	{
		$this->db->select('name, slug');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->where('trash', '0');
		$query = $this->db->where('sub', 'none');
		$query = $this->db->get('productcategory');
		return $query->result(); 
	}
	function get_menustatus()
	{
		$query = $this->db->get_where('menu', array('status' => '1'));
		return $query->result(); 
	}
	function get_postmenufooter()
	{
		$this->db->select('name, slug');
		$query = $this->db->where('trash', '0');
		$query = $this->db->where('sub', 'none');
		$query = $this->db->get('postcategory');
		return $query->result(); 
	}
	function get_postmenufooterlinks()
	{
		$this->db->order_by('date', 'desc');
		$this->db->limit(5);
		$this->db->select('name, slug');
		$query = $this->db->get_where('posts', array('trash' => '0'));
		return $query->result(); 
	}
	public function set_log($logdata) 
	{
		$this->db->insert('statslog', $logdata);
		return;
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}
