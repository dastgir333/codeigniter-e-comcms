<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editpostcat_model extends CI_Model {
	
	
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	public function get_postcat()
	{
		$query = $this->db->get_where('postcategory', array('id' => $this->uri->segment(4)));
		return $query->result();
		
	}
	public function update_record($data2) 
	{
		$this->db->where('id', $data2['id']);
		$this->db->update('postcategory', $data2);
	}
	public function get_categories()
	{
		$this->db->order_by("sort", "asc");
		$query = $this->db->get_where('postcategory', array('trash' => 0));
		return $query->result(); 
	}
}