<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cart_model extends CI_Model {
	
	public function get_shippingrules($courier, $country, $finalcode)
	{
		$this->db->like('postcodes', $finalcode, 'both'); 
		$query = $this->db->get_where('shippingzones', array('name' => $courier, 'country' => $country, 'status' => '0'));
		return $query->result();
	}
	public function get_shippingruleszoneone($courier, $country)
	{
		$query = $this->db->get_where('shippingzones', array('name' => $courier, 'country' => $country, 'postcodes' => 'all others', 'status' => '0'));
		return $query->result();
	}
	public function get_shippingrulesbasic($courier)
	{
		$query = $this->db->get_where('shippingzones', array('name' => $courier, 'status' => '0', 'zone' => '1'));
		return $query->result();
	}
	public function get_customeraddress($customerid)
	{
		$query = $this->db->get_where('customers', array('id' => $customerid));
		return $query->result();
	}
	public function get_itemcountry($couriercheck)
	{
		$this->db->select('country');
		$query = $this->db->get_where('shippingzones', array('name' => $couriercheck, 'status' => '0'));
		return $query->result_array();
	}
}