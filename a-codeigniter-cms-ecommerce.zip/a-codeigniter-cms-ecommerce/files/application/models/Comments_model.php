<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Comments_model extends CI_Model {

	public function get_waiting($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('comments', array('moderate' => '0'));
		return $query->result(); 
	}
	public function waiting_count() {
	    $this->db->like('moderate', '0');
        $this->db->from('comments');
		return $this->db->count_all_results();
	}

	public function get_allowed($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('comments', array('moderate' => '2'));
		return $query->result(); 
	}
	public function allowed_count() 
	{
	    $this->db->like('moderate', '2');
        $this->db->from('comments');
		return $this->db->count_all_results();
	}
	
	public function get_trash($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('comments', array('moderate' => '1'));
		return $query->result(); 
	}
	public function trash_count() 
	{
	    $this->db->like('moderate', '1');
        $this->db->from('comments');
		return $this->db->count_all_results();
	}
	
	public function allow_row()
	{
	$data = array(
               'moderate' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('comments', $data);
	}
	public function trash_row()
	{
	$data = array(
               'moderate' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('comments', $data);
	}
	public function waiting_row()
	{
	$data = array(
               'moderate' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('comments', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('comments');
	}
}