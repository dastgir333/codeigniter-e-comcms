<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Download_model extends CI_Model {
	
	public function get_iteminvoice($invoicenumber)
	{
		$this->db->where('customerid', $this->session->userdata('customerid'));
		$this->db->where('invoice', $invoicenumber);
		$query = $this->db->get('orders');
		return $query->result();
	}
	
	public function get_allorderedproducts($invoicenumber)
	{
		$this->db->where('invoice', $invoicenumber);
		$query = $this->db->get('orderedproducts');
		return $query->result();
	}
}