<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings_model extends CI_Model {
	
	public function get_settings()
	{
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result();
	}
	public function get_invoiceprefix()
	{
		$query = $this->db->get_where('invoiceprefix', array('id' => '1'));
		return $query->result();
	}
	public function get_menusettings()
	{
		$query = $this->db->get('menu');
		return $query->result();
	}
	public function get_templatesettings()
	{
		$query = $this->db->get_where('active_template', array('id' => '1'));
		return $query->result();
	}
	public function update_record($data) 
	{
		$this->db->where('id', '1');
		$this->db->update('settings', $data);
	}
	public function update_invoiceprefix($data2) 
	{
		$this->db->where('id', '1');
		$this->db->update('invoiceprefix', $data2);
	}
	public function update_pagemenurecord($pagemenudata) 
	{
		$this->db->where('name', 'pagemenu');
		$this->db->update('menu', $pagemenudata);
	}
	public function update_postmenurecord($postmenudata) 
	{
		$this->db->where('name', 'postmenu');
		$this->db->update('menu', $postmenudata);
	}
	public function update_productmenurecord($productmenudata) 
	{
		$this->db->where('name', 'productmenu');
		$this->db->update('menu', $productmenudata);
	}
	public function update_templaterecord($templatedata) 
	{
		$this->db->where('id', '1');
		$this->db->update('active_template', $templatedata);
	}
	public function update_logorecord($logodata) 
	{
		$this->db->where('id', '1');
		$this->db->update('logo', $logodata);
	}
	public function updatesitemap($data2)
	{
		$this->db->where('id',  '1');
		$this->db->update('sitemap', $data2); 
	}
	public function get_sitemap()
	{
		$this->db->where('id', '1');
		$query = $this->db->get('sitemap');
		return $query->result(); 
	}
	
	public function get_postdata()
	{
		$this->db->where('trash', '0');
		$query = $this->db->get('posts');
		return $query->result(); 
	}
	public function get_productdata()
	{
		$this->db->where('trash', '0');
		$query = $this->db->get('products');
		return $query->result(); 
	}
	public function get_pagedata()
	{
		$this->db->where('trash', '0');
		$query = $this->db->get('pages');
		return $query->result(); 
	}
	public function get_slugnames()
	{
		$this->db->where('trash', '0');
		$this->db->select('slug');
		$query = $this->db->get('pages');
		return $query->result_array(); 
	}
	public function get_images()
	{
		$query = $this->db->get('gallery');
		return $query->result();
	}
	public function get_logo()
	{
		$this->db->where('id', '1');
		$query = $this->db->get('logo');
		return $query->result();
	}
	
	public function get_slideroption()
	{
		$query = $this->db->get('slideroption');
		return $query->result();
	}
	public function get_sliderinfo()
	{
		$query = $this->db->get('slider');
		return $query->result();
	}
	public function update_sliderone($data1)
	{
		$this->db->where('id',  '1');
		$this->db->update('slider', $data1); 
	}
	public function update_slidertwo($data2)
	{
		$this->db->where('id',  '2');
		$this->db->update('slider', $data2);
	}
	public function update_sliderthree($data3)
	{
		$this->db->where('id',  '3');
		$this->db->update('slider', $data3);
	}
	public function update_slideroption($slideroption)
	{
		$this->db->where('id',  '1');
		$this->db->update('slideroption', $slideroption);
	}
}
