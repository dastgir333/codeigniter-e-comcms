<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users_model extends CI_Model {

	public function get_users()
	{
		$this->db->where('status', '0');
		$query = $this->db->get('admin');
		return $query->result();
	}
	public function get_userstrash()
	{
		$this->db->where('status', '1');
		$query = $this->db->get('admin');
		return $query->result();
	}
	public function get_user()
	{
		$userid = $this->uri->segment(4);
		$this->db->where('id', $userid);
		$query = $this->db->get('admin');
		return $query->result();
	}
	public function get_emails()
	{
		$this->db->select('email');
		$query = $this->db->get('admin');
		return $query->result_array();
	}
	public function get_emailsedit($userid)
	{
		$this->db->select('email');
		$this->db->where('id !=', $userid);
		$query = $this->db->get('admin');
		return $query->result_array();
	}
	public function create_user($data) 
	{
		$this->db->insert('admin', $data);
		return;
	}
	public function update_user($data) 
	{
		$this->db->where('id', $data['id']);
		$this->db->update('admin', $data);
		return;
	}
	public function trash_row()
	{
	$data = array(
               'status' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('admin', $data);
	}
	public function restore_row()
	{
	$data = array(
               'status' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('admin', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('admin');
	}
}