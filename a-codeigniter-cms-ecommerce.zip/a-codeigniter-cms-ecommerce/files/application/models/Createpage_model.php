<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createpage_model extends CI_Model {

	public function add_record($data) 
	{
		$this->db->insert('pages', $data);
		return;
	}
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	
	public function get_slugnames()
	{
		$this->db->select('slug');
		$query = $this->db->get('pages');
		return $query->result_array();
	}
	public function get_pagenames()
	{
		$this->db->select('name');
		$query = $this->db->get('pages');
		return $query->result_array();
	}
	
}