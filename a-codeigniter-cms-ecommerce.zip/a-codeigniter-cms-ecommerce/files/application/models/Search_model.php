<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Search_model extends CI_Model {
	
	public function get_page()
    {
		$query = $this->db->get_where('pages', array('slug' => 'search'));
		return $query->result(); 
	}
	
	public function get_searchresult($searchtext3)
    {
		$this->db->like('name', $searchtext3, 'both'); 
		$this->db->or_like('description', $searchtext3, 'both'); 
		$this->db->or_like('keywords', $searchtext3, 'both'); 
		$query = $this->db->get('posts');
		return $query->result(); 
	}
	public function get_searchresultproducts($searchtext3)
    {
		$this->db->like('name', $searchtext3, 'both'); 
		$this->db->or_like('description', $searchtext3, 'both'); 
		$this->db->or_like('keywords', $searchtext3, 'both'); 
		$query = $this->db->get('products');
		return $query->result(); 
	}
}
