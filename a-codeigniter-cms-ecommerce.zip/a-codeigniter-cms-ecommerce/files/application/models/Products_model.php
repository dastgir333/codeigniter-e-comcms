<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products_model extends CI_Model {


	public function get_products($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('products', array('trash' => '0'));
		return $query->result(); 
	}
	public function products_count() {
	    $this->db->like('trash', '0');
        $this->db->from('products');
		return $this->db->count_all_results();
	}
	
	public function get_productsdrafts($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('products', array('trash' => '2'));
		return $query->result(); 
	}
	public function productsdrafts_count() {
	    $this->db->like('trash', '2');
        $this->db->from('products');
		return $this->db->count_all_results();
	}
	
	public function get_productstrash($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, date');
		$this->db->order_by('date', 'desc');
		$query = $this->db->get_where('products', array('trash' => '1'));
		return $query->result(); 
	}
	public function productstrash_count() {
	    $this->db->like('trash', '1');
        $this->db->from('products');
		return $this->db->count_all_results();
	}
	
	public function get_productscat($per_page, $uri)
	{ 
		 $category = $this->uri->segment(3);
		 
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('date', 'desc');
		$this->db->like('category', $category, 'none');
		$this->db->or_like('category2', $category, 'none');
		$this->db->or_like('category3', $category, 'none');
		$query = $this->db->get('products');
		return $query->result(); 
	}
	
	public function productcat_count() {
	     
		 $category = $this->uri->segment(3);
		$this->db->like('category', $category, 'none');
		$this->db->or_like('category2', $category, 'none');
		$this->db->or_like('category3', $category, 'none');
			$this->db->from('products');
			return $this->db->count_all_results();
	}
	public function get_categoryheader()
	{
		$category = $this->uri->segment(3);
		$this->db->select('description, title, keywords'); 
		$query = $this->db->get_where('productcategory', array('slug' => $category));
		return $query->result(); 
	}
	public function get_subcat()
	{
		$category = str_replace('-', ' ', $this->uri->segment(3));
		$this->db->order_by('sort', 'asc');
		$query = $this->db->get_where('productcategory', array('sub' => $category, 'trash' => '0'));
		return $query->result(); 
	}
	public function draft_row()
	{
	$data = array(
               'trash' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('products', $data);
	}
	public function trash_row()
	{
	$data = array(
               'trash' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('products', $data);
	}
	public function restore_row()
	{
	$data = array(
               'trash' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('products', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('products');
	}


}