<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editproduct_model extends CI_Model {
	
	public function get_images() 
	{
		$query = $this->db->get_where('gallery', array('status' => '0'));
		return $query->result();
	}
	
	public function get_product()
	{
		$query = $this->db->get_where('products', array('id' => $this->uri->segment(4)));
		return $query->result();
		
	}
	public function get_productscategory()
	{
	    $this->db->order_by("sort", "asc");
	    $query = $this->db->get_where('productcategory', array('trash' => 0));
		return $query->result(); 
	}
	public function update_record($data2) 
	{
		$this->db->where('id', $data2['id']);
		$this->db->update('products', $data2);
	}
	public function get_downloads() 
	{
		$query = $this->db->get_where('downloads', array('trash' => '0'));
		return $query->result();
	}
	public function get_shippingtype() 
	{
		$query = $this->db->get_where('shippingzones', array('zone' => '1'));
		return $query->result();
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}
