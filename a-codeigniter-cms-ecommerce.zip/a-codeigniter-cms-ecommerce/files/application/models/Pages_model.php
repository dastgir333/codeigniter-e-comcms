<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages_model extends CI_Model {


	public function get_pages($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, sort');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->get_where('pages', array('trash' => '0'));
		return $query->result(); 
	}
	public function pages_count() {
	    $this->db->like('trash', '0');
        $this->db->from('pages');
		return $this->db->count_all_results();
	}
	public function get_pagesdrafts($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, sort');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->get_where('pages', array('trash' => '2'));
		return $query->result(); 
	}
	public function pagesdrafts_count() {
	    $this->db->like('trash', '2');
        $this->db->from('pages');
		return $this->db->count_all_results();
	}
	public function get_pagestrash($per_page, $uri)
	{
		
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->select('id, name, slug, description, sort');
		$this->db->order_by('sort', 'asc');
		$query = $this->db->get_where('pages', array('trash' => '1'));
		return $query->result(); 
	}
	public function pagestrash_count() {
	    $this->db->like('trash', '1');
        $this->db->from('pages');
		return $this->db->count_all_results();
	}
	
	public function draft_row()
	{
	$data = array(
               'trash' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('pages', $data);
	}
	public function trash_row()
	{
	$data = array(
               'trash' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('pages', $data);
	}
	public function restore_row()
	{
	$data = array(
               'trash' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('pages', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('pages');
	}
	

}