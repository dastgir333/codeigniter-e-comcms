<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Galleries_model extends CI_Model {
	
	public function __construct()
	{
	   parent::__construct();
	   
	   $user = $this->session->userdata('username');
	   $thing = BASEPATH;
		$replace = 'images';
		$remove = 'system';
		$new = str_replace($remove, $replace, $thing);
	   	   $this->gallery_path = $new . "gallery";
	   $this->gallery_path_url = base_url(). 'images/gallery/';
	}
	
		
	
    public function do_upload(){
	
	   $user = $this->session->userdata('username');
	   $config = array (
	    'allowed_types' => 'jpg|jpeg|JPG|JPEG|GIF|gif|PNG|png',
		'upload_path' => $this->gallery_path,
		'max_size' => 500000,
	    );
	   
	   $this->load->library('upload', $config);
	   $this->upload->do_upload();
	   $image_data = $this->upload->data();
	   $this->upload->initialize($config); 
	    
	   $config = array (
	   'source_image' => $image_data['full_path'],
	   'new_image' => $this->gallery_path . '/thumbnails',
	   'maintain_ratio' => true,
	   'width' => 150,
	   'height' => 100,
	   );
	   
	   $this->load->library('image_lib', $config);
	   $this->image_lib->resize();
	   
	   $details = array (
	   'name' => $image_data['file_name'],
	   'description' => $image_data['file_name'],
	   'url' => $image_data['file_name'],
	   );
		$this->db->insert('gallery', $details);
		return;
	}
	
	public function get_pics() {
        $this->db->where('status',  '0');
		$query = $this->db->get('gallery');
		return $query->result();
	}
	
	
	public function get_picstrash() {
        $this->db->where('status',  '1');
		$query = $this->db->get('gallery');
		return $query->result();
	}
	
	public function update($data2) 
	{
		$this->db->where('id',  $data2['id']);
		$this->db->update('gallery', $data2); 
	}
	public function trash_row()
	{
	$data = array(
               'status' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('gallery', $data);
	}
	public function restore_row()
	{
	$data = array(
               'status' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('gallery', $data);
	}
	public function delete_row()
	{
	    $this->load->helper('file');
		
		$this->db->where('url', $this->uri->segment(4));
		$this->db->delete('gallery');
		unlink($this->gallery_path . '/' . $this->uri->segment(4));
		unlink($this->gallery_path . '/thumbnails/' . $this->uri->segment(4));
		
	} 
}