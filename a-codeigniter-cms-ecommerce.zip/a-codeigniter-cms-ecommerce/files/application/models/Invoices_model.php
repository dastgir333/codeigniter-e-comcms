<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Invoices_model extends CI_Model {
	
	public function get_invoices($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('orders', array('trash' => '0'));
		return $query->result(); 
	}
	public function invoices_count() {
	    $this->db->like('trash', '0');
        $this->db->from('orders');
		return $this->db->count_all_results();
	}
	public function get_invoice()
	{
		$query = $this->db->get_where('orders', array('id' => $this->uri->segment(4)));
		return $query->result(); 
	}
	public function get_orderedproducts($number)
	{
		$query = $this->db->get_where('orderedproducts', array('invoice' => $number));
		return $query->result(); 
	}
	public function get_invoicesdrafts($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('orders', array('trash' => '1'));
		return $query->result(); 
	}
	public function invoices_draftscount() {
	    $this->db->like('trash', '1');
        $this->db->from('orders');
		return $this->db->count_all_results();
	}
	public function get_invoicestrash($per_page, $uri)
	{
		$this->db->limit($per_page, $this->uri->segment($uri));
		$this->db->order_by('id', 'desc');
		$query = $this->db->get_where('orders', array('trash' => '2'));
		return $query->result(); 
	}
	public function invoices_trashcount() {
	    $this->db->like('trash', '2');
        $this->db->from('orders');
		return $this->db->count_all_results();
	}
	public function draft_row()
	{
			$data = array(
               'trash' => 1
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function trash_row()
	{
			$data = array(
               'trash' => 2
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function restore_row()
	{
			$data = array(
               'trash' => 0
            );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function delete_row()
	{
		$this->db->where('id', $this->uri->segment(4));
		$this->db->delete('orders');
	}
	public function save_adminnotes($data)
	{
		$this->db->where('id', $data['id']);
		$this->db->update('orders', $data);
	}
	public function updatenotpaid()
	{
		$data = array(
           'paid' => 0
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function updatepaid()
	{
		$data = array(
           'paid' => 1
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function updateprocessing()
	{
		$data = array(
           'status' => 'processing'
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function updateonroute()
	{
		$data = array(
            'status' => 'on route'
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function updatedelivered()
	{
		$data = array(
           'status' => 'delivered'
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function updatecancelled()
	{
		$data = array(
           'status' => 'cancelled'
        );

		$this->db->where('id', $this->uri->segment(4));
		$this->db->update('orders', $data);
	}
	public function contactcustomer() 
	{
		$query = $this->db->get_where('orders', array('id' => $this->uri->segment(4)));
		return $query->result(); 
	}
	public function get_currency()
	{
		$this->db->select('currency, currencysign, paymentemail');
		$query = $this->db->get_where('settings', array('id' => '1'));
		return $query->result(); 
	}
}
