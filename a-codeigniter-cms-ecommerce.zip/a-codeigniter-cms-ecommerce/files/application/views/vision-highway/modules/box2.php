<?php if(isset($box2)){ ?>
			   <?php foreach($box2 as $b2part){ ?>
			   <?php 		   
			$linkurl = base_url() . 'shop/';
		   if(isset($b2part->slug)) {
		    $linkslug = $b2part->slug;
		   } else {
		   $linkslug = '';
		   }
     		   echo '<a href="' . $linkurl .  $linkslug . '">';
			   $imagetag1 = '<img';
			   $imagetagpos1 = strpos($b2part->content, $imagetag1);
			   $imagetag2 = '/>';
			   $imagetag3 = '">';
			   $imagetagpos2 = strpos($b2part->content, $imagetag2, $imagetagpos1);
			   $imagetagpos2a = strpos($b2part->content, $imagetag3, $imagetagpos1);
			   if($imagetagpos2 === FALSE) {
			   $imagetagpos3 = strpos($b2part->content, $imagetag3, $imagetagpos1);
			   } 
			   if($imagetagpos2a === FALSE){
			   $imagetagpos3 = strpos($b2part->content, $imagetag2, $imagetagpos1);
			   }
			   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
			   $boximage = substr($b2part->content, $imagetagpos1, $imagelength) ;
			   if($imagelength > 5){
			    echo '<p>' . $boximage . '</p></a>';
				} else {
				echo '<p><img src="' . base_url() . 'images/gallery/thumbnails/nopic.png' . '" /></p></a>';
				}
			    ?>
				<?php echo $b2part->description; ?>
			   <?php } ?>
			<?php } ?>