<div id="content">
 
 
 	<?php foreach($data as $row) { ?>
 <?php 
 $check = $this->uri->segment(1);
 if ($row->slug != $check) { redirect('index.php');}
 else {
$address = base_url() . 'images/smileys/';
$str = $row->content; 
$str = parse_smileys($str, $address); 
echo $str;
      }
 ?>
 <br class="clearBoth" />
       <?php if($row->videolink != ''){ ?>
<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $row->videolink; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	    <?php } ?>
 	<?php } ?>
	
	</div>