<div id="content">    
	<div id="login">
		<h4>Returning customers, login please</h4>
	<?php echo form_open('customer/check_user'); ?>
	<div class="formBoxes">
		<label for="email">Email address</label>
		<input type="text" name="email" id="email" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="password">Password</label>
		<input type="password" name="password" id="password" class="formBox" value="" />
	</div>
	<input type="submit"  value="Login"/>
	<?php echo form_close(); ?>

      </div>
	  <div id="newUser">
		<h4>Create a new account</h4>
	<?php echo form_open('customer/create_user'); ?>
	<div class="formBoxes">
		<label for="email">Email address</label>
		<input type="text" name="email" id="email" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="phone">Phone number</label>
		<input type="text" name="phone" id="phone" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="first_name">First name</label>
		<input type="text" name="first_name" id="first_name" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="last_name">Surname</label>
		<input type="text" name="last_name" id="last_name" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="street_one">Address</label>
		<input type="text" name="street_one" id="street_one" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="street_two">Address (line two)</label>
		<input type="text" name="street_two" id="street_two" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="city">City or town</label>
		<input type="text" name="city" id="city" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="county">County</label>
		<input type="text" name="county" id="county" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="postcode">Postcode</label>
		<input type="text" name="postcode" id="postcode" class="formBox" value="" />
	</div>
	<div class="formBoxes">
		<label for="country">Country</label>
		<select name="country" id="country">
		  <?php  $country = 'none';
		  foreach($countriesdata as $part) { 
			if($country != $part->country && $part->country != null){?>
			  <option value="<?php echo $part->country; ?>"><?php echo $part->country; ?></option>
			<?php $country = $part->country;
				}
			} ?>
		</select>
	</div>
	<div class="formBoxes">
		<label for="password">create a password</label>
		<input type="password" name="password" id="password" class="formBox" value="" />
	</div>
	<input type="submit"  value="Create account"/>
	<?php echo form_close(); ?>
		<br class="clearBoth" />
      </div>
   </div> <br class="clearBoth" />
   