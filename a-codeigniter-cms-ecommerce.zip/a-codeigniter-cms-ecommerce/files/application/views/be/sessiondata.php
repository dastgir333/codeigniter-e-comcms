<div id="content">
 <div id="contentWrapper">
    <h2>session data</h2>
	<p>Session data is used to enable login functions and cart functions.<br>
	After time, these session data logs can become quite large.<br>
	To clear your session data logs click the "delete session data logs" button.<br>
	Please note that this will log anyone out, who is using your site, <br>
	it will also clear customer carts of their contents, so ensure that your site status has been set to "off"<br>
	and there are no other admin users other than yourself, using the site before you press the button.<br>
	When the logs are deleted, you will be logged out and returned to the main page.<br>
	Log in again to set the site status to on.</p>
	<div class="pageEdit"><a href="<?php echo base_url() . 'be/sessiondata/deletedata'; ?>">delete session data logs</a></div>
	</div>
</div>