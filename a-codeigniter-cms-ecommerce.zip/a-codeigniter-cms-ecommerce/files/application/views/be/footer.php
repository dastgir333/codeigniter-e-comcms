
      <div id="footer">
	    <div id="footerBox1">
	  <p><?php echo date('l \t\h\e jS \o\f F Y'); ?></p>
	     </div>
	  </div>

  </body>
</html>


