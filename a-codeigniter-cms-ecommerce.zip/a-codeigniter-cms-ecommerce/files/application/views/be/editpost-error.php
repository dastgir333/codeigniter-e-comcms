 <script src="<?php echo base_url() . 'js/'; ?>addimage.js"></script> 
 <script type="text/javascript">
		jQuery (function ($){
		
			$("#bar").hide();
			$('#btnUpload').click(function() {
			$("#bar").show({height: 'slow'});

		var userfile = $('#userfile').val();
		
		if (!userfile || userfile == 'Userfile') {
			alert('Please choose an image file');
			return false;
		}
	    var data;

		data = new FormData();
		data.append( 'userfile', $( '#userfile' )[0].files[0] );

		$.ajax({
			type: "POST",
			url: "<?php echo site_url('be/gallery/submit'); ?>",
			data: data,
			processData: false,  
			contentType: false,
			success: function(msg) {
				$('#bar2').html(msg);
			}
		});
		
		return false;
		});
	});
</script>
<div id="content">
 <div id="contentWrapper">
    <h2>edit post </h2>
	<div id="bar"><h4>please wait....</h4></div>
    <div id="bar2"></div>
	<div id="imagesButton">images</div>
      <div id="imagesBox">
	   <?php echo form_open_multipart('be/gallery/submit');
			echo form_upload('userfile', 'Userfile',  'id="userfile"');
			echo form_submit('btnUpload', 'Upload', 'id="btnUpload"');
			echo form_close();
		?> 
	  <?php foreach($images as $imagebit) { ?>
	      <div class="images">
		  <img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>" />
		  <br class="clearBoth" />
		  <a href="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>">small</a>
		  <a href="<?php echo base_url() . 'images/gallery/' . $imagebit->url; ?>">large</a>
	      </div>
	  <?php } ?>
	  <br class="clearBoth" />
	  </div>
	<?php echo form_open('be/editpost/update');?>
   
  <div id="formA">
	<div class="formBoxes">
		<label for="name">post name *required</label>
		<input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" />
	</div>
	
	<div class="formBoxes">
		<label for="content">post content here *required</label>
		<textarea rows="25" cols="114" id='txtEditor' name="content"  ><?php echo $data['content']; ?></textarea>
	</div>	
  </div>
  <div id="formB">
	<div class="formBoxes">
		<label for="videolink">YouTube video code, eg, https://youtu.be/ThisCodeHere</label><br />
		https://youtu.be/<input type="text" name="videolink" id="videolink" value="<?php echo $data['videolink']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="description">description *required</label>
		<input type="text" name="description" id="description" value="<?php echo $data['description']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="keywords">keywords *required</label>
		<input type="text" name="keywords" id="keywords" value="<?php echo $data['keywords']; ?>" />
	</div>
	</div>
	

		<div id="formC">
	<label for="trash">save as draft</label>
    <input type="checkbox" name="trash" value="2"> 
    <div class="formBoxes">
	<label for="comments">allow comments</label>
    <input type="checkbox" name="comments" value="1"> 
	</div>
	<input type="hidden" name="category" id="category" value="<?php echo $data['category']; ?>" />
	<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>" />
		<input type="submit"  value="publish"/>
	</div>
	<?php echo form_close(); ?>
		<div id="catlist">
		<h3>Category</h3>
	
	<?php 
	$n = 0;
	if(isset($catlist)) {
        	foreach($catlist as $catpart) {
	    $n++;
		$array = explode(',', $data['category']);
		$check = $catpart->slug;
	?>
   <script type="text/javascript">
	 jQuery (function ($){
		$('#added<?php echo $n;?>').hide();
		$('.catlist<?php echo $n;?>').click(function(event) { 
		event.preventDefault();
        text = '<?php echo $catpart->slug; ?>';
		stuff = ',';
        $('#category').val($('#category').val()+text+stuff); 
        $('.catlist<?php echo $n;?>').hide('fast');
        $('#added<?php echo $n;?>').delay(400).show('fast');
       });
   }); 
   </script>
   <?php if(in_array($check, $array)) { ?>
   <div class="catsingle">
		   <?php echo '<div class="catlist' . $n . '" id="cl"><a href="#">add</a></div>'; ?>  
		 <div class="added" id="added<?php echo $n;?>"><?php echo 'remove'; ?></div>
		 <div class="catname"><?php echo $catpart->name; ?><br />
		 <?php
		 if($catpart->sub && $catpart->sub != 'none') {
		 echo 'sub of: ' . $catpart->sub; 
		 }
		 ?>
		 </div>
    </div>
	<script type="text/javascript">
   jQuery (function ($){
    $('.catlist<?php echo $n;?>').hide();
    $('#added<?php echo $n;?>').delay(100).show();
   });
 </script>
   <?php } else { ?>
   <div class="catsingle">
		   <?php echo '<div class="catlist' . $n . '" id="cl"><a href="#">add</a></div>'; ?>  
		 <div class="added" id="added<?php echo $n;?>"><?php echo 'remove'; ?></div>
		 <div class="catname"><?php echo $catpart->name; ?><br />
		 <?php
		 if($catpart->sub && $catpart->sub != 'none') {
		 echo 'sub of: ' . $catpart->sub; 
		 }
		 ?>
		 </div>
    </div>
   <?php } ?>
		 <script type="text/javascript">
    jQuery (function ($){
   $('#added<?php echo $n;?>').click(function() {
	
   $('#category').val($('#category').val().replace('<?php echo $catpart->slug; ?>,', '')); 
	$('#added<?php echo $n;?>').fadeOut('fast');
	$('.catlist<?php echo $n;?>').delay(400).show('fast');
});
});
		   </script>  
<?php }
     } ?>
	 </div>
<br class="clearBoth" />
	</div>
</div> <br class="clearBoth" />