

    <div id="content">
	  <div id="contentWrapper">
	     <h2>sent messages</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/messages' ?>">messages</a>
		 <a href="<?php echo base_url() . 'be/messages/saved' ?>">saved</a>
		 <a href="<?php echo base_url() . 'be/messages/trash' ?>">trash</a>
		 </div>
	        <?php foreach($messagesdata['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo $row->email; ?>
				<div class="date">
	            <?php echo $row->date; ?>
				</div>
		       </div>
			  <?php
			  $otext = strip_tags($row->message, '<br>');
			  $ctext = explode(' ', $otext);
			  $c2text = array_slice($ctext, 0, 3);
			  $message = implode(' ', $c2text);
			  ?>
		        <div class="box2">
	            <?php echo $message . ' [read more]'; ?>
		         </div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/view/' . $row->id; ?>">view</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/setrestore/' . $row->id; ?>">restore</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/setsaved/' . $row->id; ?>">save</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/settrash/' . $row->id; ?>">trash</a></div>
			</div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $messagesdata['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />