<div id="content">
	  <div id="contentWrapper">
	     <h2>invoice</h2>
	        <?php foreach($invoice as $row){ ?>	
			<div id="markas">
				<?php if($row->status == 'processing'){
				 echo '<h2>order is being processed</h2>';
				 } elseif($row->status == 'on route'){
				 echo '<h2>order is with courier</h2>';
				 } elseif($row->status == 'delivered'){
				 echo '<h2>order has been delivered</h2>';
				 } elseif($row->status == 'cancelled'){
				 echo '<h2>order has been cancelled & refunded</h2>';
				 } elseif($row->status == '') {
				 echo '<h2>status: not set</h2>';
				 }?>
				 <?php echo 'would you like to: '; ?>
				<ul>
				<?php if($row->paid == 1){ ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updatenotpaid/' . $row->id;?>">mark as not paid</a></li>
			   <?php  } else { ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updatepaid/' . $row->id;?>">mark as paid</a></li>
			   <?php } ?>
				<?php if($row->status == 'processing'){ ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updateonroute/' . $row->id;?>">mark as on route</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatedelivered/' . $row->id;?>">mark as delivered</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatecancelled/' . $row->id;?>">mark as cancelled</a></li>
				 <?php } elseif($row->status == 'on route') { ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updateprocessing/' . $row->id;?>">mark as processing</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatedelivered/' . $row->id;?>">mark as delivered</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatecancelled/' . $row->id;?>">mark as cancelled</a></li>
			   <?php  } elseif($row->status == 'delivered') { ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updateprocessing/' . $row->id;?>">mark as processing</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updateonroute/' . $row->id;?>">mark as on route</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatecancelled/' . $row->id;?>">mark as cancelled</a></li>
				<?php } elseif($row->status == 'cancelled') { ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updateprocessing/' . $row->id;?>">mark as processing</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updateonroute/' . $row->id;?>">mark as on route</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatedelivered/' . $row->id;?>">mark as delivered</a></li>
				<?php } else { ?>
					<li><a href="<?php echo base_url() . 'be/invoices/updateprocessing/' . $row->id;?>">mark as processing</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updateonroute/' . $row->id;?>">mark as on route</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatedelivered/' . $row->id;?>">mark as delivered</a></li>
					<li><a href="<?php echo base_url() . 'be/invoices/updatecancelled/' . $row->id;?>">mark as cancelled</a></li>
			   <?php }	?>
					<li><a href="<?php echo base_url() . 'be/invoices/customeralert/' . $row->id;?>">Alert customer</a></li>
				</ul>
			</div> 
			 <div id="invoiceDetails">
				 <ul>
					<li><?php echo 'order placed: ' . $row->originaldate; ?></li>
					<li><?php echo 'order updated: ' . date('D, d M Y, H:i', strtotime($row->date)); ?></li>
					<li><?php echo 'Invoice no: ' . $row->invoice; ?></li>
					<li><?php echo 'Items cost: ' . $currency . sprintf('%0.2f', $row->cost); ?></li>
					<li><?php echo 'Shipping cost: ' . $currency . sprintf('%0.2f', $row->shippingcost); ?></li>
					<li><?php echo 'Total: ' . $currency . sprintf('%0.2f', $row->cost + $row->shippingcost); ?></li>
					<?php if($row->qtydiscount != 'no code' && $row->qtydiscount != null){echo '<li>Discount code: ' . $row->qtydiscount . '</li>';} ?>
					<?php if($row->paid == '1'){ ?>
					<li><?php echo '<div id="paymentrecieved">Payment recieved</div>'; ?></li>
					<?php } else {?>
					<li><?php echo '<div id="paymentnotrecieved">No payment confirmation</div>'; ?></li>
					<?php } ?>
				</ul>
				<div id="deliveryAddress">
					<?php echo $row->customer; ?><br />
					<?php echo $row->deliveryaddress; ?>
				</div>
			</div>
			<div id="invoiceComments"><?php echo 'Customer comments:<br>' . $row->comments; ?></div>
			<div id="invoiceNotes"><?php echo 'Admin notes'; ?>
				<?php echo form_open('be/invoices/savenotes');?>
				<textarea rows="25" cols="70" id='txtEditor' name="adminnotes" ><?php echo $row->adminnotes; ?></textarea>
				<input type="hidden" name="invoiceid" id="invoiceid" value="<?php echo $row->id; ?>" />
				<input type="submit" id="save" value="save"/>
				<?php echo form_close(); ?>
			</div>
	<br class="clearBoth" />
	       <?php } ?>
	        <?php foreach($orderedproducts as $item){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo 'item: ' . $item->product; ?><br />
	            <?php echo ' quantity: ' . $item->quantity; ?>
	            <?php if($item->download != '' && $item->download != 'none'){ echo '<br /> download: ' . $item->download; } ?>
				</div>
				<div class="box2">
	            <?php echo '<br>' . $currency . $item->price; ?><br />
				<?php if($item->options != null){
						$itemsoption = explode(',', $item->options);
						$itemsoptioncost = $itemsoption['1'];
						$itemsoptionname = $itemsoption['0'];
						echo 'Item options: ' .  $itemsoptionname . ', ' . $currency . sprintf('%0.2f', $itemsoptioncost); 
							}?><br />
				</div>
			</div>
			<?php } ?>
	  </div>
	</div>
	<br class="clearBoth" />