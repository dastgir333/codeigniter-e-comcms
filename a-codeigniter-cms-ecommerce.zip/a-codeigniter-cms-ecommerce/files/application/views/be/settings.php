<script type="text/javascript">
		     jQuery (function ($){
			  $('.onstatus').click(function(){
			     stuff = '0';
				 $('#status').val(stuff);
				 $('.onstatus').hide();
				 $('.offstatus').delay(100).show();
			  });
			  
			  $('.offstatus').click(function(){
			     stuff = '1';
				 $('#status').val(stuff);
				 $('.offstatus').hide();
				 $('.onstatus').delay(100).show();
			  });
			 });			 
		 </script>
<div id="content">
        <div id="contentWrapper">
	      <h2>settings</h2>
			<div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/settings/slider-options' ?>">slider options</a>
		 </div>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/settings/payment'; ?>">payment settings</a>
		 </div>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/sessiondata' ?>">session data logs</a>
		 </div>
		 <br class="clearBoth" />
	<?php echo form_open('be/settings/edit');?>
		 <?php foreach($settingsdata as $settingspart){ ?>
		 <?php if($settingspart->status == '1'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.offstatus').hide();
				 $('.onstatus').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.onstatus').hide();
				 $('.offstatus').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
			 <div id="settingsTop">
				  <div class="siteStatus">
				  <label for="status">Site status: </label>
				   <div class="onstatus">
					  <div class="onButton">on</div>
				   </div>
				  <div class="offstatus">
					 <div class="offButton">off</div>
				  </div>
				  <input type="hidden" name="status" id="status" value="<?php echo $settingspart->status;?>" />
				  </div>
				  <div id="sitemap">
					  <?php foreach($sitemapdata as $smd){ ?>
						  <a class="onButton" href="<?php echo base_url() . 'be/settings/sitemap'; ?>">update sitemaps</a>
						  <br class="clearBoth" />
						  <div class="sitemaptext"><?php echo 'sitemaps updated on: ' . $smd->updated; ?></div>
					  <?php } ?>
				  </div>
			  </div>
			  <br class="clearBoth" />
			  <div id="settingsForm">
	            <div class="siteEmail">
			      <label for="email">Site email: </label>
		          <input type="text" name="email" id="email" value="<?php echo $settingspart->email;?>" />
	            </div>
		        <div class="siteTitle">
			      <label for="title">Site title: </label>
		          <input type="text" name="title" id="title" value="<?php echo $settingspart->title;?>" />
	            </div>
			    <div class="siteTagline">
			      <label for="tagline">Site tagline: </label>
		          <input type="text" name="tagline" id="tagline" value="<?php echo $settingspart->tagline;?>" />
	            </div>
			    <div class="siteTimezone">
			      <label for="timezone">Site timezone: </label>
		          <input type="text" name="timezone" id="timezone" value="<?php echo $settingspart->timezone;?>" />
	            <br><a href="http://php.net/manual/en/timezones.php" target="_blank">view timezones list</a>
	            </div>
			  </div>
		 <?php } ?>
		 <div id="menuData">
		 <?php $n = 0; ?>
		 <?php foreach($menudata as $menupart) { ?>
		 <?php $n++; ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.on<?php echo $n; ?>').click(function() {
					 stuff = '0';
					 $('#<?php echo $menupart->name; ?>').val(stuff);
					 $('.on<?php echo $n; ?>').fadeOut('fast');
					 $('.off<?php echo $n; ?>').delay(400).show();
				 });
				 
				 $('.off<?php echo $n; ?>').click(function() {
					 stuff = '1';
					 $('#<?php echo $menupart->name; ?>').val(stuff);
					 $('.off<?php echo $n; ?>').fadeOut('fast');
					 $('.on<?php echo $n; ?>').delay(400).show();
				 });
			 });			 
		 </script>
		 <?php if($menupart->status == '0'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.on<?php echo $n;?>').hide();
				 $('.off<?php echo $n;?>').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.off<?php echo $n;?>').hide();
				 $('.on<?php echo $n;?>').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
		   <div class="menus">
		   <label for="<?php echo $menupart->name; ?>"><?php echo $menupart->name; ?></label>
		   <div class="on<?php echo $n; ?>">
		     <div class="onButton">on</div>
		   </div>
		   <div class="off<?php echo $n; ?>">
		   <div class="offButton">off</div>
		   </div>
		   <br class="clearBoth" />
		   <input type="hidden" name="<?php echo $menupart->name; ?>" id="<?php echo $menupart->name; ?>" value="<?php echo $menupart->status; ?>" />
		   </div>
		 <?php } ?>
		 </div>
		 <div id="logoData">
		 <?php foreach($logo as $hl){ $headerlogo = $hl->image;} ?>
		<p>Current logo<br><img src="<?php echo base_url() . 'images/gallery/' . $headerlogo; ?>" width="150px" /></p>
		<label for="logo">Set logo as:</label>
		<select name="logo" id="logo">
			 <option value="<?php echo $headerlogo; ?>" selected><?php echo $headerlogo; ?></option>
			 <?php foreach($gallerydata as $img){ ?>
			 <option value="<?php echo $img->url; ?>"><?php echo $img->url; ?></option>
			  <?php
				} ?>
		</select> 
		 </div>
		  <div id="templateData">
		 <?php foreach($templatedata as $templatepart2) { ?>
		   <?php foreach($dircontents as $bits2){ ?>
		     <?php if($bits2 != 'be'
			           && $bits2 != '.' && $bits2 != '..'
					   && $bits2 != 'jquery-te-1.4.0.css'
					   && $bits2 != 'bxslider.css'
					   && $bits2 != 'fancyboxmin.css'
					   && $bits2 != 'index.html'){ ?>
			         <?php if($templatepart2->name == $bits2){ ?>
					    <div id="activeTemplate">Active template: <?php echo $templatepart2->name; ?></div>
					   <?php } ?>
			 <?php } ?>
		   <?php } ?>
		 <?php } ?>
		 <?php foreach($templatedata as $templatepart) { ?>
		   <?php foreach($dircontents as $bits){ ?>
		     <?php if($bits != 'be'
			           && $bits != '.' && $bits != '..'
					   && $bits != 'jquery-te-1.4.0.css'
					   && $bits != 'bxslider.css'
					   && $bits != 'fancyboxmin.css'
					   && $bits != 'index.html'){ ?>
					   <div class="templateParts" id="<?php echo $bits; ?>">
					   <?php echo $bits . '<br><img src="' . base_url() . 'css/' . $bits . '/screenshot.png" width="100px" />'?>
					   </div>
					   <script type="text/javascript">
		               jQuery (function ($){
				         $('#<?php echo $bits; ?>').click(function() {
				    	 stuff = '<?php echo $bits; ?>';
				     	 $('#template').val(stuff);
				     	 $('#activeTemplate').replaceWith('<div id="activeTemplate">Active template: <?php echo $bits; ?></div>');
				         });
			           });			 
		              </script>
			 <?php } ?>
		   <?php } ?>
		   <input type="hidden" name="template" id="template" value="<?php echo $templatepart->name; ?>" />
		 <?php } ?>
		 </div>
		<input id="submitButton" type="submit"  value="update"/>
	<?php echo form_close(); ?>
	     </div><br class="clearBoth" />
</div>