<div id="content">
	  <div id="contentWrapper">
	     <h2>invoices drafts</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/invoices/' ?>">invoices</a>
		 <a href="<?php echo base_url() . 'be/invoices/trash' ?>">trash</a>
		 </div>
		  <?php foreach($invoices['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo 'Invoice no: ' . $row->invoice; ?><br />
				<?php echo $currency . sprintf('%0.2f', $row->cost + $row->shippingcost); ?><br />
				<?php echo $row->originaldate; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->customer; ?>
		         </div>
			<div class="pageEdit"><a href="<?php echo base_url() . 'be/invoices/view/' . $row->id; ?>">view</a></div>
			<div class="pageEdit"><a href="<?php echo base_url() . 'be/invoices/setrestore/' . $row->id; ?>">restore</a></div>
			<div class="pageEdit"><a href="<?php echo base_url() . 'be/invoices/settrash/' . $row->id; ?>">trash</a></div>
		   </div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $invoices['links']; ?>
		   </div>
	  </div>
</div><br class="clearBoth" />
