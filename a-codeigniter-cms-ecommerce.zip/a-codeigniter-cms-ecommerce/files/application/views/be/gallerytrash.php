
  <div id="content">
    <div id="contentWrapper">

    <div id="galleryWrapper">
       <h2>images trash</h2>
        <div id="gallerybuttons">
	     <h4><?php echo anchor("be/gallery/", 'images'); ?> </h4>
        </div>
       <br class="clearBoth"/>
         <div id="gallery">
        
     <?php foreach($data as $row){?>
		  <div class="thumb">

        <div class="thumbimage">
		    <a rel="prettyPhoto" href="<?php echo base_url() . 'images/gallery/' . $row->url;?>" title="<?php echo $row->name;?>">
			<img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $row->url;?>" title="<?php echo $row->description;?>" alt="<?php echo $row->description;?>" />
			</a>
		</div>
			<div>
			<?php echo $row->name; ?>
			</div>
	      <h4><?php echo anchor("be/gallery/restorepic/$row->id", 'restore'); ?> </h4>
	     <h4><?php echo anchor("be/gallery/deletepic/$row->url", 'delete'); ?> </h4>
		  </div>
		
	<?php } ?>
		</div>
	
        </div>
    </div>	
  </div>	 <br class="clearBoth" />
