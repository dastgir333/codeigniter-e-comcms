    <div id="content">
	  <div id="contentWrapper">
	     <h2>customer</h2>
		 <div id="pagesButtons">
		 </div>
	        <?php foreach($subscriber as $row){ ?>
			<div id="customerDetails">
	           <div id="customerName"><?php echo $row->first_name . ' ' . $row->last_name; ?></div>
		       <div id="customerEmail"><?php echo $row->email; ?></div>
		       <div id="customerPhone"><?php echo $row->phone; ?></div>
		       <div id="customerAddress">
					<ul>
						<li><?php echo $row->street_one; ?></li>
						<li><?php echo $row->street_two; ?></li>
						<li><?php echo $row->city; ?></li>
						<li><?php echo $row->county; ?></li>
						<li><?php echo $row->postcode; ?></li>
						<li><?php echo $row->country; ?></li>
					</ul>
			   </div>
			 </div>
			 
	       <?php } ?>
	<br class="clearBoth" />
	<h4>Invoices</h4>
		    <?php foreach($subscriberinvoice as $invoice){ ?>
			<div class="box1Container">
	           <div class="box1">
					<?php echo  'No: ' . $invoice->invoice . ' ' . $invoice->originaldate; ?>
				</div>
				<div class="box2">
					<?php echo '£' . $invoice->cost; ?>
					<?php if($invoice->paid == '1'){ ?>
							<?php echo ' paid '; ?>
					<?php } ?>
				</div>
				<div class="pageEdit"><a href="<?php echo base_url() . 'be/invoices/view/' . $invoice->id; ?>">
				view</a></div>
	<br class="clearBoth" />
			</div>
	       <?php } ?>
		  
	  </div>
	</div>
	<br class="clearBoth" />