<div id="content">
	<div id="contentWrapper">
		<h2>edit shipping zone</h2>
		<h4>all fields are required</h4>
			<?php echo form_open('be/shipping/editzone');?>
			<div id="formA">
				<div class="formBoxes">
					<label for="name">name</label>
					<input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" />
				</div>
				<div class="formBoxes">
					<label for="zone">zone</label>
					<input type="text" name="zone" id="zone" value="<?php echo $data['zone']; ?>" />
				</div>
				<div class="formBoxes">
					<label for="country">country</label>
					<input type="text" name="country" id="country" value="<?php echo $data['country']; ?>" />
				</div>	
			</div> 
			<div id="formB">
			<div class="formBoxes">
				<label for="postcodes">postcodes</label><br />
				<textarea id='txt' name="postcodes" ><?php echo $data['postcodes']; ?></textarea>
			</div>
			<div class="formBoxes">
	<p>shipping weights and cost</p>
		<input type="hidden" name="cost" id="cost" value="<?php echo $data['cost']; ?>" />
		<label for="from">weight from (g): </label>
		<input type="text" name="from" id="from" value="" />
		<label for="to">weight to (g): </label>
		<input type="text" name="to" id="to" value="" />
		<label for="price">cost<?php echo ' (' . $currency . ')'; ?>: </label>
		<input type="text" name="price" id="price" value="" />
	<br class="clearBoth" />
		<div class="buttonadd">
		<a id="buttonadd" href="#">add</a>
		</div>
		<div class="buttonclear">
		<a id="buttonclear" href="#">clear</a>
		</div>
	<div id="display">
	<div id="display heading">weight from (g)   |    weight to (g)  |    cost <?php echo '(' . $currency . ')'; ?></div>
	<?php if($data['cost'] != null){ 
	$shippingcosts = explode( ';', $data['cost']);
	foreach($shippingcosts as $shc){	
	$shippingparts = explode(',', $shc); ?>
		<?php if($shippingparts['0'] != null){?>
			<p><?php echo '<div class="shippingboxes">' . $shippingparts['0'] . '</div><div class="shippingboxes">' . $shippingparts['1'] . '</div><div class="shippingboxes">' . $shippingparts['2'] . '</div>';?></p>
		<?php } ?>
	<?php }
	}?>
	<div class="displaylist"></div>
	</div>
	<br class="clearBoth" />
	</div>
	   <script type="text/javascript">
	 jQuery (function ($){
		$('.buttonadd #buttonadd').click(function(event) { 
		event.preventDefault();
		one = $('#from').val();
		two = $('#to').val();
		three = $('#price').val();
        $('#cost').val($('#cost').val()+one+','+two+','+three+';'); 
        $('#display .displaylist').before('<p><div class="shippingboxes">'+one+'</div><div class="shippingboxes">'+two+'</div><div class="shippingboxes">'+three+'</div></p>'); 
       });
	   $('.buttonclear #buttonclear').click(function(event) { 
		event.preventDefault();
        $('#cost').val(''); 
        $('#display p, .shippingboxes').remove(); 
       });
   }); 
   </script>
		</div>	
		<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>" />
		<input type="submit"  value="save"/>
			<?php echo form_close();?>
	</div><br class="clearBoth" />
</div>