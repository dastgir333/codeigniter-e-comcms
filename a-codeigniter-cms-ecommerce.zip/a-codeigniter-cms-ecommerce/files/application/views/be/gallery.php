
<div id="content">
 <div id="contentWrapper">
    <div id="uploadWrapper">
	    <h2>images</h2>
         <div id="gallerybuttons">
	         <h4><?php echo anchor("be/gallery/trash", 'trash'); ?> </h4>
         </div>
       <div id="uploadform">
        <?php
		echo form_open_multipart('be/gallery');
		echo form_upload('userfile');
		echo form_submit('upload', 'Upload');
		echo form_close();

?>
        </div>
    </div>
    <div id="galleryWrapper">

         <div id="gallery">
        
         <?php foreach($data as $row){ ?>
		  <div class="thumb">
		  <?php 
         echo form_open('be/gallery/update');?>
        <div class="thumbimage">
		    <a rel="prettyPhoto" href="<?php echo base_url() . 'images/gallery/' . $row->url;?>" title="<?php echo $row->name;?>">
			<img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $row->url;?>" title="<?php echo $row->description;?>" alt="<?php echo $row->description;?>" />
			</a>
		</div>
			<div>
			<label for="name">title</label><br class="clearBoth" />
				<input type="text" name="name" id="name"  value="<?php echo set_value('name', $row->name) ?>"/>
			</div>
			<div>
			<label for="description">description</label><br class="clearBoth" />
				<input type="text" name="description" id="description"  value="<?php echo set_value('description', $row->description); ?>"/>
			</div>
			
	<input type="submit" value="Update" />
	
	<input type="hidden" name="id" id="id"  value="<?php echo set_value('id', $row->id); ?>"/>
	<?php echo form_close(); ?>
	 <h4><?php if($row->url != 'nopic.png'){ echo anchor("be/gallery/trashpic/$row->id", 'trash'); } ?> </h4>
		  </div>
		
		    <?php } ?>
		</div>
	
        </div>
    </div>	
  </div>	 <br class="clearBoth" />