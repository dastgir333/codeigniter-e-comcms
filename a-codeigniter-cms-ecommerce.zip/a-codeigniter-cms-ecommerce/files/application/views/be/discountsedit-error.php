<div id="content">
	<div id="contentWrapper">
		<h2>edit discount code</h2>
		<h4>name and code are required</h4>
					<?php echo form_open('be/discounts/editcode');?>
					<div id="formA">
						<div class="formBoxes">
							<label for="name">name</label>
							<input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" />
						</div>
						<div class="formBoxes">
							<label for="code">code</label>
							<input type="text" name="code" id="code" value="<?php echo $data['code']; ?>" />
						</div>
						<div class="formBoxes">
							<label for="uses">number of uses</label>
							<input type="text" name="uses" id="uses" value="<?php echo $data['uses']; ?>" />
						</div>	
					</div>
					<div id="formB">
						<div class="formBoxes">
							<label for="startdate">start date | example: 31-12-2019 (DD-MM-YYYY)</label>
							<input type="text" name="startdate" id="startdate" value="<?php echo $data['startdate']; ?>" />
						</div>
						<div class="formBoxes">
							<label for="enddate">end date | example: 31-12-2019 (DD-MM-YYYY)</label>
							<input type="text" name="enddate" id="enddate" value="<?php echo $data['enddate']; ?>" />
						</div>
						<p>If using a set discount, set percent to 0 or if using percent, set discount to 0</p>
						<div class="formBoxes">
							<label for="discount">set discount<?php echo ' (' . $currency . ')'; ?></label>
							<input type="text" name="discount" id="discount" value="<?php echo $data['discount']; ?>" />
						</div>
						<div class="formBoxes">
							<label for="percent">percent discount (%)</label>
							<input type="text" name="percent" id="percent" value="<?php echo $data['percent']; ?>" />
						</div>
					</div>	 
							<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>" />
					<input type="submit"  value="save"/>
					<?php echo form_close();?>
	</div>
	<br class="clearBoth" />
</div>