<div id="content">
        <div id="contentWrapper">
			  <h2>users trash</h2>
			  <div id="pagesButtons">
			      <a href="<?php echo base_url() . 'be/users' ?>">users</a>
		      </div>
		 
		 <br class="clearBoth" />
		 
	    <?php foreach($users as $user){ ?>
		 <div class="box1Container">
			 <?php echo $user->first_name . ' ' . $user->last_name . ',<br> ' . $user->email; ?>
			 <div class="pageEdit"><a href="<?php echo base_url() . 'be/users/edit/' . $user->id; ?>">edit</a></div>
			 <div class="pageEdit"><a href="<?php echo base_url() . 'be/users/setrestore/' . $user->id; ?>">restore</a></div>
			 <div class="pageEdit"><a href="<?php echo base_url() . 'be/users/setdelete/' . $user->id; ?>">delete</a></div>
		 </div>
	    <?php } ?>
		 </div>
</div>
		 <br class="clearBoth" />