<script type="text/javascript">
jQuery (function ($) {
	  $('.images a').click(function(event) {
		  event.preventDefault();
		  linkLocation = this.href;
		  stuffa = '<a class="image-popup-no-margins" href="';
		  stuffb = '">';
		  stuff1 = '<img src="';
		  stuff2 = '" width="150px" /></a>';
		  $("textarea").jqteVal($('textarea').val()+stuffa+linkLocation+stuffb+stuff1+linkLocation+stuff2);
	  });
  });
</script> 
<script type="text/javascript">
		jQuery (function ($){
		
			$("#bar").hide();
			$('#btnUpload').click(function() {
			$("#bar").show({height: 'slow'});

		var userfile = $('#userfile').val();
		
		if (!userfile || userfile == 'Userfile') {
			alert('Please choose an image file');
			return false;
		}
	    var data;

		data = new FormData();
		data.append( 'userfile', $( '#userfile' )[0].files[0] );

		$.ajax({
			type: "POST",
			url: "<?php echo site_url('be/gallery/submit'); ?>",
			data: data,
			processData: false,  
			contentType: false,
			success: function(msg) {
				$('#bar2').html(msg);
			}
		});
		
		return false;
		});
	});
</script>
	  <?php echo form_open_multipart('be/gallery/submit');
			echo form_upload('userfile', 'Userfile',  'id="userfile"');
			echo form_submit('btnUpload', 'Upload', 'id="btnUpload"');
			echo form_close();
	  ?>
	  <?php foreach($images as $imagebit) { ?>
	      <div class="images">
		  <img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>" />
		  <br class="clearBoth" />
		  <a href="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>">small</a>
		  <a href="<?php echo base_url() . 'images/gallery/' . $imagebit->url; ?>">large</a>
	      </div>
	  <?php } ?>
	  <br class="clearBoth" />