
<div id="content">
 <div id="contentWrapper">
    <h2>message</h2>
	<?php foreach($viewmessage as $row){ ?>
	      
	   <div id="email">
	   <?php echo $row->email; ?>
	   </div>
	   <div id="dateOriginal">
	   <?php echo 'Sent: ' . $row->originaldate; ?>
	   </div>
	   <div id="date">
	   <?php echo 'Updated: ' . $row->date; ?>
	   </div>
	   <div class="box3">
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/reply/' . $row->id; ?>">reply</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/setsaved/' . $row->id; ?>">save</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/settrash/' . $row->id; ?>">trash</a></div>
		  </div>
        <br class="clearBoth" />
	   <div id="message">
	   <?php echo $row->message; ?>
	   </div>
	<?php } ?>
  </div>
</div> 
<br class="clearBoth" />