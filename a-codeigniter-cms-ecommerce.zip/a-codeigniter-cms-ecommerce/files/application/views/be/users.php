<div id="content">
        <div id="contentWrapper">
	      <h2>users</h2>
		  
		  <div id="pagesButtons">
		     <a href="<?php echo base_url() . 'be/users/trash' ?>">trash</a>
		 </div>
		 <br class="clearBoth" />
		  
		  <?php foreach($users as $user){ ?>
		 <div class="box1Container">
			 <?php echo $user->first_name . ' ' . $user->last_name . ',<br> ' . $user->email; ?>
			 <div class="pageEdit"><a href="<?php echo base_url() . 'be/users/edit/' . $user->id; ?>">edit</a></div>
			 <div class="pageEdit"><a href="<?php echo base_url() . 'be/users/settrash/' . $user->id; ?>">trash</a></div>
		   </div>
		 <?php } ?>
		 <h4>create new user</h4>
		   <div id="userForm">
		   <?php if(isset($usererror)) { echo $usererror; } ?>
		   
	<?php echo form_open('be/users/create');?>
	
		 <label for="first_name">first name </label>
		 <input type="text" name="first_name" id="first_name" value="" />
		 
		 <label for="last_name">last name </label>
		 <input type="text" name="last_name" id="last_name" value="" />
		 
		 <label for="email">email </label>
		 <input type="text" name="email" id="email" value="" />
		 
		 <label for="password">password </label>
		 <input type="password" name="password" id="password" value="" />
		 
		<input id="submitButton" type="submit"  value="save"/>
	<?php echo form_close(); ?>
	       </div>
	     </div>
</div>
		 <br class="clearBoth" />
