<div id="content">
      <div id="contentWrapper">
	      <h2>main page slider settings</h2>
		  <?php echo form_open('be/settings/saveslideroptions');?>
		 <div id="settingsOption">
				 <?php foreach($slideroption as $so){ ?>
				 <?php echo 'Slider set to display: <b>' . $so->slideroption . '</b><br />'; ?>
				 <?php } ?>
		  <label for="slideroption">slider option: </label>
		   <select name="slideroption" id="slideroption">
				 <option value="select option" selected>select option</option>
					<option value="posts">posts</option>
					<option value="products">products</option>
					<option value="custom">custom</option>
				</select> 
		 </div>
		  <?php $n = 0; ?>
		 <?php foreach($sliderinfo as $sl){ ?>
		 <?php $n++; ?>
		 <div id="settingsForm">
		  <?php echo 'Custom image ' . $n ?><br />
		 <div class="sliderCurrent">
			 current image<br />
			 <?php echo $sl->content . '<br /><h3>' . $sl->title . '</h3><br />' . $sl->description; ?>
		 </div>
		 <br class="clearBoth" />
	            <div class="siteSlider">
				<label for="image<?php echo $n; ?>">image: </label>
			     <select name="image<?php echo $n; ?>" id="image<?php echo $n; ?>">
				 <option value="select image" selected>select image</option>
				 <?php foreach($gallerydata as $img){ ?>
					<option value="<?php echo $img->url; ?>"><?php echo $img->url; ?></option>
				 <?php } ?>
				</select> 
	            </div>
		        <div class="siteSlider">
			      <label for="title<?php echo $n; ?>">heading: </label>
		          <input type="text" name="title<?php echo $n; ?>" id="title<?php echo $n; ?>" value="<?php echo $sl->title;?>" />
	            </div>
				<div class="siteSlider">
			      <label for="description<?php echo $n; ?>">text: </label>
		          <input type="text" name="description<?php echo $n; ?>" id="description<?php echo $n; ?>" value="<?php echo $sl->description;?>" />
	            </div>
				 <div class="siteSlider">
			      <label for="link<?php echo $n; ?>">link: </label>
		          <input type="text" name="link<?php echo $n; ?>" id="link<?php echo $n; ?>" value="<?php echo $sl->slug;?>" />
	            </div>
			  </div>
		 <?php } ?>
		 <br class="clearBoth" />
		<input id="submitButton" type="submit"  value="update"/>
		 <?php echo form_close(); ?>
	  </div>
</div>
		 <br class="clearBoth" />