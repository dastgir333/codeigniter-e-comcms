    <div id="content">
	  <div id="contentWrapper">
	     <h2>logs (minus bots)</h2>
		 <div id="pagesButtons">
			<a href="<?php echo base_url() . 'be/stats/all' ?>">logs (all)</a>
		 </div>
	        <?php foreach($logs['results'] as $row){ ?>
			<div class="box1Container">
			   <?php echo $row->action; ?>
	           <div class="box1">
	            <?php if($row->customerid != '' && $row->customerid != '0'){ echo 'ID:' . $row->customerid . ', ';} echo $row->email; ?>
		       <?php if($row->customerid == '' or $row->customerid == '0' && $row->email != 'not logged in'){ echo '<br>store admin';} ?>
		       </div>
		        <div class="box2">
	            <?php echo 'IP address:' . $row->ip_address; ?><br>
	            <?php echo 'User agent: ' . $row->user_agent; ?><br>
	            <?php echo 'Date:' . $row->date; ?>
		         </div>
			</div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $logs['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />