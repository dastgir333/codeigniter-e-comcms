<div id="content">
	 <div id="contentWrapper">
	     <h2>download files trash</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/downloads' ?>">download files</a>
		 </div>
	    <?php foreach($downloads as $row){ ?>
	   <div class="box1Container">
	           <div class="box1">
	            <?php echo $row->file; ?>
		       </div>
			  
		        <div class="box2">
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/downloads/setrestore/' . $row->id; ?>">restore</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/downloads/setdelete/' . $row->file; ?>">delete</a></div>
		         </div>
			</div> 
	       <?php } ?>
	 </div>
</div>
<br class="clearBoth" />