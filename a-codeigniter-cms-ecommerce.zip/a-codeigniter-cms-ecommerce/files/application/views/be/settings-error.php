<?php if($data['pagemenu'] == '0'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.on1').hide();
				 $('.off1').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.off1').hide();
				 $('.on1').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
		<?php if($data['postmenu'] == '0'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.on2').hide();
				 $('.off2').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.off2').hide();
				 $('.on2').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
		 <?php if($data['productmenu'] == '0'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.on3').hide();
				 $('.off3').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.off3').hide();
				 $('.on3').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
        <script type="text/javascript">
		     jQuery (function ($){
				 $('.on1').click(function() {
					 stuff = '0';
					 $('#pagemenu').val(stuff);
					 $('.on1').fadeOut('fast');
					 $('.off1').delay(400).show();
				 });
				 
				 $('.off1').click(function() {
					 stuff = '1';
					 $('#pagemenu').val(stuff);
					 $('.off1').fadeOut('fast');
					 $('.on1').delay(400).show();
				 });
				 
				 $('.on2').click(function() {
					 stuff = '0';
					 $('#postmenu').val(stuff);
					 $('.on2').fadeOut('fast');
					 $('.off2').delay(400).show();
				 });
				 
				 $('.off2').click(function() {
					 stuff = '1';
					 $('#postmenu').val(stuff);
					 $('.off2').fadeOut('fast');
					 $('.on2').delay(400).show();
				 });
			 
				 $('.on3').click(function() {
					 stuff = '0';
					 $('#productmenu').val(stuff);
					 $('.on3').fadeOut('fast');
					 $('.off3').delay(400).show();
				 });
				 
				 $('.off1').click(function() {
					 stuff = '1';
					 $('#productmenu').val(stuff);
					 $('.off3').fadeOut('fast');
					 $('.on3').delay(400).show();
				 });
				 
				 $('.onstatus').click(function(){
			     stuff = '0';
				 $('#status').val(stuff);
				 $('.onstatus').hide();
				 $('.offstatus').delay(100).show();
			  });
			  
			  $('.offstatus').click(function(){
			     stuff = '1';
				 $('#status').val(stuff);
				 $('.offstatus').hide();
				 $('.onstatus').delay(100).show();
			  });
			 });			 
		 </script>
<div id="content">
        <div id="contentWrapper">
	      <h2>settings</h2>
		  <h4>all fields are required</h4>
	<?php echo form_open('be/settings/edit');?>
	         <?php if($data['status'] == '1'){ ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.offstatus').hide();
				 $('.onstatus').delay(100).show();
			 });			 
		 </script>
		 <?php } else { ?>
		 <script type="text/javascript">
		     jQuery (function ($){
				 $('.onstatus').hide();
				 $('.offstatus').delay(100).show();
			 });			 
		 </script>
		 <?php } ?>
	         <div class="siteStatus">
			  <label for="status">Site status: </label>
			  <div class="onstatus">
		          <div class="onButton">on</div>
		       </div>
		      <div class="offstatus">
		         <div class="offButton">off</div>
		      </div>
		      <input type="hidden" name="status" id="status" value="<?php echo $data['status'];?>" />
	          </div>
		     <br class="clearBoth" />
			<div id="settingsForm">
	          <div class="siteEmail">
			  <label for="email">Site email: </label>
		      <input type="text" name="email" id="email" value="<?php echo $data['email'];?>" />
	          </div>
		      <div class="siteTitle">
			  <label for="title">Site title: </label>
		      <input type="text" name="title" id="title" value="<?php echo $data['title'];?>" />
	          </div>
			  <div class="siteTagline">
			  <label for="tagline">Site tagline: </label>
		      <input type="text" name="tagline" id="tagline" value="<?php echo $data['tagline'];?>" />
	          </div>
			  <div class="siteTimezone">
			  <label for="timezone">Site timezone: </label>
		      <input type="text" name="timezone" id="timezone" value="<?php echo $data['timezone'];?>" />
	          </div>
			</div>
		<div id="menuData">
		   <div class="menus">
		   <label for="pagemenu">pagemenu</label>
		   <div class="on1">
		     <div class="onButton">on</div>
		   </div>
		   <div class="off1">
		   <div class="offButton">off</div>
		   </div>
		   <br class="clearBoth" />
		   <input type="hidden" name="pagemenu" id="pagemenu" value="<?php echo $data['pagemenu']; ?>" />
		   </div>
		   <div class="menus">
		   <label for="postmenu">postmenu</label>
		   <div class="on2">
		     <div class="onButton">on</div>
		   </div>
		   <div class="off2">
		   <div class="offButton">off</div>
		   </div>
		   <br class="clearBoth" />
		   <input type="hidden" name="postmenu" id="postmenu" value="<?php echo $data['postmenu']; ?>" />
		   </div>
		   <div class="menus">
		   <label for="productmenu">productmenu</label>
		   <div class="on3">
		     <div class="onButton">on</div>
		   </div>
		   <div class="off3">
		   <div class="offButton">off</div>
		   </div>
		   <br class="clearBoth" />
		   <input type="hidden" name="productmenu" id="productmenu" value="<?php echo $data['productmenu']; ?>" />
		   </div>
		 </div>
		 <div id="templateData">
		   <?php foreach($dircontents as $bits){ ?>
		     <?php if($bits != 'be'
			           && $bits != '.' && $bits != '..'
					   && $bits != 'jquery-te-1.4.0.css'
					   && $bits != 'bxslider.css'
					   && $bits != 'fancyboxmin.css'){ ?>
			         <?php if($data['template'] == $bits){ ?>
					    <div id="activeTemplate">Active template: <?php echo $data['template']; ?></div>
					   <?php } ?>
					   <div class="templateParts" id="<?php echo $bits; ?>">
					   <?php echo $bits . '<br><img src="' . base_url() . 'css/' . $bits . '/screenshot.png" width="100px" />'?>
					   </div>
					   <script type="text/javascript">
		               jQuery (function ($){
				         $('#<?php echo $bits; ?>').click(function() {
				    	 stuff = '<?php echo $bits; ?>';
				     	 $('#template').val(stuff);
				     	 $('#activeTemplate').replaceWith('<div id="activeTemplate">Active template: <?php echo $bits; ?></div>');
				         });
			           });			 
		              </script>
			 <?php } ?>
		   <?php } ?>
		   <input type="hidden" name="template" id="template" value="<?php echo $data['template']; ?>" />
		 </div>
		<input id="submitButton" type="submit"  value="update"/>
	<?php echo form_close(); ?>
	     </div><br class="clearBoth" />
</div>