<div id="content">
	 <div id="contentWrapper">
       <div id="uploadform">
			<?php
			echo form_open_multipart('be/downloads');
			echo form_upload('userfile');
			echo form_submit('upload', 'Upload');
			echo form_close(); ?>
        </div>
	     <h2>download files</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/downloads/trash' ?>">trash</a>
		 </div>
	    <?php foreach($downloads as $row){ ?>
	   <div class="box1Container">
	           <div class="box1">
	            <?php echo $row->file; ?>
		       </div>
			  
		        <div class="box2">
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/downloads/settrash/' . $row->id; ?>">trash</a></div>
		         </div>
			</div> 
	       <?php } ?>
	 </div>
</div>
<br class="clearBoth" />