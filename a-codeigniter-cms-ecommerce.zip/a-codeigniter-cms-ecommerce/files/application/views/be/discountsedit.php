<div id="content">
	<div id="contentWrapper">
		<h2>edit discount code</h2>
					<?php echo form_open('be/discounts/editcode');?>
					<?php foreach($discounts as $row){ ?>
					<div id="formA">
						<div class="formBoxes">
							<label for="name">name</label>
							<input type="text" name="name" id="name" value="<?php echo $row->name; ?>" />
						</div>
						<div class="formBoxes">
							<label for="code">code</label>
							<input type="text" name="code" id="code" value="<?php echo $row->code; ?>" />
						</div>
						<div class="formBoxes">
							<label for="uses">number of uses</label>
							<input type="text" name="uses" id="uses" value="<?php echo $row->uses; ?>" />
						</div>	
					</div>
					<div id="formB">
						<div class="formBoxes">
							<label for="startdate">start date | example: 31-12-2019 (DD-MM-YYYY)</label>
							<input type="text" name="startdate" id="startdate" value="<?php echo $row->start; ?>" />
						</div>
						<div class="formBoxes">
							<label for="enddate">end date | example: 31-12-2019 (DD-MM-YYYY)</label>
							<input type="text" name="enddate" id="enddate" value="<?php echo $row->end; ?>" />
						</div>
						<p>If using a set discount, set percent to 0 or if using percent, set discount to 0</p>
						<div class="formBoxes">
							<label for="discount">set discount<?php echo ' (' . $currency . ')'; ?></label>
							<input type="text" name="discount" id="discount" value="<?php echo $row->discount; ?>" />
						</div>
						<div class="formBoxes">
							<label for="percent">percent discount (%)</label>
							<input type="text" name="percent" id="percent" value="<?php echo $row->percent; ?>" />
						</div>
					</div>	 
							<input type="hidden" name="id" id="id" value="<?php echo $row->id; ?>" />
					<input type="submit"  value="save"/>
					<?php echo form_close();?>
					<?php } ?>
	</div>
	<br class="clearBoth" />
</div>