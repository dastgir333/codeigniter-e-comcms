
<div id="content">
 <div id="contentWrapper">
    <h2>message</h2>
	<?php foreach($viewmessage as $row){ ?>
	      
	   <div id="email">
	   <?php echo $row->email; ?>
	   </div>
	   <div id="date">
	   <?php echo $row->date; ?>
	   </div>
        <br class="clearBoth" />
	   <div id="message">
	   <?php echo form_open('be/messages/send');?>
	
	<input type="hidden" name="email" id="email" value="<?php echo set_value('email', $row->email); ?>" />
	<div id="replyto">
	<?php echo 'reply to:' . $row->email;?>
	</div>
	<br class="clearBoth" />
	<?php $extra = '
	<br>
	---------- original message ---------------
	<br><br>from: 
	' . $row->email . '<br><br>'; ?>
	<div id="replybox">
		<textarea rows="25" cols="110" id='txtEditor' name="message" ><?php echo $extra . $row->message; ?></textarea>
		<input type="submit" id="send" value="send"/>
	</div>
		  <?php echo form_close(); ?>
	   </div>
	<?php } ?>
  </div>
</div> 
<br class="clearBoth" />