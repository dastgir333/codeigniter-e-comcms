<div id="content">
        <div id="contentWrapper">
	      <h2>payment settings</h2>
		  <h4>all fields are required</h4>
	<?php echo form_open('be/settings/editpayment');?>
			  <div id="settingsForm">
	            <div class="paymentEmail">
			      <label for="email">Payment email: </label>
		          <input type="text" name="email" id="email" value="<?php echo $data['email'];?>" />
	            </div>
		        <div class="currencyBox">
			      <label for="currency">Site currency: </label>
		          <input type="text" name="currency" id="currency" value="<?php echo $data['currency'];?>" />
	            </div>
			    <div class="signBox">
			      <label for="currencysign">Currency sign: </label>
		          <input type="text" name="currencysign" id="currencysign" value="<?php echo $data['currencysign'];?>" />
	            </div>
			    <div class="invoiceprefix">
			      <label for="invoiceprefix">Invoice prefix: </label>
		          <input type="text" name="invoiceprefix" id="invoiceprefix" value="<?php echo $data['invoiceprefix'];?>" />
	            </div>
			  </div>
		<input id="submitButton" type="submit"  value="update"/>
	<?php echo form_close(); ?>
	     </div><br class="clearBoth" />
</div>