<script type="text/javascript">
jQuery (function ($){
		
		$("#bar").hide({height: 'slow'});
		$("#bar2").delay(1000).toggle({height: 'slow'});
		$("#bar2").delay(1000).hide({height: 'slow'});
		$('#imagesBox').fadeOut('slow').load('<?php echo base_url('be/createpost/renew'); ?>').fadeIn("slow");
});
</script>
<h1>uploaded</h1>