
    <div id="content">
	  <div id="contentWrapper">
	     <h2>trashed posts</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/posts' ?>">posts</a>
		 <a href="<?php echo base_url() . 'be/posts/drafts' ?>">drafts</a>
		 </div>
		 <div id="catNavButtons">
		 <a href="<?php echo base_url() . 'be/postcategories' ?>">categories</a>
		 <a href="<?php echo base_url() . 'be/createpostcat' ?>">create new category</a>
		 </div>
	        <?php foreach($postsdata['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo $row->name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->description; ?>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editpost/edit/' . $row->id; ?>">edit</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/posts/setrestore/' . $row->id; ?>">restore</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/posts/setdraft/' . $row->id; ?>">draft</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/posts/setdelete/' . $row->id; ?>">delete</a></div>
		         </div>
			</div> 
	       <?php } ?>
		    <div id="pagesLinks">
		   <?php echo $postsdata['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />