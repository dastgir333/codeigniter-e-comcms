    <div id="content">
	  <div id="contentWrapper">
	     <h2>customers</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/customers/trash'; ?>">trash</a>
		 </div>
	        <?php foreach($subs['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo $row->first_name . ' ' . $row->last_name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->email; ?>
		         </div>
			<div class="pageEdit"><a href="<?php echo base_url() . 'be/customers/settrash/' . $row->id; ?>">
		   trash</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/customers/logs/' . $row->id; ?>">
		   logs</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/customers/view/' . $row->id; ?>">
		   view</a></div>
			</div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $subs['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />