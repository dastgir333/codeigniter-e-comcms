<!DOCTYPE html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?php echo base_url() . 'js/'; ?>jquery-3.3.1.min.js"></script>
	<script src="<?php echo base_url() . 'js/'; ?>jquery-te-1.4.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'css/be/';?>style.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'css/';?>jquery-te-1.4.0.css" />
	<title>admin panel</title> 
<?php if($this->uri->segment(2) != 'shipping'){ ?>
<script type="text/javascript">
jQuery(function ($) {

    $("textarea").jqte();
	
  });
</script>
<?php } ?>
<script type="text/javascript">
	 jQuery (function ($){
		$('.menuToggle').click(function(){ 
        $('#headerMenu').slideToggle('fast');
       });
   }); 
   $(window).resize(function(){
	if ($(window).width() >= 550){	
		$('#headerMenu').show();
  var modWidth = 560;	
		$('iframe').width( modWidth );
	}	
	if ($(window).width() <= 550){
  var modWidth = 250;	
		$('iframe').width( modWidth );
	}	
});

   </script>
</head>
<body>

	   <div id="header">
		  <div id="mobileMenu">
		    <div class="menuToggle">Menu</div>
		   </div>
		  <div id="headerMenu">
		  <ul>
		  <li><a href="<?php echo base_url() . 'be/dash'; ?>">dash</a></li>
		  <li><a href="<?php echo base_url() . 'be/pages'; ?>">pages</a></li>
		  <li><a href="<?php echo base_url() . 'be/createpage'; ?>">create page</a></li>
		  <li><a href="<?php echo base_url() . 'be/posts'; ?>">posts</a></li>
		  <li><a href="<?php echo base_url() . 'be/createpost'; ?>">create post</a></li>
		  <li><a href="<?php echo base_url() . 'be/products'; ?>">products</a></li>
		  <li><a href="<?php echo base_url() . 'be/createproduct'; ?>">create product</a></li>
		  <li><a href="<?php echo base_url() . 'be/invoices'; ?>">invoices</a></li>
		  <li><a href="<?php echo base_url() . 'be/customers'; ?>">customers</a></li>
		  <li><a href="<?php echo base_url() . 'be/gallery'; ?>">gallery</a></li>
		  <li><a href="<?php echo base_url() . 'be/messages'; ?>">messages</a></li>
		  <br />
		  <li><a href="<?php echo base_url() . 'be/shipping'; ?>">shipping</a></li>
		  <li><a href="<?php echo base_url() . 'be/discounts'; ?>">discounts</a></li>
		  <li><a href="<?php echo base_url() . 'be/stats'; ?>">stats</a></li>
		  <li><a href="<?php echo base_url() . 'be/settings'; ?>">settings</a></li>
		  <li><a href="<?php echo base_url() . 'be/users'; ?>">users</a></li>
		  <li><a href="<?php echo base_url() . 'be/help'; ?>">help</a></li>
		  <li><a href="<?php echo base_url() . 'login/logout'; ?>">Logout</a></li>
		  </ul>
		  </div>
	   </div>
