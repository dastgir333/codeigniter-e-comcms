
    <div id="content">
	  <div id="contentWrapper">
	     <h2>approved comments</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/comments' ?>">waiting</a>
		 <a href="<?php echo base_url() . 'be/comments/trash' ?>">trash</a>
		 </div>
		
	        <?php foreach($commentsdata['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <ul>
	            <li><?php echo 'user: ' . $row->user; ?></li>
	            <li><?php echo 'post: ' . $row->post; ?></li>
				</ul>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->comment; ?>
				<br class="clearBoth" />
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/comments/setwaiting/' . $row->id; ?>">unapprove</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/comments/settrash/' . $row->id; ?>">trash</a></div>
		         </div>
			</div> 
	       <?php } ?>
		    <div id="pagesLinks">
		   <?php echo $commentsdata['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />
	