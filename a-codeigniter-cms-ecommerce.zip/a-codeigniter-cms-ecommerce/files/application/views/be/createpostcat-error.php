 <script src="<?php echo base_url() . 'js/'; ?>addimage.js"></script> 
<script type="text/javascript">
		jQuery (function ($){
		
			$("#bar").hide();
			$('#btnUpload').click(function() {
			$("#bar").show({height: 'slow'});

		var userfile = $('#userfile').val();
		
		if (!userfile || userfile == 'Userfile') {
			alert('Please choose an image file');
			return false;
		}
	    var data;

		data = new FormData();
		data.append( 'userfile', $( '#userfile' )[0].files[0] );

		$.ajax({
			type: "POST",
			url: "<?php echo site_url('be/gallery/submit'); ?>",
			data: data,
			processData: false,  
			contentType: false,
			success: function(msg) {
				$('#bar2').html(msg);
			}
		});
		
		return false;
		});
	});
</script>
<div id="content">
 <div id="contentWrapper">
    <h2>create new post category</h2>
	<div id="bar"><h4>please wait....</h4></div>
    <div id="bar2"></div>
	<div id="imagesButton">images</div>
      <div id="imagesBox">
	   <?php echo form_open_multipart('be/gallery/submit');
			echo form_upload('userfile', 'Userfile',  'id="userfile"');
			echo form_submit('btnUpload', 'Upload', 'id="btnUpload"');
			echo form_close();
		?>
	  <?php foreach($images as $imagebit) { ?>
	      <div class="images">
		  <img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>" />
		  <br class="clearBoth" />
		  <a href="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>">small</a>
		  <a href="<?php echo base_url() . 'images/gallery/' . $imagebit->url; ?>">large</a>
	      </div>
	  <?php } ?>
	  <br class="clearBoth" />
	  </div>
	<?php echo form_open('be/createpostcat/create');?>

  <div id="formA">
	<div class="formBoxes">
		<label for="name">category name *required</label>
		<input type="text" name="name" id="name" value="<?php echo $data['name'] ?>" />
	</div>
	
	<div class="formBoxes">
		<label for="content">category content here *required</label>
		<textarea rows="25" cols="114" id='txtEditor' name="content"  ><?php echo $data['content'] ?></textarea>
	</div>	
  </div>
  <div id="formB">
	<div class="formBoxes">
		<label for="videolink">YouTube video code, eg, https://youtu.be/ThisCodeHere</label><br />
		https://youtu.be/<input type="text" name="videolink" id="videolink" value="<?php echo $data['videolink'] ?>" />
	</div>
	<div class="formBoxes">
		<label for="description">description *required</label>
		<input type="text" name="description" id="description" value="<?php echo $data['description'] ?>" />
	</div>
	<div class="formBoxes">
		<label for="keywords">keywords *required</label>
		<input type="text" name="keywords" id="keywords" value="<?php echo $data['keywords'] ?>" />
	</div>
	</div>
	

		<div id="formC">
	<label for="trash">save as draft</label>
    <input type="checkbox" name="trash" value="2"> 
    <div class="formBoxes"><label for="sort">sort order</label>
	<input type="text" name="sort" id="sort" value="<?php echo $data['sort']; ?>" />
	<input type="hidden" name="sub" id="sub" value="<?php echo $data['sub']; ?>" />
	</div>
	
		<input type="submit"  value="publish"/>
	</div>
	<?php echo form_close(); ?>
	<div id="catlist2">
	<div class="formBoxes">
		<div class="subcatof">sub category of: <?php echo $data['sub'] ?></div>
	</div>
    <div class="catsingle">
		<?php echo '<div class="catlist" id="cl"><a href="#">none</a></div>'; ?>  
    </div>
	<?php
	$n = 0;
	foreach($categories as $catbit) {
	$n++
	?>
	<script type="text/javascript">
     jQuery (function ($){
		$('.catlist').click(function(event) { 
		event.preventDefault();
        text = 'none';
		$('#sub').val('');
        $('#sub').val($('#sub').val()+text); 
        $('.subcatof').replaceWith('<div class="subcatof">sub category of: none</div>');
        });
		   
		$('#added<?php echo $n;?>').hide();
		$('.catlist<?php echo $n;?>').click(function(event) { 
		event.preventDefault();
        text = '<?php echo $catbit->name; ?>';
		$('#sub').val('');
        $('#sub').val($('#sub').val()+text); 
        $('.subcatof').replaceWith('<div class="subcatof">sub category of: <?php echo $catbit->name; ?></div>');
        });
    }); 
	</script>
	<div class="catsingle">
		<?php echo '<div class="catlist' . $n . '" id="cl"><a href="#">' . $catbit->name . '</a></div>'; ?>  
    </div>
		<?php } ?>
	</div>
	</div>
</div> <br class="clearBoth" />