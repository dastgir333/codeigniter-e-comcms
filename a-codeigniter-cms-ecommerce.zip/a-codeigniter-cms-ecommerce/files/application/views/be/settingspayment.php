<div id="content">
        <div id="contentWrapper">
	      <h2>payment settings</h2>
			<div id="settingsForm">
			<?php echo form_open('be/settings/editpayment');?>
			<?php foreach($settingsdata as $settingspart){ ?>
			 
	            <div class="paymentEmail">
			      <label for="email">Payment email: </label>
		          <input type="text" name="email" id="email" value="<?php echo $settingspart->paymentemail;?>" />
	            </div>
		        <div class="currencyBox">
			      <label for="currency">Site currency: </label>
		          <input type="text" name="currency" id="currency" value="<?php echo $settingspart->currency;?>" />
	            </div>
				  <a href="https://developer.paypal.com/docs/api/reference/currency-codes/" target="_blank">Click here for currency values</a><br>
				<a href="https://www.htmlsymbols.xyz/currency-symbols" target="_blank">Click here for HTML currency signs</a>
			    <div class="signBox">
			      <label for="currencysign">Currency sign: </label>
		          <input type="text" name="currencysign" id="currencysign" value="<?php echo $settingspart->currencysign;?>" />
	            </div>
		 <?php } ?>
		 <?php foreach($invoiceprefix as $invoicepart){ ?>
	            <div class="invoiceprefix">
			      <label for="invoiceprefix">Invoice prefix: </label>
		          <input type="text" name="invoiceprefix" id="invoiceprefix" value="<?php echo $invoicepart->prefix;?>" />
	            </div>
		 <?php } ?>
			  </div>
		<input id="submitButton" type="submit"  value="update"/>
	<?php echo form_close(); ?>
	     </div><br class="clearBoth" />
</div>