<div id="content">
        <div id="contentWrapper">
		 
		  <?php foreach($user as $part){ ?>
			 <h4>edit user</h4>
			   <div id="userForm">
			<?php echo form_open('be/users/update');?>
			
				 <label for="first_name">first name </label>
				 <input type="text" name="first_name" id="first_name" value="<?php echo $part->first_name; ?>" />
				 
				 <label for="last_name">last name </label>
				 <input type="text" name="last_name" id="last_name" value="<?php echo $part->last_name; ?>" />
				 
				 <label for="email">email </label>
				 <input type="text" name="email" id="email" value="<?php echo $part->email; ?>" />
				 
				 <label for="password">password </label>
				 <input type="password" name="password" id="password" value="" />
				 <input type="hidden" name="id" id="id" value="<?php echo $part->id; ?>" />
				 
				<input id="submitButton" type="submit"  value="save"/>
			<?php echo form_close(); ?>
			   </div>
		 <?php } ?>
		 
	     </div>
</div>
		 <br class="clearBoth" />