
    <div id="content">
	 <div id="contentWrapper">
		 <div id="catNavButtons">
		 <a href="<?php echo base_url() . 'be/downloads' ?>">download files</a>
		 </div>
	     <h2>products</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/products/drafts' ?>">drafts</a>
		 <a href="<?php echo base_url() . 'be/products/trash' ?>">trash</a>
		 </div>
		 <div id="catNavButtons">
		 <a href="<?php echo base_url() . 'be/productcategories' ?>">categories</a>
		 <a href="<?php echo base_url() . 'be/createproductcat' ?>">create new category</a>
		 </div>
	    <?php foreach($productsdata['results'] as $row){ ?>
	   <div class="box1Container">
	           <div class="box1">
	            <?php echo $row->name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->description; ?>
		         </div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editproduct/edit/' . $row->id; ?>">edit</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/products/setdraft/' . $row->id; ?>">draft</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/products/settrash/' . $row->id; ?>">trash</a></div>
			</div> 
	       <?php } ?>
		    <div id="pagesLinks">
		   <?php echo $productsdata['links']; ?>
		   </div>
	 </div>
	</div>
	<br class="clearBoth" />