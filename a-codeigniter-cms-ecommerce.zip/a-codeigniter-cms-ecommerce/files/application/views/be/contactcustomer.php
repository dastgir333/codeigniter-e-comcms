<div id="content">
 <div id="contentWrapper">
    <h2>message</h2>
	<?php foreach($data as $row){ ?>
		<?php if($row->status == 'processing'){
				 $status = '<h3>Your order is being processed</h3>';
				 } elseif($row->status == 'on route'){
				 $status = '<h3>Your order is with the courier</h3>';
				 } elseif($row->status == 'delivered'){
				 $status = '<h3>Your order has been delivered</h3>';
				 } elseif($row->status == 'cancelled'){
				 $status = '<h3>Your order has been cancelled & refunded</h3>';
				 } elseif($row->status == '') {
				 $status = '';
				}?>
        <br class="clearBoth" />
	   <div id="message">
	   <?php echo form_open('be/messages/send');?>
	
	<input type="hidden" name="email" id="email" value="<?php echo set_value('email', $row->email); ?>" />
	<div id="replyto">
	<?php echo 'Alert customer:' . $row->email;?>
	</div>
	<br class="clearBoth" />
	<?php $extra = $status . '
	<br>
	' . $row->invoice . '
	<br>Order placed:  ' . $row->originaldate . '<br>
	' . $row->email . '<br><br>'; ?>
	<div id="replybox">
		<textarea rows="25" cols="110" id='txtEditor' name="message" ><?php echo $extra; ?></textarea>
		<input type="submit" id="send" value="send"/>
	</div>
		  <?php echo form_close(); ?>
	   </div>
	<?php } ?>
  </div>
</div> 
<br class="clearBoth" />

