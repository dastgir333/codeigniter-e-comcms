<div id="content">
	  <div id="contentWrapper">
	     <h2>help pages</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		 <div id="helpList">
			 <ul>
				<li><a href="<?php echo base_url() . 'be/help/dash' ?>">dash -- how the dash works</a></li>
				<li><a href="<?php echo base_url() . 'be/help/pages' ?>">pages -- how to create and edit pages</a></li>
				<li><a href="<?php echo base_url() . 'be/help/posts' ?>">posts -- how to create and edit posts and post categories</a></li>
				<li><a href="<?php echo base_url() . 'be/help/products' ?>">products -- how to create and edit products and product categories</a></li>
				<li><a href="<?php echo base_url() . 'be/help/gallery' ?>">gallery -- how to upload images and how the gallery works</a></li>
				<li><a href="<?php echo base_url() . 'be/help/shipping' ?>">shipping -- how to create and edit shipping zones and costs</a></li>
				<li><a href="<?php echo base_url() . 'be/help/discounts' ?>">discounts -- how to create and edit discount codes</a></li>
				<li><a href="<?php echo base_url() . 'be/help/invoices' ?>">invoices -- how to update invoices and how the invoice functions work</a></li>
				<li><a href="<?php echo base_url() . 'be/help/customers' ?>">customers -- how to use the customers functions</a></li>
				<li><a href="<?php echo base_url() . 'be/help/messages' ?>">messages -- how to recieve, reply and save messages</a></li>
				<li><a href="<?php echo base_url() . 'be/help/stats' ?>">stats -- how to use site stats</a></li>
				<li><a href="<?php echo base_url() . 'be/help/users' ?>">users -- how to create and delete admin user accounts</a></li>
				<li><a href="<?php echo base_url() . 'be/help/settings' ?>">settings -- how to use the site settings and site payment settings</a></li>
			 </ul>
		 </div>
	  </div>
</div><br class="clearBoth" />