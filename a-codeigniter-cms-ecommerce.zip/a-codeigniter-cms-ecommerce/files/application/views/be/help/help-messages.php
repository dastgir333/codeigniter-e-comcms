<div id="content">
	  <div id="contentWrapper">
	     <h2>messages help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			Messages recieved via the contact form will be forwarded to the site email address that has been set in the settings section, aswell as saved in the messages section. To view a message click view from the dash board or the messages section.<br><br>
			To reply to a message, click reply from inside the message view screen, this will forward you to a reply screen where the email address has been taken care of for you and the original message along with a date has been added to the reply for you. Add your message into the text area and click send.<br><br>
			Sent messages will be saved in the sent section inside the messages section.<br><br>
			To delete a message, click trash then from inside the trash section click delete.
			You can also save messages by clicking save, this will save the message into the saved section inside the messages section.
		</p>
	  </div>
</div><br class="clearBoth" />