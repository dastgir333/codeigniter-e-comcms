<div id="content">
	  <div id="contentWrapper">
	     <h2>settings help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To set your site in maintenance mode, click the site status button to display "off" and click update at the bottom of the page.<br><br>
			To update the websites site maps and to alert google that the site maps are ready to be indexed, click the "update sitemaps" button (no need to click update) and this will return you to the settings page where the updated date will have been updated, this indicates that the sitemaps have been built and google has been alerted successfully.<br><br>
			Enter your contact email address into the site email field, this email address will recieve messages sent via the contact form and will recieve messages regarding new orders.<br>
			Enter the site tagline and title into the appropriate fields and add in your sites timezone, relevant timezones can be found through the link provided.<br>
			These four fields are required.<br><br>
			Header menus can be enabled and disabled by switching on or off the correct menu and then by clicking the update button.<br><br>
			The current logo will be displayed in the logo box on the right hand side of the settings page. To choose a logo first upload your logo via the gallery section then from inside the setting section, select the image you want to use as your logo and click update at the bottom of the settings page.<br><br>
			To choose a template for your site, click on the thumbnail image for that template and click update at the bottom of the settings page, this will set the template you have chosen on the front end of your site.<br><br>
			Slider options, to change the content of the mainpage image slider, from inside the settings section click the slider settings button, select from the drop down menu at the top of the page which option you would prefer, to display posts, products or custom images, text and links. Posts and Products will display the last three most recent posts or products inside the mainpage slider, custom will use the images text and links that are entered into the custom fields.<br>
			To use custom images, text and links, first upload your images via the gallery section then from inside settings/slider options, select the images using the drop down menus and enter your link text and the URL you want to link to, then click update at the bottom of the screen, ensure that you have selected "custom" in the dropdown menu.<br><br>
			Payment settings, enter in your sites payment email address, this must be the email address that you have registered with PayPal as a viable payment address. Enter in your sites currency, both the abbreviated currency and the currency symbol, for example GBP and &pound;, use the links provided to ensure you enter the correct values, then click update.<br><br>
			Session data is used to enable login functions and cart functions.<br>
			After time, these session data logs can become quite large.<br>
			To clear your session data logs click the "delete session data logs" button.<br>
			Please note that this will log anyone out, who is using your site,
			it will also clear customer carts of their contents, so ensure that your site status has been set to "off"
			and there are no other admin users other than yourself, using the site before you press the button.<br>
			When the logs are deleted, you will be logged out and returned to the main page.<br>
			Log in again to set the site status to on.
		<p/>
	  </div>
</div><br class="clearBoth" />