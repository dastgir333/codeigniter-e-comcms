<div id="content">
	  <div id="contentWrapper">
	     <h2>posts help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new post, click the create post link in the header menu.<br>
			Enter a post name without punctuation. Question marks can be used.<br>
			A post name is required.<br><br>
			Enter some content for your post via the content box. This acts like a standard text editor allowing you to alter the size and colour of your text, set headings and list items, justify text and align text, set links and add images.<br>
			The first image in your post will be used in the post category list, recent posts and on the front page, to display a link to that post.<br><br>
			To upload images, click the images button and use the quick upload system provided. This will allow you to upload images one at a time, without leaving the create post screen. You can also upload images via the gallery. To add an image to your post, find the image in the images section (this opens and closes when the images button is clicked) click on small or large and this will add the image to your post. You can alter the image size in the text editor to better suit your post layout.<br><br>
			If you want to display a youtube video on your post, add in the YouTube video code, eg, https://youtu.be/ThisCodeHere into the box, or leave empty in you do not want to display a video.<br><br>
			A post description is required.<br>
			Post descriptions are used in recent posts and post category lists and within the front page slider. They are used to give site users a brief description on the post in the link.<br>
			Post descriptions are also used and displayed by search engines in search listings.<br>
			Descriptions should be limited to 160 characters or less.<br><br>
			Keywords and keyphrases should be seperated by a comma and should be used to best index that post. Keywords should reflect the content in the post, so a post about gardening should have keywords similar to this:<br><br>
			gardening, garden maintainence, how to start a garden, how to build raised beds, how to grow tomatoes<br><br>
			Keep keywords specific to your post content.<br><br>
			Ticking the "save as draft" checkbox will save the post as a draft.<br><br>
			Posts can be added to up to three categories. Click on the add button to add that post to the category.<br>
			Click the remove button to remove from the category. Categories can be created and edited via the posts section (click posts in the header menu).<br><br>
			Comments are off by default and need to be switched on by clicking the comments checkbox. Editing posts will require the comments checkbox to be clicked again to switch on post comments as this is set to off by default. Comments are keppt for approval by site admin before they are displayed on the site, this is done via the comments section inside the posts section. Comments are seperated into sections, comments waiting approval, comments that have been approved and trashed comments waiting to be deleted or restored.<br><br>
			Clicking publish will publish your post or save as draft and return you to the posts section, if there are any required fields that have not been filled, you will be returned to the error page where you will be able to add in the extra, missing info, without loosing the post content that you have already entered.<br>
		</p>
	  </div>
</div><br class="clearBoth" />