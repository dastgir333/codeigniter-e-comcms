<div id="content">
	  <div id="contentWrapper">
	     <h2>shipping help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new shipping zone, click the create zone button.<br>
			Enter a name for this shipping zone, related zones should share the same name, this is usually the courier name.<br>
			You can have as many zones as you need that share the same name.<br>
			You can also have zones for the same locations that have a different name and also different shipping costs.<br>
			This is useful to create different courier types with different costs.<br><br>
			Enter a number for your zone, for example 1 or 2 etc. Each zone will have its own shipping costs per weight. <br>
			Using zones allows you to charge different shipping costs for different locations.<br><br>
			Enter a country for this shipping zone, for example: United Kingdom<br><br>
			Enter the postcodes for this zone separated by a comma, for example:<br><br>
			IV,HS,KA27,KA28,KW,PA20,PA21,PA22,PA23,PA24,PA25,PA26,PA27,PA28,MX5<br><br>
			Only the first half of the postcode is required, for example a postcode like this MX5 2LT will only need MX5 adding into the postcode list.<br>
			If the postcode length is six characters long, then only the first three characters need added to the postcode field.<br>
			If the postcode length is seven characters long, then only the first four characters need added to the postcode field.<br>
			If the postcode length is eight characters long, then only the first four characters need added to the postcode field.<br>
			If the postcode length is five characters long, then only the first two characters need added to the postcode field.<br>
			If the postcode length is four characters long, then only the first two characters need added to the postcode field.<br><br>
			If you are creating "zone 1" you only require "all others" to be added to the post code field as it will be assumed that any post code that can not be found in zone 2 or 3 or 4 etc, must be in zone 1.<br>
			It is possible to have one zone for one country, this will mean one set of shipping costs to all addresses in that country.<br><br>
			Set your cost per weight, add a "from weight" for example 1g, set a "to weight" for example 1000g, set a cost for shipping items between these two weights, for example £1 (your own site currency will be shown in the shipping section) and click the add button<br>
			Add in as many weights and costs as you require, from the smallest weight of your products to the largest weight of order that you can process.<br><br>
			Click save to save that zone into the database. Repeat for each shipping zone you require for your location and shipping requirements.<br><br>
			To edit zones, click edit and change the required information, ensure to follow the same rules as above.<br>
		</p>
	  </div>
</div><br class="clearBoth" />