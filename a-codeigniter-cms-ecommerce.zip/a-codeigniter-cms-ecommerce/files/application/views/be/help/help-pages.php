<div id="content">
	  <div id="contentWrapper">
	     <h2>pages help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new page, click the create page link in the header menu.<br>
			Enter a page name without punctuation. Question marks can be used.<br>
			A page name is required.<br><br>
			Enter some content for your page via the content box. This acts like a standard text editor allowing you to alter the size and colour of your text, set headings and list items, justify text and align text, set links and add images.<br><br>
			To upload images, click the images button and use the quick upload system provided. This will allow you to upload images one at a time, without leaving the create page screen. You can also upload images via the gallery. To add an image to your page, find the image in the images section (this opens and closes when the images button is clicked) click on small or large and this will add the image to your page. You can alter the image size in the text editor to better suit your page layout.<br><br>
			If you want to display a youtube video on your page, add in the YouTube video code, eg, https://youtu.be/ThisCodeHere into the box, or leave empty in you do not want to display a video.<br><br>
			A page description is required.<br>
			Page descriptions are used in recent posts and post category lists and within the front page slider. They are used to give site users a brief description on the page in the link.<br>
			Page descriptions are also used and displayed by search engines in search listings.<br>
			Descriptions should be limited to 160 characters or less.<br><br>
			Keywords and keyphrases should be seperated by a comma and should be used to best index that page. Keywords should reflect the content on the page, so a page about gardening should have keywords similar to this:<br><br>
			gardening, garden maintainence, how to start a garden, how to build raised beds, how to grow tomatoes<br><br>
			Keep keywords specific to your page content.<br><br>
			Ticking the "save as draft" checkbox will save the page as a draft.<br><br>
			Page sort orders are used to position page links in the header menu, a sort order of zero will hide that page from the header menu, which is useful for making sub-pages that link from other pages.<br><br>
			Clicking publish will publish your page or save as draft and return you to the pages section, if there are any required fields that have not been filled, you will be returned to the error page where you will be able to add in the extra, missing info, without loosing the page content that you have already entered.<br>
		</p>
	  </div>
</div><br class="clearBoth" />