<div id="content">
	  <div id="contentWrapper">
	     <h2>gallery help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To upload images, select the image to upload and click the upload button.<br>
			A multi image upload upgrade is due soon.<br>
			To delete images, click trash, then from inside the trash section, click delete.<br>
			Images uploaded will be able to be added to pages posts and products through the relevant create or edit sections.
		</p>
	  </div>
</div><br class="clearBoth" />