<div id="content">
	  <div id="contentWrapper">
	     <h2>customers help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To view customer details, click customers in the header menu and click view on the customer you wish to view. To view logs and download records for that customer, click the logs button.<br>
			The customer view will display delivery details and invoice details for that customer. You can click on each invoice to view that invoice for that customer, you can also contact the customer via any invoice for that customer.<br><br>
			Customer logs are required by Paypal as evidence of reciept of a downloadable product.
		</p>
	  </div>
</div><br class="clearBoth" />