<div id="content">
	  <div id="contentWrapper">
	     <h2>users help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new site admin user, add in a first name, last name, email address and password.<br>
			Ensure that the same email address is not used twice as this will return you to the error page that will ask you to enter another email address.<br>
			To delete a user, click trash, then from inside  the trash section click delete. Users that are in the trash section can not log in.<br>
			To edit user details, click edit and enter the new information. If you do not wish to update the password, leave the password field blank and the password will remain unchanged. To change the password, enter the new password in the field and click save.
		</p>
	  </div>
</div><br class="clearBoth" />