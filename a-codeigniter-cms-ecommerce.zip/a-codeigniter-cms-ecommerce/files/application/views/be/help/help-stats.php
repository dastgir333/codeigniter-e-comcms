<div id="content">
	  <div id="contentWrapper">
	     <h2>stats help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			The statistics page will show site users minus search engine robots and spiders as default, to view the full list of site visitors including search engine bots and spiders, click the "all logs button".<br><br>
			Stats that record customer downloads relating to downloads purchased can be viewed via the customers section.<br>
			This information is required by PayPal as evidence of product delivery.
		</p>
	  </div>
</div><br class="clearBoth" />