<div id="content">
	  <div id="contentWrapper">
	     <h2>invoices help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To view an invoice click view. The invoice screen will display the delivery details and name of the customer, the items cost for the order, the shipping cost and the total cost.<br>
			Individual items details are displayed at the bottom of the invoice, items name, quantity, options and cost.<br><br>
			To leave comments for administration purposes (not displayed to the customer) enter the comments into the text area and click save.<br><br>
			To update the order, click the appropriate button, you will be returned to the same invoice and the status will have been altered and the updated date will show when the status was set.<br><br>
			To contact the customer click alert customer, you will be forwared to a reply screen where the details of the order will be already added to your message and the correct email address set for that customer. Enter your message to the customer in to the text area and click send. Sent messages will be saved in the sent section inside the messages section.
		</p>
	  </div>
</div><br class="clearBoth" />