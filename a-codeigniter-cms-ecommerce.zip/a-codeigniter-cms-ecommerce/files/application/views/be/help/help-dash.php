<div id="content">
	  <div id="contentWrapper">
	     <h2>dash help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
		The dashboard displays five latest posts, five pages, five products and the most recent five messages that have been recieved via the contact form. <br>
		To view a page, post or product simply click on the title of that post, page or product. <br>
		To edit, simply click the edit button next to the title. <br>
		To view a message click the view button. The "view all" links will take you to the correct section.
		</p>
	  </div>
</div><br class="clearBoth" />