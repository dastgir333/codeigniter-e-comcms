<div id="content">
	  <div id="contentWrapper">
	     <h2>discounts help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new discount code, click the create discount code button and enter in a name for your discount voucher.<br>
			Names do not need to be unique but codes do.<br>
			All fields are required.<br>
			Enter a code for your discount voucher, ensure this code is not the same as a code you already have in yor discounts section, this will cause your code to be changed and a -2 added onto the end of the code to ensure the code is unique.<br>
			Enter the number of uses you would like this voucher to have.<br>
			Enter the start date for this voucher example: 31-12-2019 (DD-MM-YYYY)<br>
			Enter the end date for this voucher example: 31-01-2020 (DD-MM-YYYY)<br>
			Set a discount for this voucher, if using a set discount, set percent to 0 or if using percent, set discount to 0<br>
			Click save at the bottom of the screen to set your discount voucher live.<br><br>
			To edit an existing voucher, click edit and change any info you require, ensure to follow the same rules as above.
		</p>
	  </div>
</div><br class="clearBoth" />