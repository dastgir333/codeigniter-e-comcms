<div id="content">
	  <div id="contentWrapper">
	     <h2>products help page</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/help' ?>">help</a>
		 </div>
		 <br class="clearBoth" />
		<p>
			To create a new product, click the create product link in the header menu.<br>
			Enter a product name without punctuation. Question marks can be used.<br>
			A product name is required.<br><br>
			Enter a price and weight for your product. Weights are used to calculate shipping costs (see shipping help for more info).<br>
			Enter a shipping type for your product, this will assign a shipping cost to your product (see shipping help for more info).<br><br>
			If your product is a downloadable product, select the file for download via the drop down list, if your product is not a download, leave set to "none". Downloadable files can be uploaded via the Products section, click Products then click download files to view a list of downloadable files and to upload files for product downloads.<br>
			Downloadable products can not use the options functions, options will not be offered to customers on downloadable products.<br><br>
			Enter some content for your product via the content box. This acts like a standard text editor allowing you to alter the size and colour of your text, set headings and list items, justify text and align text, set links and add images.<br>
			The first image in your product will be used in the product category list, all products and on the front page, to display a link to that product.<br><br>
			To upload images, click the images button and use the quick upload system provided. This will allow you to upload images one at a time, without leaving the create product screen. You can also upload images via the gallery. To add an image to your product, find the image in the images section (this opens and closes when the images button is clicked) click on small or large and this will add the image to your product. You can alter the image size in the text editor to better suit your product page layout.<br><br>
			If you want to display a youtube video on your product page, add in the YouTube video code, eg, https://youtu.be/ThisCodeHere into the box, or leave empty in you do not want to display a video.<br><br>
			A product description is required.<br>
			Product descriptions are used in all products and product category lists and within the front page slider. They are used to give site users a brief description on the product in the link.<br>
			Product descriptions are also used and displayed by search engines in search listings.<br>
			Descriptions should be limited to 160 characters or less.<br><br>
			Keywords and keyphrases should be seperated by a comma and should be used to best index that product. Keywords should reflect the content in the product page, so a product about garden equipment should have keywords similar to this:<br><br>
			gardening equipment, gardening tools, spade, shovel, wheelbarrow, compost bin, hoe, trowel, bucket<br><br>
			Keep keywords specific to your product.<br><br>
			Ticking the "save as draft" checkbox will save the product as a draft.<br><br>
			Products can be added to up to three categories. Click on the add button to add that product to the category.<br>
			Click the remove button to remove from the category. Categories can be created and edited via the products section (click Products in the header menu).<br><br>
			To create product options, different colour or size options, create the name of your option and extra price for that option and click "add". If the option has no extra cost, enter 0.00 into the cost field.<br><br>
			Clicking publish will publish your product or save as draft and return you to the products section, if there are any required fields that have not been filled, you will be returned to the error page where you will be able to add in the extra, missing info, without loosing the product content that you have already entered.<br>
		</p>
	  </div>
</div><br class="clearBoth" />