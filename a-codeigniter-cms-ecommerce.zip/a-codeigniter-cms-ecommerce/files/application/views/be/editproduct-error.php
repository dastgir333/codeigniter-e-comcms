 <?php $stocknumbers = array(
    'no limit'        => 'no limit',
    'out of stock'        => 'out of stock',
    '0'        => '0',
    '1'          => '1',
    '2'       => '2',
    '3'     => '3',
    '4'        => '4',
    '5'          => '5',
    '6'       => '6',
    '7'     => '7',
    '8'        => '8',
    '9'          => '9',
    '10'        => '10',
    '11'          => '11',
    '12'       => '12',
    '13'     => '13',
    '14'        => '14',
    '15'          => '15',
    '16'       => '16',
    '17'     => '17',
    '18'        => '18',
    '19'          => '19',
	'20'        => '20',
    '21'          => '21',
    '22'       => '22',
    '23'     => '23',
    '24'        => '24',
    '25'          => '25',
    '26'       => '26',
    '27'     => '27',
    '28'        => '28',
    '29'          => '29',
	'30'        => '30',
    '31'          => '31',
    '32'       => '32',
    '33'     => '33',
    '34'        => '34',
    '35'          => '35',
    '36'       => '36',
    '37'     => '37',
    '38'        => '38',
    '39'          => '39',
	'40'        => '40',
    '41'          => '41',
    '42'       => '42',
    '43'     => '43',
    '44'        => '44',
    '45'          => '45',
    '46'       => '46',
    '47'     => '47',
    '48'        => '48',
    '49'          => '49',
	'50'        => '50',
    '51'          => '51',
    '52'       => '52',
    '53'     => '53',
    '54'        => '54',
    '55'          => '55',
    '56'       => '56',
    '57'     => '57',
    '58'        => '58',
    '59'          => '59',
	'60'        => '60',
    '61'          => '61',
    '62'       => '62',
    '63'     => '63',
    '64'        => '64',
    '65'          => '65',
    '66'       => '66',
    '67'     => '67',
    '68'        => '68',
    '69'          => '69',
	'70'        => '70',
    '71'          => '71',
    '72'       => '72',
    '73'     => '73',
    '74'        => '74',
    '75'          => '75',
    '76'       => '76',
    '77'     => '77',
    '78'        => '78',
    '79'          => '79',
	'80'        => '80',
    '81'          => '81',
    '82'       => '82',
    '83'     => '83',
    '84'        => '84',
    '85'          => '85',
    '86'       => '86',
    '87'     => '87',
    '88'        => '88',
    '89'          => '89',
	'90'        => '90',
    '91'          => '91',
    '92'       => '92',
    '93'     => '93',
    '94'        => '94',
    '95'          => '95',
    '96'       => '96',
    '97'     => '97',
    '98'        => '98',
    '99'          => '99',
	'100'        => '100',
    '101'          => '101',
    '102'       => '102',
    '103'     => '103',
    '104'        => '104',
    '105'          => '105',
    '106'       => '106',
    '107'     => '107',
    '108'        => '108',
    '109'          => '109',
	'110'        => '110',
    '111'          => '111',
    '112'       => '112',
    '113'     => '113',
    '114'        => '114',
    '115'          => '115',
    '116'       => '116',
    '117'     => '117',
    '118'        => '118',
    '119'          => '119',
	'120'        => '120',
    '121'          => '121',
    '122'       => '122',
    '123'     => '123',
    '124'        => '124',
    '125'          => '125',
    '126'       => '126',
    '127'     => '127',
    '128'        => '128',
    '129'          => '129',
	'130'        => '130',
    '131'          => '131',
    '132'       => '132',
    '133'     => '133',
    '134'        => '134',
    '135'          => '135',
    '136'       => '136',
    '137'     => '137',
    '138'        => '138',
    '139'          => '139',
	'140'        => '140',
    '141'          => '141',
    '142'       => '142',
    '143'     => '143',
    '144'        => '144',
    '145'          => '145',
    '146'       => '146',
    '147'     => '147',
    '148'        => '148',
    '149'          => '149',
	'150'        => '150',
    '151'          => '151',
    '152'       => '152',
    '153'     => '153',
    '154'        => '154',
    '155'          => '155',
    '156'       => '156',
    '157'     => '157',
    '158'        => '158',
    '159'          => '159',
	'160'        => '160',
    '161'          => '161',
    '162'       => '162',
    '163'     => '163',
    '164'        => '164',
    '165'          => '165',
    '166'       => '166',
    '167'     => '167',
    '168'        => '168',
    '169'          => '169',
	'170'        => '170',
    '171'          => '171',
    '172'       => '172',
    '173'     => '173',
    '174'        => '174',
    '175'          => '175',
    '176'       => '176',
    '177'     => '177',
    '178'        => '178',
    '179'          => '179',
	'180'        => '180',
    '181'          => '181',
    '182'       => '182',
    '183'     => '183',
    '184'        => '184',
    '185'          => '185',
    '186'       => '186',
    '187'     => '187',
    '188'        => '188',
    '189'          => '189',
	'190'        => '190',
    '191'          => '191',
    '192'       => '192',
    '193'     => '193',
    '194'        => '194',
    '195'          => '195',
    '196'       => '196',
    '197'     => '197',
    '198'        => '198',
    '199'          => '199',
    ); ?>
 <script src="<?php echo base_url() . 'js/'; ?>addimage.js"></script> 
<script type="text/javascript">
		jQuery (function ($){
		
			$("#bar").hide();
			$('#btnUpload').click(function() {
			$("#bar").show({height: 'slow'});

		var userfile = $('#userfile').val();
		
		if (!userfile || userfile == 'Userfile') {
			alert('Please choose an image file');
			return false;
		}
	    var data;

		data = new FormData();
		data.append( 'userfile', $( '#userfile' )[0].files[0] );

		$.ajax({
			type: "POST",
			url: "<?php echo site_url('be/gallery/submit'); ?>",
			data: data,
			processData: false,  
			contentType: false,
			success: function(msg) {
				$('#bar2').html(msg);
			}
		});
		
		return false;
		});
	});
</script>
<div id="content">
 <div id="contentWrapper">
    <h2>edit product </h2>
	<div id="bar"><h4>please wait....</h4></div>
    <div id="bar2"></div>
	<div id="imagesButton">images</div>
      <div id="imagesBox">
	   <?php echo form_open_multipart('be/gallery/submit');
			echo form_upload('userfile', 'Userfile',  'id="userfile"');
			echo form_submit('btnUpload', 'Upload', 'id="btnUpload"');
			echo form_close();
		?>
	  <?php foreach($images as $imagebit) { ?>
	      <div class="images">
		  <img src="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>" />
		  <br class="clearBoth" />
		  <a href="<?php echo base_url() . 'images/gallery/thumbnails/' . $imagebit->url; ?>">small</a>
		  <a href="<?php echo base_url() . 'images/gallery/' . $imagebit->url; ?>">large</a>
	      </div>
	  <?php } ?>
	  <br class="clearBoth" />
	  </div>
	<?php echo form_open('be/editproduct/update');?>

  <div id="formA">
	<div class="formBoxes">
		<label for="name">product name *required</label>
		<input type="text" name="name" id="name" value="<?php echo $data['name']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="price">product price<?php echo ' (' . $currency . ')'; ?></label>
		<input type="text" name="price" id="price" value="<?php echo $data['price']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="weight">product weight</label>
		<input type="text" name="weight" id="weight" value="<?php echo $data['weight']; ?>" />
	</div>
	<br class="clearBoth" />
	<div class="formBoxes">
	 <label for="shippingname">shipping type: </label>
	   <select name="shippingname" id="shippingname">
			  <option value="<?php echo $data['shippingname']; ?>"><?php echo $data['shippingname']; ?></option>
		  <?php
			foreach($shippingname as $shipping) { ?>
			  <option value="<?php echo $shipping->name; ?>"><?php echo $shipping->name; ?></option>
		  <?php
			} ?>
		</select>
	<?php echo 'stock: ' . form_dropdown('stock', $stocknumbers, $data['stock']); ?>
	</div>
	<br class="clearBoth" />
	<div class="formBoxes">
	 <label for="download">download file: </label>
	   <select name="download" id="download">
			  <option value="<?php echo $data['download']; ?>"><?php echo $data['download']; ?></option>
		  <?php
			foreach($downloads as $part) { ?>
			  <option value="<?php echo $part->file; ?>"><?php echo $part->file; ?></option>
		  <?php
			} ?>
		</select>
	</div>
	<br class="clearBoth" />
	<div class="formBoxes">
		<label for="content">product content here *required</label>
		<textarea rows="25" cols="114" id='txtEditor' name="content"  ><?php echo $data['content']; ?></textarea>
	</div>	
  </div>
  <div id="formB">
	<div class="formBoxes">
		<label for="videolink">YouTube video code, eg, https://youtu.be/ThisCodeHere</label><br />
		https://youtu.be/<input type="text" name="videolink" id="videolink" value="<?php echo $data['videolink']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="description">description *required</label>
		<input type="text" name="description" id="description" value="<?php echo $data['description']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="keywords">keywords *required</label>
		<input type="text" name="keywords" id="keywords" value="<?php echo $data['keywords']; ?>" />
	</div>
	<div class="formBoxes">
	<p>product options<br>
	If your option has no extra cost, enter 0.00 into the cost field</p>
		<input type="hidden" name="options" id="options" value="<?php echo $data['options']; ?>" />
		<label for="optionsone">option name: </label>
		<input type="text" name="optionsone" id="optionsone" value="" />
		<label for="optionstwo">cost:<?php echo ' (' . $currency . ')'; ?></label>
		<input type="text" name="optionstwo" id="optionstwo" value="" />
	<br class="clearBoth" />
		<div class="buttonadd">
		<a id="buttonadd" href="#">add</a>
		</div>
		<div class="buttonclear">
		<a id="buttonclear" href="#">clear</a>
		</div>
	<div id="display">
	<div class="displaylist"></div>
	<?php if($data['options'] != null){ 
	$productoptions = explode( ';', $data['options']);
	foreach($productoptions as $po){	
	$optionparts = explode(',', $po); 
		if($optionparts['0'] != null){ ?>
	<p><?php echo 'option: ' .  $optionparts['0'] . ', price: ' . $optionparts['1'];?></p>
	<?php   }
		}
	}?>
	</div>
	<br class="clearBoth" />
	</div>
	   <script type="text/javascript">
	 jQuery (function ($){
		$('.buttonadd #buttonadd').click(function(event) { 
		event.preventDefault();
		one = $('#optionsone').val();
		two = $('#optionstwo').val();
        $('#options').val($('#options').val()+one+','+two+';'); 
        $('#display .displaylist').after('<p>option: '+one+', price: '+two+'</p>'); 
       });
	   $('.buttonclear #buttonclear').click(function(event) { 
		event.preventDefault();
        $('#options').val(''); 
        $('#display p').remove(); 
       });
   }); 
   </script>
	</div>
	

		<div id="formC">
	<label for="trash">save as draft</label>
    <input type="checkbox" name="trash" value="2"> 
    <div class="formBoxes"></div>
	<input type="hidden" name="category" id="category" value="<?php echo $data['category'] ?>" />
	<input type="hidden" name="id" id="id" value="<?php echo $data['id'] ?>" />
		<input type="submit"  value="save"/>
	</div>
	<?php echo form_close(); ?>
		<div id="catlist">
		<h3>Category</h3>
	
	<?php 
	$n = 0;
	if(isset($catlist)) {
        	foreach($catlist as $catpart) {
	    $n++;
		$array = explode(',', $data['category']);
		$check = $catpart->slug;
	?>
   <script type="text/javascript">
	 jQuery (function ($){
		$('#added<?php echo $n;?>').hide();
		$('.catlist<?php echo $n;?>').click(function(event) { 
		event.preventDefault();
        text = '<?php echo $catpart->slug; ?>';
		stuff = ',';
        $('#category').val($('#category').val()+text+stuff); 
        $('.catlist<?php echo $n;?>').hide('fast');
        $('#added<?php echo $n;?>').delay(400).show('fast');
       });
   }); 
   </script>
   <?php if(in_array($check, $array)) { ?>
   <div class="catsingle">
		   <?php echo '<div class="catlist' . $n . '" id="cl"><a href="#">add</a></div>'; ?>  
		 <div class="added" id="added<?php echo $n;?>"><?php echo 'remove'; ?></div>
		 <div class="catname"><?php echo $catpart->name; ?><br />
		 <?php
		 if($catpart->sub && $catpart->sub != 'none') {
		 echo 'sub of: ' . $catpart->sub; 
		 }
		 ?>
		 </div>
    </div>
	<script type="text/javascript">
   jQuery (function ($){
    $('.catlist<?php echo $n;?>').hide();
    $('#added<?php echo $n;?>').delay(100).show();
   });
 </script>
   <?php } else { ?>
   <div class="catsingle">
		   <?php echo '<div class="catlist' . $n . '" id="cl"><a href="#">add</a></div>'; ?>  
		 <div class="added" id="added<?php echo $n;?>"><?php echo 'remove'; ?></div>
		 <div class="catname"><?php echo $catpart->name; ?><br />
		 <?php
		 if($catpart->sub && $catpart->sub != 'none') {
		 echo 'sub of: ' . $catpart->sub; 
		 }
		 ?>
		 </div>
    </div>
   <?php } ?>
		 <script type="text/javascript">
    jQuery (function ($){
   $('#added<?php echo $n;?>').click(function() {
	
   $('#category').val($('#category').val().replace('<?php echo $catpart->slug; ?>,', '')); 
	$('#added<?php echo $n;?>').fadeOut('fast');
	$('.catlist<?php echo $n;?>').delay(400).show('fast');
});
});
		   </script>  
<?php }
     } ?>
	 </div>
<br class="clearBoth" />
	</div>
</div> <br class="clearBoth" />