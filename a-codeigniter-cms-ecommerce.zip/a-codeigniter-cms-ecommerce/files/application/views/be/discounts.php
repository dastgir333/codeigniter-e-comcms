<div id="content">
	<div id="contentWrapper">
		<h2>discounts</h2>
		<div id="pagesButtons">
			<a href="<?php echo base_url() . 'be/discounts/trash' ?>">trash</a>
			<a href="<?php echo base_url() . 'be/discounts/create' ?>">create new discount code</a>
		</div>
		<?php if(isset($discounts)){ ?>
			<?php foreach($discounts as $part){ ?>
				<div class="box1Container">
				   <div class="box1">
					<?php echo 'name:' . $part->name; ?>
				   </div>
					<div class="box2">
						<?php echo $part->code; ?>
					   <div class="pageEdit"><a href="<?php echo base_url() . 'be/discounts/edit/' . $part->id; ?>">edit</a></div>
					   <div class="pageEdit"><a href="<?php echo base_url() . 'be/discounts/settrash/' . $part->id; ?>">trash</a></div>
					</div>
				</div> 
			<?php } ?>
		<?php } ?>
		
	</div><br class="clearBoth" />
</div>