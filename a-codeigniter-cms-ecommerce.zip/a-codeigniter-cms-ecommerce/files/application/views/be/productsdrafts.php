
    <div id="content">
	 <div id="contentWrapper">
	     <h2>draft products</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/products' ?>">products</a>
		 <a href="<?php echo base_url() . 'be/products/trash' ?>">trash</a>
		 </div>
		 <div id="catNavButtons">
		 <a href="<?php echo base_url() . 'be/productcategories' ?>">categories</a>
		 <a href="<?php echo base_url() . 'be/createproductcat' ?>">create new category</a>
		 </div>
	    <?php foreach($productsdata['results'] as $row){ ?>
	   <div class="box1Container">
	           <div class="box1">
	            <?php echo $row->name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->description; ?>
		         </div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editproduct/edit/' . $row->id; ?>">edit</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/products/setrestore/' . $row->id; ?>">restore</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/products/settrash/' . $row->id; ?>">trash</a></div>
			</div> 
	       <?php } ?>
		    <div id="pagesLinks">
		   <?php echo $productsdata['links']; ?>
		   </div>
	 </div>
	</div>
	<br class="clearBoth" />