

    <div id="content">
        <div id="contentWrapper">
	<h2>dashboard</h2>
	       <div id='dashbox1'>
		   <h3>recent posts</h3>
		   <ul>
		   <?php foreach($dashposts as $postbit) { ?>
		   <li><a href="<?php echo base_url() . 'post/' . $postbit->slug; ?>" target="_blank"><?php echo $postbit->name; ?></a>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editpost/edit/' . $postbit->id; ?>">edit</a></div></li>
		  <?php } ?>
		   </ul>
		  <div class="viewAll"><a href="<?php echo base_url() . 'be/posts/'; ?>">view all</a></div>
		   </div>
		   
		   <div id='dashbox2'>
		   <h3>pages</h3>
		   <ul>
		   <?php foreach($dashpages as $pagebit) { ?>
		   <li><a href="<?php echo base_url() . $pagebit->slug; ?>" target="_blank"><?php echo $pagebit->name; ?></a>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editpage/edit/' . $pagebit->id; ?>">edit</a></div></li>
		   <?php } ?>
		  </ul>
		  <div class="viewAll"><a href="<?php echo base_url() . 'be/pages/'; ?>">view all</a></div>
		   </div>
		   
		   <div id='dashbox3'>
		   <h3>recent products</h3>
		   <ul>
		   <?php foreach($dashproducts as $productbit) { ?>
		   <li><a href="<?php echo base_url() . 'shop/' . $productbit->slug; ?>" target="_blank"><?php echo $productbit->name; ?></a>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editproduct/edit/' . $productbit->id; ?>">edit</a></div></li>
		  <?php } ?>
		    </ul>
		  <div class="viewAll"><a href="<?php echo base_url() . 'be/products/'; ?>">view all</a></div>
		  </div>
		   
		   <div id='dashbox4'>
		   <h3>messages</h3>
		   <ul>
		   <?php foreach($dashmessages as $msgbit) { ?>
		   <li><?php echo $msgbit->email . ' ' . $msgbit->date; ?>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/messages/view/' . $msgbit->id; ?>">view</a></div></li>
		  <?php } ?>
		    </ul>
		  <div class="viewAll"><a href="<?php echo base_url() . 'be/messages/'; ?>">view all</a></div>
		  </div>
	    </div>
		<br class='clearBoth' />
	</div>