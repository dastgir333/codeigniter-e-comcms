<div id="content">
        <div id="contentWrapper">
			<h2>shipping trash</h2>
			<div id="pagesButtons">
			<a href="<?php echo base_url() . 'be/shipping/' ?>">shipping</a>
			<a href="<?php echo base_url() . 'be/shipping/create' ?>">create zone</a>
		 </div>
			<?php if(isset($shippingrules)){ ?>
				<?php foreach($shippingrules as $part){ ?>
					<div class="box1Container">
					   <div class="box1">
						<?php echo $part->name . '<br />Zone:' . $part->zone; ?>
					   </div>
						<div class="box2">
							<?php echo $part->country; ?>
						</div>
						   <div class="pageEdit"><a href="<?php echo base_url() . 'be/shipping/edit/' . $part->id; ?>">edit</a></div>
						   <div class="pageEdit"><a href="<?php echo base_url() . 'be/shipping/setrestore/' . $part->id; ?>">restore</a></div>
						   <div class="pageEdit"><a href="<?php echo base_url() . 'be/shipping/setdelete/' . $part->id; ?>">delete</a></div>
					</div> 
				<?php } ?>
			<?php } ?>
			
		</div><br class="clearBoth" />
</div>