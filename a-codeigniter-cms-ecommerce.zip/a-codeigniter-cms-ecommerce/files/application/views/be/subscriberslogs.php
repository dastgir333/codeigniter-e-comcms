    <div id="content">
	  <div id="contentWrapper">
	     <h2>Customer logs</h2>
		 <div id="pagesButtons">
		 </div>
	        <?php foreach($sublogs['results'] as $row){ ?>
			<div class="box1Container">
			   <?php echo $row->action; ?>
	           <div class="box1">
	            <?php echo 'ID:' . $row->customerid . ', ' . $row->email; ?>
		       </div>
		        <div class="box2">
	            <?php echo 'IP address:' . $row->ip_address; ?><br>
	            <?php echo 'User agent: ' . $row->user_agent; ?><br>
	            <?php echo 'Date:' . $row->date; ?>
		         </div>
			</div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $sublogs['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />