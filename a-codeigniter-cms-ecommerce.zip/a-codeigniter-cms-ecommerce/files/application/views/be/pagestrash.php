

    <div id="content">
	  <div id="contentWrapper">
	     <h2>trashed pages</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/pages' ?>">pages</a>
		 <a href="<?php echo base_url() . 'be/pages/drafts' ?>">drafts</a>
		 </div>
	        <?php foreach($pagesdata['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo $row->name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->description; ?>
		         </div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editpage/edit/' . $row->id; ?>">edit</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/pages/setrestore/' . $row->id; ?>">restore</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/pages/setdraft/' . $row->id; ?>">draft</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/pages/setdelete/' . $row->id; ?>">delete</a></div>
			</div> 
	       <?php } ?>
		   <div id="pagesLinks">
		   <?php echo $pagesdata['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />