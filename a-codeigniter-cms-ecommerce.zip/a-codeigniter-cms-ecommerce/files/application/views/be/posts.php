
    <div id="content">
	  <div id="contentWrapper">
	     <h2>posts</h2>
		 <div id="pagesButtons">
		 <a href="<?php echo base_url() . 'be/posts/drafts' ?>">drafts</a>
		 <a href="<?php echo base_url() . 'be/posts/trash' ?>">trash</a>
		 <a href="<?php echo base_url() . 'be/comments' ?>">comments</a>
		 </div>
		 <div id="catNavButtons">
		 <a href="<?php echo base_url() . 'be/postcategories' ?>">categories</a>
		 <a href="<?php echo base_url() . 'be/createpostcat' ?>">create new category</a>
		 </div>
	        <?php foreach($postsdata['results'] as $row){ ?>
			<div class="box1Container">
	           <div class="box1">
	            <?php echo $row->name; ?>
		       </div>
			  
		        <div class="box2">
	            <?php echo $row->description; ?>
				</div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/editpost/edit/' . $row->id; ?>">edit</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/posts/setdraft/' . $row->id; ?>">draft</a></div>
		   <div class="pageEdit"><a href="<?php echo base_url() . 'be/posts/settrash/' . $row->id; ?>">trash</a></div>
		        
			</div> 
	       <?php } ?>
		    <div id="pagesLinks">
		   <?php echo $postsdata['links']; ?>
		   </div>
	  </div>
	</div>
	<br class="clearBoth" />