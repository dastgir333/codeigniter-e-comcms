 <div id="content">
  <?php foreach($userdetails as $part){ ?>
			 <h4>edit contact details</h4>
			   <div id="userForm">
			<?php echo form_open('checkout/customer_update');?>
			
				 <label for="first_name">first name </label>
				 <input type="text" name="first_name" id="first_name" value="<?php echo $part->first_name; ?>" />
				 
				 <label for="last_name">last name </label>
				 <input type="text" name="last_name" id="last_name" value="<?php echo $part->last_name; ?>" />
				 
				 <label for="email">email </label>
				 <input type="text" name="email" id="email" value="<?php echo $part->email; ?>" />
				 
				 <input type="hidden" name="id" id="id" value="<?php echo $part->id; ?>" />
				 
				 <label for="phone">phone </label>
				 <input type="text" name="phone" id="phone" value="<?php echo $part->phone; ?>" />
				 
				 <label for="street_one">street </label>
				 <input type="text" name="street_one" id="street_one" value="<?php echo $part->street_one; ?>" />
				 
				 <label for="street_two">street (second line) </label>
				 <input type="text" name="street_two" id="street_two" value="<?php echo $part->street_two; ?>" />
				 
				 <label for="city">city </label>
				 <input type="text" name="city" id="city" value="<?php echo $part->city; ?>" />
				 
				 <label for="county">county </label>
				 <input type="text" name="county" id="county" value="<?php echo $part->county; ?>" />
				 
				 <label for="postcode">postcode </label>
				 <input type="text" name="postcode" id="postcode" value="<?php echo $part->postcode; ?>" />
				 
				 <label for="country">country </label>
				 <input type="text" name="country" id="country" value="<?php echo $part->country; ?>" />
				 
				<input id="submitButton" type="submit"  value="save"/>
			<?php echo form_close(); ?>
			   </div>
		 <?php } ?>
  </div>
  