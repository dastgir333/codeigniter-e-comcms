<div id="content">
	<h5>Logged in as: <?php echo $this->session->userdata('email'); ?></h5>
	<p>Thank you for your order</p>

</div> <br class="clearBoth" />