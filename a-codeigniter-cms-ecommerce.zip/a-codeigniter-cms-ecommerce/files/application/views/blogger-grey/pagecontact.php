  <div id="content">

<?php 
if(isset($formemail)) {
 $emailaddress = $formemail;
} else {
 $emailaddress = '';
}
if(isset($formmessage)) {
 $messagetext = $formmessage;
} else {
 $messagetext = '';
}
?>
 	<?php if(isset($data['records'])) : foreach($data['records'] as $row) : ?>
	
 
 <?php $address = base_url() . '/images/smileys/';
$str = $row->content; 
$str = parse_smileys($str, $address); 
echo $str; ?>
 
 	<?php endforeach; ?>

	<?php else : ?>	
		<?php redirect('mainpage');?>
	<?php endif; ?>
	
<?php echo form_open('contact/send');?>

    <p><label for="email">email address</label>
	<?php 
	$data1 = array(
              'name'        => 'email',
              'id'          => 'email',
              'value'       => $emailaddress,
            );

echo form_input($data1);
	?></p>
	<label for="message">enter your message here</label><br />
	<?php 
	$data2 = array(
              'name'        => 'message',
              'id'          => 'message',
              'value'       => $messagetext,
              'rows'        => '15',
              'cols'          => '70',
            );

echo form_textarea($data2);
	?> <div id="capture">
	<p><?php foreach($capturedata as $image) {
	echo '<img src="' . base_url() . 'images/' . $image->one . '" alt="capture" />';
	?>
	</p>
	
	<p><label for="capture1">capture field </label>
	<?php 
	$data3 = array(
              'name'        => 'capture1',
              'id'          => 'capture1',
            );

echo form_input($data3);
echo 'why is there a capture field?<br />
      It is to ensure that you are a real person sending a real enquiry.';
	?></p>
	<input type="hidden" name="capture2" id="capture2" value="<?php echo $image->one; ?>" />
	<?php 
       }
	
	?>
	</div>
		<?php echo form_submit('submit', 'Send'); ?>
	
	<?php echo form_close(); ?>
  </div>	 
