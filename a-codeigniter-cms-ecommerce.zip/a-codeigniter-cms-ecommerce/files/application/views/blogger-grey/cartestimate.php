<div id="content">
   <div id="estimateBox">
   <h3>Estimate shipping costs</h3>
    <?php echo form_open('cart/estimate_result');?>
	<label for="postcode">postcode</label>
	<input type="text" name="postcode" id="postcode"  />
	<label for="country">country</label>
	<input type="text" name="country" id="country"  />
		<input type="submit"  value="estimate"/>
	<?php echo form_close(); ?>
 
	</div>
	
</div>