<div id="content">    
	<h3><?php echo $usererror . '<br>'; ?></h3>
	  <div id="newUser">
		<h4>Create a new account</h4>
	<?php echo form_open('customer/create_user'); ?>
	<div class="formBoxes">
		<label for="email">Email address *required</label>
		<input type="text" name="email" id="email" class="formBox" value="<?php echo $data['email']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="phone">Phone number *required</label>
		<input type="text" name="phone" id="phone" class="formBox" value="<?php echo $data['phone']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="first_name">First name *required</label>
		<input type="text" name="first_name" id="first_name" class="formBox" value="<?php echo $data['first_name']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="last_name">Surname *required</label>
		<input type="text" name="last_name" id="last_name" class="formBox" value="<?php echo $data['last_name']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="street_one">Address *required</label>
		<input type="text" name="street_one" id="street_one" class="formBox" value="<?php echo $data['street_one']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="street_two">Address (line two)</label>
		<input type="text" name="street_two" id="street_two" class="formBox" value="<?php echo $data['street_two']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="city">City or town *required</label>
		<input type="text" name="city" id="city" class="formBox" value="<?php echo $data['city']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="county">County *required</label>
		<input type="text" name="county" id="county" class="formBox" value="<?php echo $data['county']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="postcode">Postcode *required</label>
		<input type="text" name="postcode" id="postcode" class="formBox" value="<?php echo $data['postcode']; ?>" />
	</div>
	<div class="formBoxes">
		<label for="country">Country *required</label>
		<select name="country" id="country">
		 <option value="<?php echo $data['country']; ?>"><?php echo $data['country']; ?></option>
		  <?php  $country = 'none';
		  foreach($countriesdata as $part) { 
			if($country != $part->country && $part->country != null){?>
			  <option value="<?php echo $part->country; ?>"><?php echo $part->country; ?></option>
			<?php $country = $part->country;
				}
			} ?>
		</select>
	</div>
	<div class="formBoxes">
		<label for="password">create a password *required</label>
		<input type="password" name="password" id="password" class="formBox" value="" />
	</div>
	<input type="submit"  value="Create account"/>
	<?php echo form_close(); ?>
		<br class="clearBoth" />
      </div>
   </div> <br class="clearBoth" />
   