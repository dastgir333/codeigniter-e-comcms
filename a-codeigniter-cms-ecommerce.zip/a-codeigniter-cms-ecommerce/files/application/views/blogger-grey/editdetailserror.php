 <div id="content">
			 <h4>edit contact details</h4>
			 <h5><?php echo $usererror; ?></h5>
			   <div id="userForm">
			<?php echo form_open('checkout/customer_update');?>
			
				 <label for="first_name">first name </label>
				 <input type="text" name="first_name" id="first_name" value="<?php echo $user['first_name']; ?>" />
				 
				 <label for="last_name">last name </label>
				 <input type="text" name="last_name" id="last_name" value="<?php echo $user['last_name']; ?>" />
				 
				 <label for="email">email </label>
				 <input type="text" name="email" id="email" value="<?php echo $user['email']; ?>" />
				 
				 <input type="hidden" name="id" id="id" value="<?php echo $user['id']; ?>" />
				 
				 <label for="phone">phone </label>
				 <input type="text" name="phone" id="phone" value="<?php echo $user['phone']; ?>" />
				 
				 <label for="street_one">street </label>
				 <input type="text" name="street_one" id="street_one" value="<?php echo $user['street_one']; ?>" />
				 
				 <label for="street_two">street (second line) </label>
				 <input type="text" name="street_two" id="street_two" value="<?php echo $user['street_two']; ?>" />
				 
				 <label for="city">city </label>
				 <input type="text" name="city" id="city" value="<?php echo $user['city']; ?>" />
				 
				 <label for="county">county </label>
				 <input type="text" name="county" id="county" value="<?php echo $user['county']; ?>" />
				 
				 <label for="postcode">postcode </label>
				 <input type="text" name="postcode" id="postcode" value="<?php echo $user['postcode']; ?>" />
				 
				 <label for="country">country </label>
				 <input type="text" name="country" id="country" value="<?php echo $user['country']; ?>" />
				 
				<input id="submitButton" type="submit"  value="save"/>
			<?php echo form_close(); ?>
			   </div>
  </div>
  