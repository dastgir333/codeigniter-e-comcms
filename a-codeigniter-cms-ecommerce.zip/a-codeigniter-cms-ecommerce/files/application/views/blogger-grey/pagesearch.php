<div id="content">

    <?php if(isset($data)){ 
	         foreach($data as $part){ ?>
	<div id="searchContent"><?php echo $part->content; ?></div>
	       <?php } 
	}  ?>
   <div id="searchBox">
    <?php echo form_open('search/result');?>
	<label for="searchfield">search keywords</label>
	<input type="text" name="searchfield" id="searchfield"  />
		<input type="submit"  value="search"/>
	<?php echo form_close(); ?>
 
	</div>
	
</div>