<?php if(isset($box1)){ ?>
			   <?php foreach($box1 as $b1part){ ?>
			   <?php 		   
			$linkurl = base_url() . 'post/';
		   if(isset($b1part->slug)) {
		    $linkslug = $b1part->slug;
		   } else {
		   $linkslug = '';
		   }
     		   echo '<a href="' . $linkurl .  $linkslug . '">';
			   $imagetag1 = '<img';
			   $imagetagpos1 = strpos($b1part->content, $imagetag1);
			   $imagetag2 = '/>';
			   $imagetag3 = '">';
			   $imagetagpos2 = strpos($b1part->content, $imagetag2);
			   $imagetagpos2a = strpos($b1part->content, $imagetag3);
			   if($imagetagpos2 === FALSE) {
			   $imagetagpos3 = strpos($b1part->content, $imagetag3, $imagetagpos1);
			   } 
			   if($imagetagpos2a === FALSE){
			   $imagetagpos3 = strpos($b1part->content, $imagetag2, $imagetagpos1);
			   }
			   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
			   $boximage = substr($b1part->content, $imagetagpos1, $imagelength) ;
			   if($imagelength > 5){
			    echo '<p>' . $boximage . '</p></a>';
				} else {
				echo '<p><img src="' . base_url() . 'images/gallery/thumbnails/nopic.png' . '" /></p></a>';
				}
			    ?>
				<?php echo $b1part->title; ?>
			   <?php } ?>
			<?php } ?>