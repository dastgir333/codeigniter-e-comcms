<?php if(isset($box3)){ ?>
			   <?php foreach($box3 as $b3part){ ?>
			   <?php 		   
			$linkurl = base_url() . 'shop/';
		   if(isset($b3part->slug)) {
		    $linkslug = $b3part->slug;
		   } else {
		   $linkslug = '';
		   }
     		   echo '<a href="' . $linkurl .  $linkslug . '">';
			   $imagetag1 = '<img';
			   $imagetagpos1 = strpos($b3part->content, $imagetag1);
			   $imagetag2 = '/>';
			   $imagetag3 = '">';
			   $imagetagpos2 = strpos($b3part->content, $imagetag2, $imagetagpos1);
			   $imagetagpos2a = strpos($b3part->content, $imagetag3, $imagetagpos1);
			   if($imagetagpos2 === FALSE) {
			   $imagetagpos3 = strpos($b3part->content, $imagetag3, $imagetagpos1);
			   } 
			   if($imagetagpos2a === FALSE){
			   $imagetagpos3 = strpos($b3part->content, $imagetag2, $imagetagpos1);
			   }
			   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
			   $boximage = substr($b3part->content, $imagetagpos1, $imagelength) ;
			   if($imagelength > 5){
			    echo '<p>' . $boximage . '</p></a>';
				} else {
				echo '<p><img src="' . base_url() . 'images/gallery/thumbnails/nopic.png' . '" /></p></a>';
				}
			    ?>
				<?php echo $b3part->title; ?>
			   <?php } ?>
			<?php } ?>