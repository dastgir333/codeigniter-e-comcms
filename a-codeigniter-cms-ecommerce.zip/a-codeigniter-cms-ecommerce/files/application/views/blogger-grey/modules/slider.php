<?php if(isset($slider)){ ?>
			   <?php foreach($slider as $sliderpart){ ?>
			   <?php
			   if(isset($sliderpart->type)){
				   if($sliderpart->type == 'custom'){
			$linkurl = '';
				   }
			   } elseif($check == 'posts') {
			$linkurl = base_url() . 'post/';
			   } else {
			$linkurl = base_url() . 'shop/';
			   }
		   if(isset($sliderpart->slug)) {
		    $linkslug = $sliderpart->slug;
		   } else {
		   $linkslug = '';
		   }
     		   echo '<div class="sc"><a href="' . $linkurl .  $linkslug . '">';
			   $imagetag1 = '<img';
			   $imagetagpos1 = strpos($sliderpart->content, $imagetag1);
			   $imagetag2 = '/>';
			   $imagetag3 = '">';
			   $imagetagpos2 = strpos($sliderpart->content, $imagetag2);
			   $imagetagpos2a = strpos($sliderpart->content, $imagetag3);
			   if($imagetagpos2 === FALSE) {
			   $imagetagpos3 = strpos($sliderpart->content, $imagetag3, $imagetagpos1);
			   } 
			   if($imagetagpos2a === FALSE){
			   $imagetagpos3 = strpos($sliderpart->content, $imagetag2, $imagetagpos1);
			   }
			   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
			   $boximage = substr($sliderpart->content, $imagetagpos1, $imagelength) ;
			   if($imagelength > 5){
			    echo '<p>' . $boximage . '</p></a>';
				} else {
				echo '<p><img src="' . base_url() . 'images/gallery/thumbnails/nopic.png' . '" /></p></a>';
				}
			    ?>
				  <div class="sctext">
				  <?php echo '<a href="' . $linkurl .  $linkslug . '">'; ?>
				  <?php echo '<h2>' . $sliderpart->title . '</h2>'; 
				  if(isset($sliderpart->price)){ echo '<h3>' . $currency  . $sliderpart->price . '</h3>'; } ?>
				  <br />
				  <?php echo $sliderpart->description . '</a>'; ?>
				  </div>
				</div>
			   <?php } ?>
			<?php } ?>