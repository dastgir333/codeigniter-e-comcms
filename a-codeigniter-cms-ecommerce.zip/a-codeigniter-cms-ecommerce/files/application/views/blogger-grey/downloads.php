<div id="content">
   <div class="button"><a href="<?php echo base_url() . 'account'; ?>">Account</a></div>
   <h2>downloads</h2>	
 	<?php foreach($downloads['results'] as $row) { ?>
		<div class="downloads">
			 <h3><?php echo $row->invoice; ?></h3>
			 <div class="downloadsFile">
				<a href="<?php echo base_url() . 'download/item/' . $row->invoice . '_' . $row->download; ?>"><b><?php echo $row->download; ?></b><img src="<?php echo base_url() . 'images/default/download-icon.png' ?>" width="50px" title="download file" alt="download file" /></a>
			 </div>	
			  <div class="downloadsInfo"> 
				<?php echo $currency . $row->price; ?><br />
			 </div>
		 </div>
 	<?php } ?>
	<div id="pageLinks">
          <?php echo $downloads['links']; ?>
     </div>
<br class="clearBoth" />
</div>