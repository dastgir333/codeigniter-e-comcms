
<div id="content">
 
  <h2>all products</h2>	

 	<?php foreach($results as $row) { ?>
<?php
   ?>
 
 <?php //content here ?>
 <div class="products">
 <h2><a href="<?php echo base_url() . 'shop/' . $row->slug; ?>"><?php echo $row->name; ?></a></h2>
 <h3><?php echo $currency . $row->price; ?></h3>
  <div class="product-image">
 <?php		
		$linkurl = base_url() . 'shop/';
		  
	   if(isset($row->slug)) {
		$linkslug = $row->slug;
	   } else {
	   $linkslug = '';
	   }
	   $imagetag1 = '<img';
	   $imagetagpos1 = strpos($row->content, $imagetag1);
	   $imagetag2 = '/>';
	   $imagetag3 = '">';
	   $imagetagpos2 = strpos($row->content, $imagetag2, $imagetagpos1);
	   $imagetagpos2a = strpos($row->content, $imagetag3, $imagetagpos1);
	   if($imagetagpos2 === FALSE) {
	   $imagetagpos3 = strpos($row->content, $imagetag3, $imagetagpos1);
	   } 
	   if($imagetagpos2a === FALSE){
	   $imagetagpos3 = strpos($row->content, $imagetag2, $imagetagpos1);
	   }
	   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
	   $boximage = substr($row->content, $imagetagpos1, $imagelength) ;
	   
		echo '<a href="' . $linkurl .  $linkslug . '">';
	   if($imagelength > 5){
		echo '<p>' . $boximage . '</p></a>';
		} else {
		echo '<p><img src="' . base_url() . 'images/gallery/thumbnails/nopic.png' . '" /></a>';
		}
			    ?>
 </div>
  <div class="rpinner"> 
 <p><?php echo $row->description; ?></p>
 </div>
 </div>

 
 
<?php // end of content ?>

 	<?php } ?>
	<div id="pageLinks">
           <p><?php echo $links; ?></p>
     </div>
<br class="clearBoth" />
</div>