<div id="content">
 <?php foreach($data as $row) { ?>
	 <?php echo '<h2>' . $row->name . '</h2>'; ?>
	 <?php echo '<h3>' . $currency . $row->price , '</h3>'; ?>
	 <div id="productContent">
		 <?php 
		 $check = $this->uri->segment(2);
		 if ($row->slug != $check) { redirect('index.php');}
		 else {
		$address = base_url() . 'images/smileys/';
		$str = $row->content; 
		$str = parse_smileys($str, $address); 
		echo $str;
			  }
		 ?>
	 </div>
  <div id="addcartitem">
   <?php echo $row->name;?>
		 <?php echo form_open('shop/add_item');?>
		 <?php if($row->stock == 'no limit'){ $max = '10'; 
		 } elseif($row->stock == 'out of stock') {
			$max = '0'; 
		 } else { 
			$max = $row->stock; 
		 } ?>
			<?php if($row->download == 'none' or $row->download == ''){ ?>
				<label for="quantity">quantity (max <?php echo $max ?>)</label>
				<input type="number" name="item-quantity" id="item-quantity" min="1" max="<?php echo $max ?>" value="1" />
			<?php } else { ?>
				<input type="hidden" name="item-quantity" id="item-quantity" value="1" />
			<?php } ?>
			<?php 
	                  $imagetag1 = '<img';
			   $imagetagpos1 = strpos($row->content, $imagetag1);
			   $imagetag2 = '/>';
			   $imagetag3 = '">';
			   $imagetagpos2 = strpos($row->content, $imagetag3, $imagetagpos1);
			   if($imagetagpos2 > 110) {
			   $imagetagpos3 = strpos($row->content, $imagetag3, $imagetagpos1);
			   } else {
			   $imagetagpos3 = strpos($row->content, $imagetag2, $imagetagpos1);
			   }
			   $imagelength =  $imagetagpos3 - $imagetagpos1 + 2;
			   $boximage = substr($row->content, $imagetagpos1, $imagelength) ;
			   if($imagelength > 5){
			   $productimage = $boximage;
				} else {
				$productimage = '';
				}
			?>
			<input type="hidden" name="itemimage" id="itemimage"  value='<?php echo $productimage; ?>' />
			<input type="hidden" name="item-id" id="item-id" value="<?php echo $row->id; ?>" />
			<input type="hidden" name="item-price" id="item-price" value="<?php echo $row->price; ?>" />
			<input type="hidden" name="item-name" id="item-name" value="<?php echo $row->name; ?>"/>
			<input type="hidden" name="item-weight" id="item-weight" value="<?php echo $row->weight; ?>"/>
			<input type="hidden" name="item-shippingname" id="item-shippingname" value="<?php echo $row->shippingname; ?>"/>
			<input type="hidden" name="item-download" id="item-download" value="<?php echo $row->download; ?>"/>
			<?php if($row->options != null){ 
						if($row->download == '' or $row->download == 'none'){ ?>
			<br class="clearBoth" />
			<label for="item-options">select option: </label>
			   <select name="item-options" id="item-options">
				  <?php
				  $options = explode(';', $row->options);
					foreach($options as $optionpart) { ?>
						<?php $op = explode(',', $optionpart); 
						if($op['0'] != null){ ?>
					  <option value="<?php echo $op['0'] . ',' . $op['1'];?>"><?php echo $op['0'];
					  if($op['1'] != '0.00'){echo ', +' . $currency . $op['1'];} ?></option>
					  <?php }
						} 
					}?>
				</select>
				<br class="clearBoth" />
			<?php } ?>
			<br class="clearBoth" />
			<?php if($max == '0'){ echo 'out of stock'; } else { ?>
				<?php $cartcheck = 'no';
				foreach($this->cart->contents() as $items){ 
					if($items['download'] != 'none' && $items['download'] != ''){
							$cartcheck = 'yes';
					} 
				} ?>
				<?php if($cartcheck == 'yes' && $row->download != 'none'){ echo 'already added to cart'; } else { ?>
				<input id="addToCart" type="submit"  value="add to cart"/> 
				<?php } 
			}?>
			<?php echo form_close(); ?>
	
	</div>
 <br class="clearBoth" />
       <?php if($row->videolink != ''){ ?>
<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $row->videolink; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	    <?php } ?>
 	<?php } ?>
	
	</div>