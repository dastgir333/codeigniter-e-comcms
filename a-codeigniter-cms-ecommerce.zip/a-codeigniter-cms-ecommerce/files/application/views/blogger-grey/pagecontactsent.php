  <div id="content">
 

 	
	<h2>your message has been sent</h2>
	<p>Thank you for contacting us. We will reply as soon as we can.</p>
	
  </div>