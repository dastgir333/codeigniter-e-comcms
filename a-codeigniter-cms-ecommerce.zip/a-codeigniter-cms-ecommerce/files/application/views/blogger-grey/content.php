       
	   <div id="content">
	   
	  <?php foreach($pagedata as $row) { ?>
	   
	   <h2><?php echo $row->title; ?></h2>
	   
	   <p><?php echo $row->content; ?></p>
	  
	  <?php } ?>


	   </div>