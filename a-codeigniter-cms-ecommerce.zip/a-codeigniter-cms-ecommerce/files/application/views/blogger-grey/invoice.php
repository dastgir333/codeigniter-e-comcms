<div id="content">
   <div class="button"><a href="<?php echo base_url() . 'account'; ?>">Account</a></div>
   <br class="clearBoth" />
   <div class="button"><a href="<?php echo base_url() . 'account/downloads'; ?>">Downloads</a></div>
   <h2>invoice</h2>	
 	<?php foreach($invoice as $row) { ?>
		<div class="invoice">
			 <h3><?php echo $row->invoice; ?></h3>
			 <div class="date">
				<?php $date = $row->originaldate; ?>
				<?php echo date('D, d M Y, H:i', strtotime($date)); ?>
			 </div>	
			  <div class="invoiceinfo"> 
				<?php if($row->status == 'processing'){
				 echo '<h4>order is being processed</h4>';
				 } elseif($row->status == 'on route'){
				 echo '<h4>order is with courier</h4>';
				 } elseif($row->status == 'delivered'){
				 echo '<h4>order has been delivered</h4>';
				 } elseif($row->status == 'cancelled'){
				 echo '<h4>order has been cancelled & refunded</h4>';
				 } elseif($row->status == '') {
				 echo '';
				 }?>
			 </div>
		 </div>
		 <div class="invoiceDetails">
				 <ul>
					<li><?php echo 'order placed: ' . $row->originaldate; ?></li>
					<li><?php echo 'order updated: ' . date('D, d M Y, H:i', strtotime($row->date)); ?></li>
					<li><?php echo 'Invoice no: ' . $row->invoice; ?></li>
					<li><?php echo 'Items cost: ' . $currency . sprintf('%0.2f', $row->cost); ?></li>
					<li><?php echo 'Shipping cost: ' . $currency . sprintf('%0.2f', $row->shippingcost); ?></li>
					<li><?php echo 'Total: ' . $currency . sprintf('%0.2f', $row->cost + $row->shippingcost); ?></li>
					<?php if($row->qtydiscount != 'no code' && $row->qtydiscount != null){echo '<li>Discount code: ' . $row->qtydiscount . '</li>';} ?>
					<?php if($row->paid == '1'){ ?>
					<li><?php echo '<div id="paymentrecieved">Payment recieved</div>'; ?></li>
					<?php } else {?>
					<li><?php echo '<div id="paymentnotrecieved">No payment confirmation</div>'; ?></li>
					<?php } ?>
				</ul>
			</div>
			<div class="deliveryAddress">
				<?php echo $row->customer; ?><br />
				<?php echo $row->deliveryaddress; ?>
			</div>
			<?php if($row->comments != null){ ?>
			<div id="invoiceComments"><?php echo 'Customer comments:<br>' . $row->comments; ?></div>
			<?php } ?>
 	<?php } ?>
	<?php foreach($orderedproducts as $part){ ?>
		<div class="orderedproducts">
	           <div class="opcontainer">
					<?php echo 'item: ' . $part->product; ?><br />
					<?php echo ' quantity: ' . $part->quantity; ?>
				</div>
				<div class="opcontainer">
					<?php echo '<br>' . $currency . $part->price; ?><br />
					<?php if($part->options != null){
						$itemsoption = explode(',', $part->options);
						$itemsoptioncost = $itemsoption['1'];
						$itemsoptionname = $itemsoption['0'];
						echo 'Item options: ' .  $itemsoptionname; 
						if($itemsoptioncost != '0.00'){echo ', +' . $currency . sprintf('%0.2f', $itemsoptioncost);}
							}?><br />
				</div>
				<?php if($part->download != null && $part->download != 'none'){ ?>
				<div class="downloadBox">
					<a href="<?php echo base_url() . 'download/item/' . $row->invoice . '_' . $part->download; ?>"><?php echo $part->download; ?><img src="<?php echo base_url() . 'images/default/download-icon.png' ?>" width="50px" title="download file" alt="download file" /></a>
				</div>
				<?php } ?>
			</div>
	<?php } ?>
<br class="clearBoth" />
</div>