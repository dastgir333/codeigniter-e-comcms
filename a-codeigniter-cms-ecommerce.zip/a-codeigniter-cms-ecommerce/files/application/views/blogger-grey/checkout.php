<div id="content">
   <div class="button"><a href="<?php echo base_url() . 'account'; ?>">Account</a></div>
   <br class="clearBoth" />
   <div class="button"><a href="<?php echo base_url() . 'account/downloads'; ?>">Downloads</a></div>
	<h5>Logged in as: <?php echo $this->session->userdata('email'); ?></h5>
	<div id="contactInfo">
		<p>Address and contact info</p>
		<?php foreach($userdetails as $part){ ?>
		<div class="addressDetails">
			<?php echo $part->first_name . ' ' . $part->last_name; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->phone; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->street_one; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->street_two; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->city; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->county; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->postcode; ?>
		</div>
		<div class="addressDetails">
			<?php echo $part->country; ?>
		</div>
		<?php } ?>
		<br class="clearBoth" />
		<div class="button"><a href="<?php echo base_url() . 'checkout/edit_details' ?>">Edit details</a></div>
	</div>
	<div id="checkoutCartBox">
		   <div id="discountBox">
				<?php echo form_open('checkout/discount'); ?>
				<label for="discount">discount code</label>
				<input type="text" name="discount" id="discount" />
				<input type="submit"  value="check code"/>
				<?php echo form_close(); ?>
				<p>To use a discount code, click "check code" before continuing through checkout.</p>
		   </div>
    <?php if(!$this->cart->contents()){ 
			echo 'you have no items in your shopping cart yet.';  
			} else { ?>
			<h4>Shopping cart contents</h4>
	        <?php foreach($this->cart->contents() as $items){ ?>
			  <div class="cartItem">
				<?php echo form_open('shop/update_item');?>
					<div class="cartItemName"><?php echo 'name: ' . $items['name']; ?></div>
					<div class="cartItemImage"><?php echo $items['image']; ?></div>
					<input type="hidden" name="item-rowid" id="item-rowid" value="<?php echo $items['rowid']; ?>" />
					<div class="cartItemPrice">
						<?php echo 'individual price: ' . $currency . $this->cart->format_number($items['price']); ?><br />
						<?php if($items['options'] != null){
						$optionscheckarray = $items['options'];
						$itemsoption = explode(',', $optionscheckarray['zero']);
							if($itemsoption['0'] != null){
								$itemsoptioncost = $itemsoption['1'];
								$itemsoptionname = $itemsoption['0'];
								echo 'Item options: ' .  $itemsoptionname; 
								if($itemsoptioncost != '0.00'){echo ', +' . $currency . sprintf('%0.2f', $itemsoptioncost);} 
							}
						}?><br />
					</div>
					<div class="cartItemUpdate">
					<?php if($items['download'] == 'none' or $items['download'] == ''){ ?>
						<input type="number" name="item-quantity" id="item-quantity" min="0" max="<?php echo $items['max']; ?>" value="<?php echo $items['qty']; ?>" />
						<input type="submit"  value="update item"/>
					<?php } else { ?>
						<input type="hidden" name="item-quantity" id="item-quantity" value="0" />
						<input type="submit"  value="remove item"/>
					<?php } ?>
					</div>
				<?php echo form_close(); ?>
			</div>
		  <?php } ?>
		    <div  class="cartItemCost">
		   <?php if($shippingvalid == 'no'){
			   echo 'Unfortunately we do not ship to your country at this time.';
		   } else {
			   echo 'shipping cost: ' . $currency . sprintf('%0.2f', $shippingtotal);
			   } ?>
			   <br />
		   <?php echo 'Items cost: ' . $currency . sprintf('%0.2f', $this->cart->total() + $optiontotal); ?>
			   <br />
			   <?php if(isset($code)){
					   if($percent != 0){
						   $discountamount = sprintf('%0.2f', $this->cart->total()) + $optiontotal;
						   $discountamount1 = $discountamount / 100;
						   $discountamount2 = $discountamount1 * $percent;
							$carttotala = sprintf('%0.2f', $this->cart->total()) - $discountamount2;
							if($carttotala <= 0){
								$carttotal = 0 + $optiontotal + $optiontotalb;
							} else {
								$carttotal = $carttotala + $optiontotal;
							}
					   } else {
						   $carttotala = sprintf('%0.2f', $this->cart->total()) + $optiontotal - $discount;
						   if($carttotala <= 0){
								$carttotal = 0;
							} else {
								$carttotal = $carttotala;
							}
					   } 
			   } else {
				   $carttotal = $this->cart->total()+ $optiontotal;
			   }?>
		   <?php echo 'Total: ' . $currency . sprintf('%0.2f', $shippingtotal  + $carttotal); ?>
		   <?php if($code != 'no code'){ 
					if($code != 'not valid'){
						echo ' using discount code: ' . $code;
					} else {
						echo ' discount code not valid';
					}
				} ?>
		   </div>
		   <br class="clearBoth" />
			<div id="emptyCart"><a href="<?php echo base_url() . 'shop/empty_cart';?>">empty cart</a></div>
		   <br class="clearBoth" />
		   <?php if($shippingvalid == 'yes'){ ?>
			<?php echo form_open('checkout/pay'); ?>
				<label for="comments">customer comments</label>
		   <br class="clearBoth" />
				<textarea rows="5" cols="70" name="comments" id="comments"></textarea>
		   <br class="clearBoth" />
				<input id="pay" type="submit"  value="confirm and pay"/>
				<?php echo form_close(); ?>
				<br class="clearBoth" />
				<p>By clicking "confirm and pay" you are agreeing to our term and conditions.</p>
		   <?php } ?>
	<?php }  ?>
	</div>
	<br class="clearBoth" />
</div> 
