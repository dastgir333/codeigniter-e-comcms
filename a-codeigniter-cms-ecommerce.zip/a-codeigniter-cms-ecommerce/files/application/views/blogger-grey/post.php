<div id="content">
 
 
 	<?php foreach($data as $row) { ?>
 <?php 
 $check = $this->uri->segment(2);
 if ($row->slug != $check) { redirect('index.php');}
 else {
$address = base_url() . 'images/smileys/';
$str = $row->content; 
$str = parse_smileys($str, $address); 
echo $str;
      }
 ?>
 <br class="clearBoth" />
       <?php if($row->videolink != ''){ ?>
<iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo $row->videolink; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	    <?php } ?>
		
		<?php if($row->comments == '1'){ ?>
		<?php if(isset($comments)){ ?>
			  <h4>comments</h4>
			  <?php foreach($comments as $cbits){ ?>
			  <div class="postComment">
			  <?php echo '<div class="commentUser">' . $cbits->user . '</div><br class="clearBoth" /><div class="comment">' . $cbits->comment . '</div>'; ?>
			  </div>
			  <?php }
		  } ?>
			<br class="clearBoth" />
<?php echo form_open('post/comments');?>

    <p><label for="comment_name">name</label>
	<?php 
	$data1 = array(
              'name'        => 'comments_name',
              'id'          => 'comments_name',
              'value'       => ''
            );

echo form_input($data1);
	?></p>
	<label for="comments_message">enter your message here</label><br />
	<?php 
	$data2 = array(
              'name'        => 'comments_message',
              'id'          => 'comments_message',
              'value'       => '',
              'rows'        => '10',
              'cols'          => '40',
            );

echo form_textarea($data2);
	?> 
	<p>comments are held for approval by a moderator</p>
	<div id="capture">
	<p><?php foreach($capturedata as $image) {
	echo '<img src="' . base_url() . 'images/' . $image->one . '" alt="capture" />';
	?>
	</p>
	
	<p><label for="capture1">capture field </label>
	<?php 
	$data3 = array(
              'name'        => 'capture1',
              'id'          => 'capture1',
            );

echo form_input($data3);
echo 'why is there a capture field?<br />
      It is to ensure that you are a real person leaving a real comment.';
	?></p>
	<input type="hidden" name="capture2" id="capture2" value="<?php echo $image->one; ?>" />
	<input type="hidden" name="comments_post" id="comments_post" value="<?php echo $row->title; ?>" />
	<input type="hidden" name="comments_slug" id="comments_slug" value="<?php echo $row->slug; ?>" />
	<?php 
       }
	
	?>
	</div>
		<?php echo form_submit('submit', 'Send'); ?>
	<?php echo form_close(); ?>
		<?php } ?>
		
 	<?php } ?>
	
	</div>