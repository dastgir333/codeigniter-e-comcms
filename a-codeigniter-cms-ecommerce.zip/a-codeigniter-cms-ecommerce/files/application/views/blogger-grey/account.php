<div id="content">
   <div class="button"><a href="<?php echo base_url() . 'customer/logout'; ?>">Log out</a></div>
   <br class="clearBoth" />
   <div class="button"><a href="<?php echo base_url() . 'account/downloads'; ?>">Downloads</a></div>
   <h2>invoices</h2>	
 	<?php foreach($invoices['results'] as $row) { ?>
		<div class="invoices">
			 <h3><a href="<?php echo base_url() . 'account/invoice/' . $row->id; ?>"><?php echo $row->invoice; ?></a></h3>
			 <div class="invoiceDate">
				<?php $date = $row->originaldate; ?>
				<?php echo date('D, d M Y, H:i', strtotime($date)); ?><br />
				<a href="<?php echo base_url() . 'account/invoice/' . $row->id; ?>"><b>View invoice</b></a>
			 </div>	
			  <div class="invoiceInfo"> 
				<?php echo 'Total: ' . $currency . sprintf('%0.2f', $row->cost + $row->shippingcost); ?><br />
				<?php echo 'Items cost: ' . $currency . sprintf('%0.2f', $row->cost); ?><br />
				<?php echo 'Shipping cost: ' . $currency . sprintf('%0.2f', $row->shippingcost); ?><br />
				<?php if($row->qtydiscount != 'no code'){echo 'Discount code: ' . $row->qtydiscount;} ?><br />
				<?php echo $row->status; ?>
			 </div>
		 </div>
 	<?php } ?>
	<div id="pageLinks">
          <?php echo $invoices['links']; ?>
     </div>
<br class="clearBoth" />
</div>