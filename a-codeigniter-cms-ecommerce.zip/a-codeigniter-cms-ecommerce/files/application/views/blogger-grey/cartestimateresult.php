<div id="content">
	<?php if($this->session->userdata('email') != FALSE){ ?>
	<h5>Logged in as: <?php echo $this->session->userdata('email'); ?></h5>
	<?php } else { ?>
	<div class="button" id="login">
		<a href="<?php echo base_url() . 'customer-login'; ?>" >Login</a>
	</div>
	<br class="clearBoth" />
	<?php } ?>
	<div id="cartBox">
    <?php if(!$this->cart->contents()){ 
			echo 'you have no items in your shopping cart yet.';  
			} else { ?>
			<h4>Shopping cart contents</h4>
			<h5>Displaying estimated shipping costs</h5>
			<p>Accurate shipping costs will be calculated based on your delivery address at checkout.</p>
		   <?php if($shippingtotal != null){ ?>
		   <div class="button" id="checkoutButton"><a href="<?php echo base_url() . 'checkout'; ?>">Checkout</a></div>
			<?php } ?>
			 <?php foreach($this->cart->contents() as $items){ ?>
			  <div class="cartItem">
				<?php echo form_open('shop/update_item');?>
					<div class="cartItemName"><?php echo 'name: ' . $items['name']; ?></div>
					<div class="cartItemImage"><?php echo $items['image']; ?></div>
					<input type="hidden" name="item-rowid" id="item-rowid" value="<?php echo $items['rowid']; ?>" />
					<div class="cartItemPrice">
						<?php echo 'individual price: ' . $currency . $this->cart->format_number($items['price']); ?><br />
						<?php if($items['options'] != null){
						$optionscheckarray = $items['options'];
						$itemsoption = explode(',', $optionscheckarray['zero']);
							if($itemsoption['0'] != null){
								$itemsoptioncost = $itemsoption['1'];
								$itemsoptionname = $itemsoption['0'];
								echo 'Item options: ' .  $itemsoptionname; 
								if($itemsoptioncost != '0.00'){echo ', +' . $currency . sprintf('%0.2f', $itemsoptioncost);} 
							}
						}?><br />
					</div>
					<div class="cartItemUpdate">
					<?php if($items['download'] == 'none' or $items['download'] == ''){ ?>
						<input type="number" name="item-quantity" id="item-quantity" min="0" max="<?php echo $items['max']; ?>" value="<?php echo $items['qty']; ?>" />
						<input type="submit"  value="update item"/>
					<?php } else { ?>
						<input type="hidden" name="item-quantity" id="item-quantity" value="0" />
						<input type="submit"  value="remove item"/>
					<?php } ?>
					</div>
				<?php echo form_close(); ?>
			</div>
		  <?php } ?>
		   <div  class="cartItemCost">
		   <?php if($shippingvalid == 'no'){
			   echo 'Unfortunately we do not ship to your country at this time.';
		   } else {
			   echo 'shipping cost: £' . sprintf('%0.2f', $shippingtotal);
			   } ?>
			   <br />
		   <?php echo 'Items cost: ' . $currency . sprintf('%0.2f', $this->cart->total() + $optiontotal); ?>
			   <br />
		   <?php echo 'Total: ' . $currency . sprintf('%0.2f', $shippingtotal + $optiontotal + $this->cart->total()); ?>
		   </div>
		   <br class="clearBoth" />
		   <?php if($shippingvalid == 'yes'){ ?>
		   <div class="button" id="checkoutButton"><a href="<?php echo base_url() . 'checkout'; ?>">Checkout</a></div>
			<?php } ?>
			<div id="emptyCart"><a href="<?php echo base_url() . 'shop/empty_cart';?>">empty cart</a></div>
		   <br class="clearBoth" />
		   <div class="button" id="estimate"><a href="<?php echo base_url() . 'cart/estimate'; ?>">Estimate shipping</a></div>
	<?php }  ?>
	</div>
</div>