  <div id="content">    
	<div id="login">

	<?php 
	echo 'login please';
	echo form_open('login/check_user');
	echo 'email';
	echo form_input('email', '');
	echo '<br>password';
	echo form_password('password', '');
	echo form_submit('submit', 'Login');
	echo form_close();
	?>

      </div>
   </div>