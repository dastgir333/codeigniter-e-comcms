


      <div id="footer">
	      <div id="footerBox1">
		  <h3>post categories</h3>
		  <ul>
		  <?php if(isset($postmenufooter)){ 
		    foreach($postmenufooter as $pmf){ ?>
			 <li><a href="<?php echo base_url() . 'post/category/' . $pmf->slug;?>"><?php echo $pmf->name; ?></a></li>
		    <?php  } ?>
      <?php } ?>
	     </ul>
		  </div>
		  <div id="footerBox2">
		  <h3><a href="<?php echo base_url(); ?>recentposts">recent posts</a></h3>
		  <ul>
		  <?php if(isset($postmenufooterlinks)){ 
		    foreach($postmenufooterlinks as $pmfl){ ?>
			 <li><a href="<?php echo base_url() . 'post/' . $pmfl->slug;?>"><?php echo $pmfl->name; ?></a></li>
		    <?php  } ?>
      <?php } ?>
	     </ul>
		  </div>
	  </div>

  </body>
</html>


