 <?php if($this->uri->segment(1) == true){redirect('/');}?>
 <div id="content">
 
      <div class="slider">
	  <?php $this->load->view($theme . '/modules/slider.php'); ?>
      </div>
	  <?php foreach($pagedata as $row) { ?>
	   <h2><?php echo $row->title; ?></h2>
	   <p><?php echo $row->content; ?></p>
	  <?php } ?>
		 <div id="boxContainer">
	        <div id="box1">
			<?php $this->load->view($theme . '/modules/box1.php'); ?>
	        </div>
			<div id="box2">
			<?php $this->load->view($theme . '/modules/box2.php'); ?>
	        </div>
			<div id="box3">
			<?php $this->load->view($theme . '/modules/box3.php'); ?>
	        </div>
	     </div>
<br class="clearBoth" />
 </div>