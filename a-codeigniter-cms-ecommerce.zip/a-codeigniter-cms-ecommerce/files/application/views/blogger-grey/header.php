<!DOCTYPE html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?php echo base_url() . 'js/'; ?>jquery-3.3.1.min.js"></script>
    <script src="<?php echo base_url() . 'js/'; ?>lightbox.js"></script>
	<?php if($this->uri->segment(1) != TRUE){ ?>
	<link rel="stylesheet" href="<?php echo base_url() . 'css/'; ?>bxslider.css">
  <script src="<?php echo base_url() . 'js/'; ?>bxslider.js"></script>
	<script>
		$(document).ready(function(){
		  $('.slider').bxSlider();
		  $('.image-popup-no-margins').magnificPopup({
          type: 'image',
          closeOnContentClick: true,
          closeBtnInside: false,
          fixedContentPos: true,
          mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
          image: {
            verticalFit: true
          },
          zoom: {
            enabled: true,
            duration: 300 // don't foget to change the duration also in CSS
          }
        });
		});

	  </script>
	<?php } else { ?>
	<script>
		$(document).ready(function(){
		  $('.image-popup-no-margins').magnificPopup({
          type: 'image',
          closeOnContentClick: true,
          closeBtnInside: false,
          fixedContentPos: true,
          mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
          image: {
            verticalFit: true
          },
          zoom: {
            enabled: true,
            duration: 300 // don't foget to change the duration also in CSS
          }
        });
		});

	  </script>
	<?php } ?>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'css/blogger-grey/';?>style.css" />
   <?php if(isset($pageheader)){ 
      foreach($pageheader as $row) { ?>
    <?php if(isset($pagetitle)){
			  foreach($pagetitle as $ps){ 
				echo '<title>' . $ps->title . '</title>';
			  }
		  } else { ?>
    <title><?php echo $row->title; ?></title>
		  <?php } ?>
	<meta name="description" content="<?php echo $row->description ?>" />
	<meta name="keywords" content="<?php echo $row->keywords ?>" />	
	 <?php } ?>
   <?php } else { ?>
	<title><?php echo base_url(); ?></title> 
   <?php }?>
</head>
<body>
<script type="text/javascript">
	 jQuery (function ($){
		$('.menuToggle').click(function(){ 
        $('#productsMenu, #postMenu, #headerMenu').slideToggle('fast');
       });
   }); 
   $(window).resize(function(){
	if ($(window).width() >= 550){	
		$('#productsMenu, #postMenu, #headerMenu').show();
  var modWidth = 560;	
		$('iframe').width( modWidth );
	}	
	if ($(window).width() <= 550){
  var modWidth = 250;	
		$('iframe').width( modWidth );
	}	
});

   </script>
     <?php
    if(isset($menustatus)){
		foreach($menustatus as $Mstatus){
			if($Mstatus->name == 'pagemenu' && $Mstatus->status == '1'){
				$pagemenustatus = '1';
			}
			if($Mstatus->name == 'postmenu' && $Mstatus->status == '1'){
				$postmenustatus = '1';
			}
			if($Mstatus->name == 'productmenu' && $Mstatus->status == '1'){
				$productmenustatus = '1';
			}
        }
	}	
    ?>
	   <div id="header">
	   <?php if(isset($pagemenustatus) && $pagemenustatus == '1'){ ?>
	  <div id="headerMenu">
		<ul>
			<li><a href="<?php echo base_url(); ?>">home</a></li>
			<?php if(isset($menu)){ ?>
				  <?php foreach($menu as $menubit){ ?>
					<?php if($menubit->name != 'home'){ ?>
					<li><a href="<?php echo base_url() . $menubit->slug; ?>"><?php echo $menubit->name; ?></a></li>
					<?php } ?>
				<?php } ?>
			<?php } ?>
			<?php if($this->session->userdata('customer_logged_in') == false){ ?>
			<li><a href="<?php echo base_url(); ?>customer-login">login</a></li>
			<?php } else { ?>
			<li><a href="<?php echo base_url(); ?>account">account</a></li>
			<?php } ?>
			<li><a href="<?php echo base_url(); ?>cart">cart</a></li>
		</ul>
	  </div>
	 <?php } ?>
	 
	<?php if(isset($postmenustatus) && $postmenustatus == '1'){ ?>
	   <div id="postsMenu">
		   <ul>
			   <?php if(isset($postmenu)){ 
				   foreach($postmenu as $postmenubit){ ?>
			   <li><a href="<?php echo base_url() . 'post/category/' . $postmenubit->slug; ?>"><?php echo $postmenubit->name; ?></a></li>
					   <?php } ?>
				   <?php } ?>
		   </ul>
		</div>
	<?php } ?>
	<?php if(isset($productmenustatus) && $productmenustatus == '1'){ ?>
	   <div id="productsMenu">
		   <ul>
			<li><a href="<?php echo base_url(); ?>allproducts">all products</a></li>
		   <?php if(isset($productmenu)){ 
		       foreach($productmenu as $productmenubit){ ?>
		   <li><a href="<?php echo base_url() . 'shop/category/' . $productmenubit->slug; ?>"><?php echo $productmenubit->name; ?></a></li>
				   <?php } ?>
			   <?php } ?>
			</ul>
		</div>
	<?php } ?>
		   <div id="mobileMenu">
		    <div class="menuToggle">Menu</div>
		   </div>
		   <div id="logoWrapper">
		    <a href="<?php echo base_url(); ?>">
		  	   <img src="<?php echo base_url() . 'images/gallery/' . $headerlogo; ?>" height="90px" />
			 </a>
		   <div id="headersearchBox">
				<?php echo form_open('search/result');?>
					<input type="image" id="searchButton" alt="search" src="<?php echo base_url() . 'images/blogger-grey/'; ?>search-icon.png" height="35px">				
				<input type="text" name="searchfield" id="searchfield"  /><?php echo form_close(); ?>
		   </div>
		 </div>
	   </div>