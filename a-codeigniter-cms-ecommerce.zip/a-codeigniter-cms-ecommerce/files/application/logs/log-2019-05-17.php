<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-05-17 09:28:09 --> Config Class Initialized
INFO - 2019-05-17 09:28:09 --> Hooks Class Initialized
DEBUG - 2019-05-17 09:28:09 --> UTF-8 Support Enabled
INFO - 2019-05-17 09:28:09 --> Utf8 Class Initialized
INFO - 2019-05-17 09:28:09 --> URI Class Initialized
DEBUG - 2019-05-17 09:28:09 --> No URI present. Default controller set.
INFO - 2019-05-17 09:28:09 --> Router Class Initialized
INFO - 2019-05-17 09:28:09 --> Output Class Initialized
INFO - 2019-05-17 09:28:09 --> Security Class Initialized
DEBUG - 2019-05-17 09:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-05-17 09:28:09 --> CSRF cookie sent
INFO - 2019-05-17 09:28:09 --> Input Class Initialized
INFO - 2019-05-17 09:28:09 --> Language Class Initialized
INFO - 2019-05-17 09:28:09 --> Loader Class Initialized
INFO - 2019-05-17 09:28:09 --> Helper loaded: url_helper
INFO - 2019-05-17 09:28:09 --> Helper loaded: form_helper
INFO - 2019-05-17 09:28:09 --> Helper loaded: file_helper
INFO - 2019-05-17 09:28:09 --> Helper loaded: smiley_helper
INFO - 2019-05-17 09:28:09 --> Helper loaded: security_helper
INFO - 2019-05-17 09:28:09 --> Helper loaded: cookie_helper
INFO - 2019-05-17 09:28:09 --> Database Driver Class Initialized
INFO - 2019-05-17 09:28:09 --> Session: Class initialized using 'database' driver.
DEBUG - 2019-05-17 09:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2019-05-17 09:28:09 --> Cart Class Initialized
INFO - 2019-05-17 09:28:09 --> Controller Class Initialized
INFO - 2019-05-17 09:28:09 --> Model "Page_model" initialized
INFO - 2019-05-17 09:28:09 --> Model "Functions_model" initialized
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/header.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/modules/slider.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/modules/box1.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/modules/box2.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/modules/box3.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/mainpage.php
INFO - 2019-05-17 09:28:09 --> File loaded: /home/jcwebdev/public_html/test-ci/application/views/default/footer.php
INFO - 2019-05-17 09:28:09 --> Final output sent to browser
DEBUG - 2019-05-17 09:28:09 --> Total execution time: 0.0331
