<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Search extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Search_model');
		$this->load->model('Functions_model');
		$this->load->library("pagination");
	}
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function index()
	{
     $template = $this->Functions_model->get_template();
		$check = 'default';
		foreach($template as $bit){
		$theme = $bit->name;
		
		$data = $this->Search_model->get_page();
		$page_data = array('data' => $data);
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo,'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/pagesearch', $page_data);
		$this->load->view($theme . '/footer', $footerdata);
	  }
	}
	
	public function result()
	{
	 $this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('searchfield', 'searchfield', 'required');
		
		if($this->form_validation->run() == FALSE)
		{
     redirect('search');
		
		} else {
		$template = $this->Functions_model->get_template();
		$check = 'default';
		foreach($template as $bit){
		$theme = $bit->name;
		
		$searchtext = $this->security->xss_clean($this->input->post('searchfield'));
		$searchtext1 = str_replace('&', 'and', $searchtext);
		$searchtext2 = strtolower($searchtext1);
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â', 'SQL', 'SELECT', 'from', 'FROM');
		$change1 = '';
		$searchtext3 = str_replace($chars, $change1, $searchtext2);
		
		$data = $this->Search_model->get_page();
		$datasearch1 = $this->Search_model->get_searchresult($searchtext3);
		$datasearch2 = $this->Search_model->get_searchresultproducts($searchtext3);
		$currency = $this->currency();
		$page_data = array('data' => $data, 'datasearch1' => $datasearch1, 'datasearch2' => $datasearch2, 'currency' => $currency);
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo,'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/pagesearchresult', $page_data);
		$this->load->view($theme . '/footer', $footerdata);
		
		}	
	  }
	}
	
}
