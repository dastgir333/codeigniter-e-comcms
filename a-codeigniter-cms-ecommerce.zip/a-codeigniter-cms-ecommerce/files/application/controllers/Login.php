<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Admin_model');
	    $this->load->model('Functions_model');
	}

public function index()
	{
	
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/login');
		$this->load->view($theme . '/footer', $footerdata);
    }	 


public function check_user()
	{		
	
		$query = $this->Admin_model->check();
		
		if($query)
		{
			$newdata = array(
				'email' => $this->input->post('email'),
				'is_logged_in' => true
			);
			$this->session->set_userdata($newdata);
			redirect('be/dash/');
		}
		else 
		{
		redirect('mainpage');
		}
	}

public function logout()
	{
		$this->session->sess_destroy();
		$this->index();
	}
	
}