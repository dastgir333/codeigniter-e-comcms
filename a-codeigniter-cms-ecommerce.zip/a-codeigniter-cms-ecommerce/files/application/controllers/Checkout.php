<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checkout extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Checkout_model');
	    $this->load->model('Cart_model');
	    $this->load->model('Functions_model');
	    $this->load->model('Product_model');
		$this->load->library('email');
		$this->statuscheck();
		$this->customer_logged_in();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	public function customer_logged_in()
	{
		$customer_logged_in = $this->session->userdata('customer_logged_in');
		if(!isset($customer_logged_in) || $customer_logged_in != true)
		{
			redirect('customer-login');
		}		
	}
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function get_shippingcost()
	{
		$shippingvalid = 'no';
		$allitemsshipping = 0.00;
		$customercheck = $this->session->userdata('customer_logged_in');
		if($customercheck == TRUE){
			$customerid = $this->session->userdata('customerid');
			$address = $this->Cart_model->get_customeraddress($customerid);
			foreach($address as $row){
				$country = $row->country;
				$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â',' ','-');
				$postcode = str_replace($chars, '', $row->postcode);
				$postupper = strtoupper($postcode);
				$postlength = strlen($postcode);
				if($postlength == 6){
					$finalcode = substr($postupper, 0, 3);
				} elseif($postlength == 7){
					$finalcode = substr($postupper, 0, 4);
				} elseif($postlength == 5){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 4){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 8){
					$finalcode = substr($postupper, 0, 4);
				} else {
					$finalcode = 0;
				}
			}
			foreach($this->cart->contents() as $items){
				$courier = $items['shippingname'];
				$shippingrules = $this->Cart_model->get_shippingrules($courier, $country, $finalcode);
				if($items['qty'] == '1'){
					$shippingweight = $items['weight'];
				} else {
					$shippingweight = $items['weight'] * $items['qty'];
				}
				if($shippingrules == null){
					$shippingrules = $this->Cart_model->get_shippingruleszoneone($courier, $country);
				}
				if($items['download'] != 'none' && $items['download'] != ''){
					$itemshippingcost = 0 + $allitemsshipping;
					$allitemsshipping = $itemshippingcost;
					$shippingvalid = 'yes';
				} else {
					foreach($shippingrules as $rule){
						$codes = explode(',', $rule->postcodes);
						$shippingcosts = explode(';', $rule->cost);
						foreach($shippingcosts as $parts){
							if($parts != null){
								$individualcosts = explode(',', $parts);
								$from = $individualcosts['0'];
								$to = $individualcosts['1'];
								$price = $individualcosts['2'];
								
								if($shippingweight >= $from && $shippingweight <= $to){
									$itemshippingcost = $price + $allitemsshipping;
									$allitemsshipping = $itemshippingcost;
									$shippingvalid = 'yes';
								}
							}
						}
					}
				}
			}
		} else {
			redirect('customer-login');
		}
		foreach($this->cart->contents() as $itemcheck){
				$couriercheck = $itemcheck['shippingname'];
				$countrycheck = array('country' => $country);
				$itemcountry = $this->Cart_model->get_itemcountry($couriercheck);
				if(!in_array($countrycheck, $itemcountry, TRUE)){
					$shippingvalid = 'no';
				}
			}
		$shipping = array('allitemsshipping' => $allitemsshipping, 'shippingvalid' => $shippingvalid);
		return $shipping;
	}
	public function get_options()
	{
		$optiontotal = 0;
		$itemextra = 0;
		foreach($this->cart->contents() as $optioncheck){
			if($optioncheck['options'] != null){
				$optionscheckarray = $optioncheck['options'];
				$optionarray = explode(',', $optionscheckarray['zero']);
				if(isset($optionarray['1'])){
					if($optioncheck['qty'] != '1'){
						$itemextra = $optionarray['1'] * $optioncheck['qty'];
					} else {
						$itemextra = $optionarray['1'];
					}
				}
				$newtotal = $optiontotal + $itemextra;
				$optiontotal = $newtotal;
			}
		}
		$options = array('optiontotal' => $optiontotal);
		return $options;
	}
	public function get_discounts()
	{
		$customerid = $this->session->userdata('customerid');
		$customercode = $this->Checkout_model->get_customercode($customerid);
		if($customercode != null){
			foreach($customercode as $cc){
				if($cc->code != 'not valid'){
					$discount = $cc->discount;
					$percent = $cc->percent;
					$code = $cc->code;
				} else {
					$discount = 0;
					$percent = 0;
					$code = 'not valid';
				}
			}
		} else {
			$discount = 0;
			$percent = 0;
			$code = 'no code';
		}
		$discounts = array('discount' => $discount, 'percent' => $percent, 'code' => $code);
		return $discounts;
	}
	public function index()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$customerid = $this->session->userdata('customerid');
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
		$discounts = $this->get_discounts();
		$options = $this->get_options();
		$shipping = $this->get_shippingcost();
		$currency = $this->currency();
	    $shippingtotal = $shipping['allitemsshipping'];
		$userdetails = $this->Checkout_model->get_details(); 
		$pagedata = array(
		'userdetails' => $userdetails,
		'shippingtotal' => $shippingtotal,
		'shippingvalid' => $shipping['shippingvalid'],
		'code' => $discounts['code'],
		'percent' => $discounts['percent'],
		'discount' => $discounts['discount'],
		'optiontotal' => $options['optiontotal'],
		'currency' => $currency
		);
		
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/checkout', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
		if($discounts['code'] == 'not valid'){
			$this->Checkout_model->remove_code($customerid);
		}
	}
	
	public function pay()
	{
		$discounts = $this->get_discounts();
		$options = $this->get_options();
		$shipping = $this->get_shippingcost();
	    $shippingtotal = $shipping['allitemsshipping'];
		
		$customerdetails = $this->Checkout_model->get_details();
		foreach($customerdetails as $details){
			$name = $details->first_name . ' ' . $details->last_name;
			$address = $details->street_one . '<br>' .
						$details->street_two . '<br>' .
						$details->city . '<br>' .
						$details->county . '<br>' .
						$details->postcode . '<br>' .
						$details->country . '<br>';
		}
		$invoicecall = $this->Checkout_model->get_invoicenumber();
		$invoiceprefix = $this->Checkout_model->get_invoiceprefix();
		foreach($invoicecall as $invoicepart) {
			$invoice = $invoicepart->number;
		}
		foreach($invoiceprefix as $inp){
			$prefix = $inp->prefix;
		}
		if($invoice){
			$plusone = $invoice + 1;
		} else {
			$plusone = 1;
		}
		$nextinvoice = $prefix . '-' . $plusone;
		
		$settings = $this->Checkout_model->get_timezone();
		foreach ($settings as $row) {
			$sitetimezone = $row->timezone;
		}
		date_default_timezone_set($sitetimezone);
		$odate = date("F j, Y, g:i a");
		if($discounts['percent'] != 0){
				$discountamount = sprintf('%0.2f', $this->cart->total()) + $options['optiontotal'];
				$discountamount1 = $discountamount / 100;
			    $discountamount2 = $discountamount1 * $discounts['percent'];
				$carttotala = sprintf('%0.2f', $this->cart->total()) - $discountamount2;
				if($carttotala <= 0){
								$carttotal = 0 + $options['optiontotal'];
							} else {
								$carttotal = $carttotala + $options['optiontotal'];
							}
		   } else {
			   $carttotala = $this->cart->total() + $options['optiontotal'] - $discounts['discount'];
			   if($carttotala <= 0){
								$carttotal = 0;
							} else {
								$carttotal = $carttotala;
							}
		   }
		if($this->input->post('comments') != null){
			$customercomments = $this->input->post('comments');
		} else {
			$customercomments = 'none';
		}
		$data = array(
		     'invoice' => $nextinvoice,
		    'customer' => $name,
		     'deliveryaddress' => $address,
			 'quantity' => $this->cart->total_items(),
			 'cost' => $carttotal,
		    'email' => $this->session->userdata('email'),
			'originaldate' => $odate,
		    'customerid' => $this->session->userdata('customerid'),
		    'shippingcost' => $shippingtotal,
		    'totalextracost' => $options['optiontotal'],
		    'qtydiscount' => $discounts['code'],
			'comments' => $customercomments
		);
		$this->Checkout_model->addorder($data);
		
		$newnumber = str_replace($prefix . '-', '', $nextinvoice);
		$this->Checkout_model->update_invoicenumber($newnumber);
		
		foreach($this->cart->contents() as $cartitems){
			$cartoptions = $cartitems['options'];
			$productsordered = array(
				'product' => $cartitems['name'],
				'price' => $cartitems['price'],
				'quantity' => $cartitems['qty'],
				'productid' => $cartitems['id'],
				'invoice' => $nextinvoice,
				'download' => $cartitems['download'],
				'customerid' => $this->session->userdata('customerid'),
				'options' => $cartoptions['zero']
			);
		$this->Checkout_model->additemordered($productsordered);
		}
		foreach($this->cart->contents() as $cartpart){
			$productid = $cartpart['id'];
			$stockcheck = $this->Checkout_model->getstocklevel($productid);
			foreach($stockcheck as $sl){
				$itemstock = $sl->stock;
			}
			if($itemstock == 'no limit'){
				$newstocklevel = 'no limit';
			} elseif($itemstock == 'out of stock') {
				$newstocklevel = 'out of stock';
			} else {
				$newstocklevel = $itemstock - $cartitems['qty'];
			}
			$product = array(
					'id' => $cartitems['id'],
					'stock' => $newstocklevel
			);
			$this->Checkout_model->alterstocklevel($product);
		}
		$check = 'no';
		foreach($this->cart->contents() as $item){ 
		if($item['download'] == 'none' or $item['download'] == ''){
			$check = 'yes';
		  }
		 }
		if($check == 'yes'){
		 $no_shipping 		= 0;
		} else {
		 $no_shipping 		= 1;
		}
		$countrycode = $this->Checkout_model->getcountrycode();
		$currency = 'GBP';
		$currencyinfo = $this->Product_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currency;
			$paymentemail = $ci->paymentemail;
		}
		$config["currency_code"] = $currency;
		$config['business'] 			= $paymentemail;
		$config['cpp_header_image'] 	= ''; //Image header url [750 pixels wide by 90 pixels high]
		$config['return'] 				= base_url() . 'paypalreturn/success';
		$config['cancel_return'] 		= base_url() . 'cart';
		$config['notify_url'] 			= base_url() . 'notification'; //IPN Post
		$config['production'] 			= FALSE; //Its false by default and will use sandbox
		$config["no_shipping"] 		= $no_shipping;
		// $config["tax"] 			= 0;
		// $config["tax_cart"] 		= 0;
		$config["address_override"] 	= 1;
		$config["handling_cart"] 	= $shippingtotal;
		if($discounts['percent'] != 0){
			$config["discount_rate_cart"] 	= $discounts['percent']; //Discount percentage [15]
	    } else {
		   $config["discount_amount_cart"] = $discounts['discount']; //Discount amount [9.99]
	    }
		$config["invoice"]				= $nextinvoice; //The invoice id
		$config["first_name"] 		= $details->first_name;
		$config["last_name"] 		= $details->last_name;
		$config["address1"] 		= $details->street_one;
		$config["address2"] 		= $details->street_two;
		$config["city"] 			= $details->city;
		$config["state"] 			= $details->county;
		$config["zip"] 				= $details->postcode;
		$config["country"] 			= $countrycode;
		$config["email"] 			= $this->session->userdata('email');
		$config["night_phone_a"] 	= $details->phone;
		$config["night_phone_b"] 	= '';
		$config["night_phone_c"] 	= '';
		
		$this->load->library('paypal',$config);
		
		$options = 0;
		foreach($this->cart->contents() as $items){
			if($items['options'] != null){
			$optionscheckarray = $items['options'];
			$optionarray = explode(',', $optionscheckarray['zero']);
			if(isset($optionarray['1'])){
					if($items['qty'] != '1'){
						$options = $optionarray['1'] * $items['qty'];
					} else {
						$options = $optionarray['1'];
					}
				}
			}
			$extracost = $options;
		$this->paypal->add($items['name'],$items['price'] + $extracost, $items['qty']); 
		}
		
		$this->paypal->pay(); //Proccess the payment
		
		$this->cart->destroy();
		$customerid = $this->session->userdata['customerid'];
		if($discounts['code'] != 'not valid' && $discounts['code'] != 'no code'){
			$this->Checkout_model->remove_code($customerid);
			$code = $discounts['code'];
			$getcode = $this->Checkout_model->get_code($code);
			foreach($getcode as $gc){
				$updateduses = $gc->uses - 1;
				$data = array('uses' => $updateduses);
				
				$this->Checkout_model->update_uses($data, $code);
			}
		}
	}
	public function edit_details()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu,
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
		$userdetails = $this->Checkout_model->get_details();
		$parent_data = array(
			'userdetails' => $userdetails
		);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/editdetails', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
	}
	
	public function customer_update()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('street_one', 'street_one', 'required');
		$this->form_validation->set_rules('city', 'city', 'required');
		$this->form_validation->set_rules('county', 'county', 'required');
		$this->form_validation->set_rules('postcode', 'postcode', 'required');
		$this->form_validation->set_rules('country', 'country', 'required');
		
		$userid = $this->input->post('id');
		$useremails = $this->Checkout_model->get_emailsedit($userid);
		$emailcheck = array('email' => $this->input->post('email'));
		$emailused = FALSE;
		 if(in_array($emailcheck, $useremails, TRUE)){
			 $emailused = TRUE;
		 }
		
		if($this->form_validation->run() == FALSE or $emailused == TRUE)
		{
			$user['id'] = $this->input->post('id');
			$user['email'] = $this->input->post('email');
			$user['first_name'] = $this->input->post('first_name');
			$user['last_name'] = $this->input->post('last_name');
			$user['phone'] = $this->input->post('phone');
			$user['street_one'] = $this->input->post('street_one');
			$user['street_two'] = $this->input->post('street_two');
			$user['city'] = $this->input->post('city');
			$user['county'] = $this->input->post('county');
			$user['postcode'] = $this->input->post('postcode');
			$user['country'] = $this->input->post('country');
			$usererror = 'please use an email address that has not been used before<br>and all fields are required.';
 		
		 $activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu,
		'productmenu' => $productmenu,
		'menustatus' => $menustatus
		);
		
		$parent_data = array(
			'user' => $user,
			'usererror' => $usererror
		);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/editdetailserror', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
		
		} else {
			
				$data = array(
				'id' => $this->input->post('id'),
				'email' => $this->input->post('email'),
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'phone' => $this->input->post('phone'),
				'street_one' => $this->input->post('street_one'),
				'street_two' => $this->input->post('street_two'),
				'city' => $this->input->post('city'),
				'county' => $this->input->post('county'),
				'postcode' => $this->input->post('postcode'),
				'country' => $this->input->post('country')
				);
			
			
			$this->Checkout_model->update_user($data);
			redirect('checkout');
		}
	}
	public function discount()
	{
		$customerid = $this->session->userdata['customerid'];
		$this->Checkout_model->remove_code($customerid);
		
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('discount', 'discount', 'trim|required');
		
		if($this->form_validation->run() == FALSE)
		{
			redirect('checkout');
		} else {
			$code = $this->input->post('discount');
			$codelc = strtolower($code);
			$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â', ' ');
			$change = '';
			$discountcode = str_replace($chars, $change, $codelc);
			$codecheck = $this->Checkout_model->check_discountcode($discountcode);
			if($codecheck != null){
				foreach($codecheck as $cc){
					$currenttime = strtotime('now');
					$startdate = strtotime($cc->start);
					$enddate = strtotime($cc->end);
					
					if($cc->uses >= 1 && $currenttime >= $startdate && $currenttime <= $enddate){
							$data = array(
								'customerid' => $this->session->userdata('customerid'),
								'code' => $cc->code,
								'discount' => $cc->discount,
								'percent' => $cc->percent
							);
							$this->Checkout_model->add_customercode($data);
							redirect('checkout');
					} else {
						$data = array(
								'customerid' => $this->session->userdata('customerid'),
								'code' => 'not valid',
								'discount' => '0',
								'percent' => '0'
							);
							$this->Checkout_model->add_customercode($data);
							redirect('checkout');
					}
				}
			} else {
				redirect('checkout');
			}
		}
	}
}