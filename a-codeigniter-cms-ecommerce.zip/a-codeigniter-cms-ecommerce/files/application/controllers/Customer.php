<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Customer_model');
	    $this->load->model('Functions_model');
		$this->load->library('email');
		$this->statuscheck();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	
	public function login()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu,
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu,
		'menustatus' => $menustatus
		);
		$countriesdata = $this->Customer_model->get_countries();
		$pagedata = array('countriesdata' => $countriesdata);
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/customer-login', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
	}
	
	public function check_user()
	{
		$query = $this->Customer_model->check();
		
		if($query)
		{
			foreach($query as $part){
			$userid = $part->id;
			}
			$newdata = array(
				'email' => $this->input->post('email'),
				'customerid' => $userid,
				'customer_logged_in' => true
			);
			$this->session->set_userdata($newdata);
			$this->Customer_model->remove_code($userid);
			redirect('checkout');
		}
		else 
		{
		redirect('customer-login');
		}
	}
	
	public function create_user()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('street_one', 'street_one', 'required');
		$this->form_validation->set_rules('city', 'city', 'required');
		$this->form_validation->set_rules('county', 'county', 'required');
		$this->form_validation->set_rules('postcode', 'postcode', 'required');
		$this->form_validation->set_rules('country', 'country', 'required');
		
		$useremails = $this->Customer_model->get_emails();
		$emailcheck = array('email' => $this->input->post('email'));
		$emailused = FALSE;
		 if(in_array($emailcheck, $useremails, TRUE)){
			 $emailused = TRUE;
		 }
		
		if($this->form_validation->run() == FALSE or $emailused == TRUE)
		{
			$activetheme = $this->Functions_model->get_template();
			foreach($activetheme as $themebit){
				$theme = $themebit->name;
			}
			$data['email'] = $this->input->post('email');
			$data['phone'] = $this->input->post('phone');
			$data['first_name'] = $this->input->post('first_name');
			$data['last_name'] = $this->input->post('last_name');
			$data['street_one'] = $this->input->post('street_one');
			$data['street_two'] = $this->input->post('street_two');
			$data['city'] = $this->input->post('city');
			$data['county'] = $this->input->post('county');
			$data['postcode'] = $this->input->post('postcode');
			$data['country'] = $this->input->post('country');
			
		$usererror = 'please use an email address that has not been used before<br>and ensure all required fields have been filled in.';
 		$countriesdata = $this->Customer_model->get_countries();
		$pagedata = array(
		 'usererror' => $usererror,
		 'data' => $data,
		 'countriesdata' => $countriesdata
		 );
		 
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$menudata = $this->Customer_model->get_countries();
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/create-customer-error', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
		
		} else {
			$password = hash('sha256', $this->input->post('password'));
			$email = $this->input->post('email');
			$data = array(
			'email' => $email,
			'phone' => $this->input->post('phone'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'password' => $password,
			'street_one' => $this->input->post('street_one'),
			'street_two' => $this->input->post('street_two'),
			'city' => $this->input->post('city'),
			'county' => $this->input->post('county'),
			'postcode' => $this->input->post('postcode'),
			'country' => $this->input->post('country')
			);
			$this->Customer_model->create_user($data);
			$usercheckid = $this->Customer_model->check_user($email);
			foreach($usercheckid as $userpart){
				$customerid = $userpart->id;
			}
			$newdata = array(
				'email' => $this->input->post('email'),
				'customerid' => $customerid,
				'customer_logged_in' => true
			);
			$this->session->set_userdata($newdata);
			redirect('checkout');
		}
	}
	
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('cart');
	}
}