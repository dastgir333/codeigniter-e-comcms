<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page extends CI_Controller {
	function __construct()
	{
		parent::__construct();
	    $this->load->model('Page_model');
		$this->load->library("pagination");
	    $this->load->model('Functions_model');
		$this->statuscheck();
	}
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}

	public function index()
	{
		$check1 = $this->Page_model->get_allpages();
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		
		$uriseg = str_replace($chars, $change1, $this->uri->segment(1));
		$check2 = $uriseg;
		
		$check3 = 'got-nothing';
		
		foreach($check1 as $part){
			if($part->slug == $check2){
				$check3 = 'got-page';
			} 
		}
		
		if($check3 == 'got-nothing'){
			redirect('');
		}
		if($this->session->userdata('is_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => '0',
				'action' => 'viewed page: ' . $this->uri->segment(1),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} elseif($this->session->userdata('customer_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => $this->session->userdata('customerid'),
				'action' => 'viewed page: ' . $this->uri->segment(1),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} else {
			$logdata = array(
				'email' => 'not logged in',
				'customerid' => '0',
				'action' => 'viewed page: ' . $this->uri->segment(1),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		}
		$this->Functions_model->set_log($logdata);
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Page_model->get_header();
		$headerdata = array('headerlogo' => $headerlogo, 'pageheader' => $pageheader, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$data = array();
		$data = $this->Page_model->get_pages();
	
		$parent_data = array('data' => $data);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/page', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
    }
}