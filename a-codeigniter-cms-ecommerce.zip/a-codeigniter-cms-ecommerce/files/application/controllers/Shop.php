<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shop extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Product_model');
	    $this->load->model('Products_model');
	    $this->load->model('Functions_model');
		$this->load->library("pagination");
		$this->load->helper('text');
		$this->statuscheck();
		
	}
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function index()

	{
       $check1 = $this->Product_model->get_allproducts();
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		
		$uriseg = str_replace($chars, $change1, $this->uri->segment(2));
		$check2 = $uriseg;
		
		$check3 = 'got-nothing';
		
		foreach($check1 as $part){
			if($part->slug == $check2){
				$check3 = 'got-products';
			} 
		}
		
		if($check3 == 'got-nothing'){
			redirect('');
		}
		if($this->session->userdata('is_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => $this->session->userdata('customerid'),
				'action' => 'viewed product: ' . $this->uri->segment(2),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} else {
			$logdata = array(
				'email' => 'not logged in',
				'customerid' => '0',
				'action' => 'viewed product: ' . $this->uri->segment(2),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		}
		$this->Functions_model->set_log($logdata);
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$pageheader = $this->Product_model->get_productheader();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo, 'pageheader' => $pageheader, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
	    $data = $this->Product_model->get_products();
		$currency = $this->currency();
		$parent_data = array('data' => $data, 'currency' => $currency);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/product', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
	  
	 }
	 
	 public function category()
	{
		$check1 = $this->Product_model->get_productcats();
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		
		$uriseg = str_replace($chars, $change1, $this->uri->segment(3));
		$check2 = $uriseg;
		
		$check3 = 'got-nothing';
		
		foreach($check1 as $part){
			if($part->slug == $check2){
				$check3 = 'got-productcats';
			} 
		}
		
		if($check3 == 'got-nothing'){
			redirect('');
		}
		
	        $config['base_url'] = base_url() . "shop/category/" . $this->uri->segment(3);
	        $config['total_rows'] = $this->Products_model->productcat_count();
            $config['per_page'] = 9;
	        $config['uri_segment'] = 4;
			
	        $this->pagination->initialize($config);
	     $data4 = array();
	        $data4['results'] = $this->Products_model->get_productscat($config['per_page'], $config['uri_segment']);
	        $data4['links'] = $this->pagination->create_links();
		
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$pageheader = $this->Products_model->get_categoryheader();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo, 'pageheader' => $pageheader, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$currency = $this->currency();
		$catname = str_replace('-', ' ', $this->uri->segment(3));
		$subcat = $this->Products_model->get_subcat();
		$parent_data2 = array('data4' => $data4, 'catname' => $catname, 'currency' => $currency, 'subcat' => $subcat);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/productscategories', $parent_data2);
		$this->load->view($theme . '/footer', $footerdata);
		
	  
	}
	
	public function add_item()
	{
		$cartdata = array(
			'image' => $this->input->post('itemimage'),
            'id' => $this->input->post('item-id'),
            'qty' => $this->input->post('item-quantity'),
            'price' => $this->input->post('item-price'),
            'name' => $this->input->post('item-name'),
            'weight' => $this->input->post('item-weight'),
            'shippingname' => $this->input->post('item-shippingname'),
			'download' => $this->input->post('item-download'),
			'max' => $this->input->post('item-max'),
			'options' => array('zero' => $this->input->post('item-options'))
		);
		$this->cart->insert($cartdata); 
		redirect ('cart');
	}
	
	public function empty_cart() 
	{
		$this->cart->destroy(); 
		redirect ('cart');
	}
	
	public function update_item() {
	
		$data = array(
				   'rowid'      => $this->input->post('item-rowid'),
				   'qty'     => $this->input->post('item-quantity')
				);

		$this->cart->update($data);
		redirect ('cart');
	}
}