<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

  class Comments extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Comments_model');
		$this->load->library("pagination");
	}
	
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	
	public function index()
	{
		$config['base_url'] = base_url() . "be/comments/index";
	    $config['total_rows'] = $this->Comments_model->waiting_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$commentsdata['results'] = $this->Comments_model->get_waiting($config['per_page'], $config['uri_segment']);
	    $commentsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('commentsdata' => $commentsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/comments', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function allow()
	{
		
		$config['base_url'] = base_url() . "be/comments/allow";
	    $config['total_rows'] = $this->Comments_model->allowed_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$commentsdata['results'] = $this->Comments_model->get_allowed($config['per_page'], $config['uri_segment']);
	    $commentsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('commentsdata' => $commentsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/commentsallowed', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function trash()
	{
		$config['base_url'] = base_url() . "be/comments/trash";
	    $config['total_rows'] = $this->Comments_model->trash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$commentsdata['results'] = $this->Comments_model->get_trash($config['per_page'], $config['uri_segment']);
	    $commentsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('commentsdata' => $commentsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/commentstrash', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function setallow()
	{
		$this->Comments_model->allow_row();
		redirect('be/comments');
	}
	public function settrash()
	{
		$this->Comments_model->trash_row();
		redirect('be/comments');
	}
	public function setwaiting()
	{
		$this->Comments_model->waiting_row();
		redirect('be/comments');
	}
	public function setdelete()
	{
		$this->Comments_model->delete_row();
		redirect('be/comments');
	}
 }