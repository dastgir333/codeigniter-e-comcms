<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Productcategories extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Productcategories_model');
		$this->load->library("pagination");
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/productcategories/index";
	    $config['total_rows'] = $this->Productcategories_model->productcategories_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productcategoriesdata['results'] = $this->Productcategories_model->get_productcategories($config['per_page'], $config['uri_segment']);
	    $productcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productcategoriesdata' => $productcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/productcategories', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function drafts(){
		
		$config['base_url'] = base_url() . "be/productcategories/drafts";
	    $config['total_rows'] = $this->Productcategories_model->productcategoriesdrafts_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productcategoriesdata['results'] = $this->Productcategories_model->get_productcategoriesdrafts($config['per_page'], $config['uri_segment']);
	    $productcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productcategoriesdata' => $productcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/productcategoriesdrafts', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function trash(){
		
		$config['base_url'] = base_url() . "be/productcategories/trash";
	    $config['total_rows'] = $this->Productcategories_model->productcategoriestrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productcategoriesdata['results'] = $this->Productcategories_model->get_productcategoriestrash($config['per_page'], $config['uri_segment']);
	    $productcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productcategoriesdata' => $productcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/productcategoriestrash', $parentdata);
		$this->load->view('be' . '/footer');
    }
	public function setdraft()
	{
		$this->Productcategories_model->draft_row();
		redirect('be/productcategories/drafts');
	}
	public function settrash()
	{
		$this->Productcategories_model->trash_row();
		redirect('be/productcategories/trash');
	}
	public function setrestore()
	{
		$this->Productcategories_model->restore_row();
		redirect('be/productcategories');
	}
	public function setdelete()
	{
		$this->Productcategories_model->delete_row();
		redirect('be/productcategories/trash');
	}
}