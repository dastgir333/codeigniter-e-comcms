<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createpage extends CI_Controller {
		public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
		$this->load->model('Createpage_model');
		$this->load->helper('text');
	}

		public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('index.php');
		}		
	}
	
		
	public function index()
	{
		
		$images = $this->Createpage_model->get_images();
		$pagedata = array(
		'images' => $images
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/createpage', $pagedata);
		$this->load->view('be' . '/footer');
		
	}
	
	
	public function create()
	{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('content', 'content', 'required');
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('description', 'description','trim|required');
		$this->form_validation->set_rules('keywords', 'keywords', 'trim|required');
		
		$data['name'] = $this->input->post('name');
		$data['content'] = $this->input->post('content');
		$data['description'] = $this->input->post('description');
		$data['keywords'] = $this->input->post('keywords');
		$data['videolink'] = $this->input->post('videolink');
	    $data['sort'] = $this->input->post('sort');
		
		if($this->form_validation->run() == FALSE)
		{

		$images = $this->Createpage_model->get_images();
		$pagedata = array('images' => $images, 'data' => $data);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/createpage-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		
		$pagenames = $this->Createpage_model->get_pagenames();
		$slugnames = $this->Createpage_model->get_slugnames();
		
		$pname = $this->input->post('name');
		$pname2 = strtolower($pname);
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â');
		$change1 = '';
		$pname3 = str_replace($chars, $change1, $pname2);
		$search1 = ' ';
		 $replace1 = '-';
		 $check = str_replace($search1, $replace1, $pname3);
		 $check2 = array('slug' => $check);
		 
		 if(in_array($check2, $slugnames, TRUE)){
		   $n = 2;
		   foreach($pagenames as $names){
		   $chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?','Â£','Â');
		   $change = '';
		   $pn1 = str_replace($chars, $change, $names['name']);
		     if($pname3 != $pn1){
		       $check2 = 2;
		       } else{
		       $check2 = $n++;
		     }
		    }
		   $newslug = $check . '-' . $check2;
		  } else {
		    $newslug = $check;
		   }
		if($this->input->post('trash') == null){
			$trash = '0';
		} else {
			$trash = $this->input->post('trash');
		}
		$data = array(
			'name' => $this->input->post('name'),
			'content' => $this->input->post('content'),
			'title' => $this->input->post('name'),
			'description' => $this->input->post('description'),
			'keywords' => $this->input->post('keywords'),
			'trash' => $trash,
			'slug' => $newslug,
			'videolink' => $this->input->post('videolink'),
			'sort' => $this->input->post('sort')
		);
		
		$this->Createpage_model->add_record($data);
		redirect('be/pages');
	  }
	}
}