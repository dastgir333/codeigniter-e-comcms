<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Posts extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Posts_model');
		$this->load->library("pagination");
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/posts/index";
	    $config['total_rows'] = $this->Posts_model->posts_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postsdata['results'] = $this->Posts_model->get_posts($config['per_page'], $config['uri_segment']);
	    $postsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postsdata' => $postsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/posts', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function drafts(){
		
		$config['base_url'] = base_url() . "be/posts/drafts";
	    $config['total_rows'] = $this->Posts_model->postsdrafts_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postsdata['results'] = $this->Posts_model->get_postsdrafts($config['per_page'], $config['uri_segment']);
	    $postsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postsdata' => $postsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/postsdrafts', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function trash(){
		
		$config['base_url'] = base_url() . "be/posts/trash";
	    $config['total_rows'] = $this->Posts_model->poststrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postsdata['results'] = $this->Posts_model->get_poststrash($config['per_page'], $config['uri_segment']);
	    $postsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postsdata' => $postsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/poststrash', $parentdata);
		$this->load->view('be' . '/footer');
    }
	public function setdraft()
	{
		$this->Posts_model->draft_row();
		redirect('be/posts/drafts');
	}
	public function settrash()
	{
		$this->Posts_model->trash_row();
		redirect('be/posts/trash');
	}
	public function setrestore()
	{
		$this->Posts_model->restore_row();
		redirect('be/posts');
	}
	public function setdelete()
	{
		$this->Posts_model->delete_row();
		redirect('be/posts/trash');
	}
}