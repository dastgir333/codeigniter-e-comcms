<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stats extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Stats_model');
		$this->load->helper('text');
		$this->load->library('pagination');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	
	public function index()
	{
		$config['base_url'] = base_url() . "be/stats/index";
	    $config['total_rows'] = $this->Stats_model->stats_logcount();
		$config['per_page'] = 20;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$logs['results'] = $this->Stats_model->get_statslogs($config['per_page'], $config['uri_segment']);
	    $logs['links'] = $this->pagination->create_links();	
 		 $pagedata = array(
		 'logs' => $logs
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/stats', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function all()
	{
		$config['base_url'] = base_url() . "be/stats/all";
	    $config['total_rows'] = $this->Stats_model->stats_logcountall();
		$config['per_page'] = 20;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$logs['results'] = $this->Stats_model->get_statslogsall($config['per_page'], $config['uri_segment']);
	    $logs['links'] = $this->pagination->create_links();	
 		 $pagedata = array(
		 'logs' => $logs
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/statsall', $pagedata);
		$this->load->view('be' . '/footer');
	}
}
