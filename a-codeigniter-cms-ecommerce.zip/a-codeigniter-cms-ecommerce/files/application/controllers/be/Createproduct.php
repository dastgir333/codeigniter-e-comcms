<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createproduct extends CI_Controller {
		public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
		$this->load->model('Createproduct_model');
		$this->load->helper('text');
	}

		public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('index.php');
		}		
	}
	
		
	public function index()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Createproduct_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$catlist = $this->Createproduct_model->get_productscategory();
		$images = $this->Createproduct_model->get_images();
		$downloads = $this->Createproduct_model->get_downloads();
		$shippingname = $this->Createproduct_model->get_shippingtype();
		$pagedata = array(
		'images' => $images,
		'catlist' => $catlist,
		'downloads' => $downloads,
		'shippingname' => $shippingname,
		'currency' => $currency
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/createproduct', $pagedata);
		$this->load->view('be' . '/footer');
		
	}
	
	
		public function create()
		{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('content', 'content', 'required');
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('price', 'price','trim|required');
		$this->form_validation->set_rules('description', 'description','trim|required');
		$this->form_validation->set_rules('keywords', 'keywords', 'trim|required');
		
		$data['name'] = $this->input->post('name');
		$data['content'] = $this->input->post('content');
		$data['description'] = $this->input->post('description');
		$data['keywords'] = $this->input->post('keywords');
		$data['videolink'] = $this->input->post('videolink');
		$data['download'] = $this->input->post('download');
		$data['category'] = $this->input->post('category');
		$data['price'] = $this->input->post('price');
		$data['weight'] = $this->input->post('weight');
		$data['stock'] = $this->input->post('stock');
		$data['shippingname'] = $this->input->post('shippingname');
		$data['options'] = $this->input->post('options');
		
		if($this->form_validation->run() == FALSE)
		{

		$currency = '&pound;';
		$currencyinfo = $this->Createproduct_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$catlist = $this->Createproduct_model->get_productscategory();
		$images = $this->Createproduct_model->get_images();
		$downloads = $this->Createproduct_model->get_downloads();
		$shippingname = $this->Createproduct_model->get_shippingtype();
		$pagedata = array('images' => $images, 'data' => $data, 'catlist' => $catlist, 'downloads' => $downloads, 'shippingname' => $shippingname, 'currency' => $currency);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/createproduct-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		
		$productnames = $this->Createproduct_model->get_productnames();
		$slugnames = $this->Createproduct_model->get_slugnames();
		
		$pname = $this->input->post('name');
		$pname2 = strtolower($pname);
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â');
		$change1 = '';
		$pname3 = str_replace($chars, $change1, $pname2);
		$search1 = ' ';
		 $replace1 = '-';
		 $check = str_replace($search1, $replace1, $pname3);
		 $check2 = array('slug' => $check);
		 
		 if(in_array($check2, $slugnames, TRUE)){
		   $n = 2;
		   foreach($postnames as $names){
		   $chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?','Â£','Â');
		   $change = '';
		   $pn1 = str_replace($chars, $change, $names['name']);
		     if($pname3 != $pn1){
		       $check2 = 2;
		       } else{
		       $check2 = $n++;
		     }
		    }
		   $newslug = $check . '-' . $check2;
		  } else {
		    $newslug = $check;
		   }
		   $categorylist = $this->input->post('category');
		$catarray = explode(',', $categorylist);
		if(isset($catarray['0'])) {
		   if($catarray['0'] == '') {
		   $cat1 = '';
			$cat1a = '';
			} else {
			$cat1 = $catarray['0'];
			$cat1a = ',';
			}
		} else {
		    $cat1 = '';
			$cat1a = '';
		}
		if(isset($catarray['1'])) {
		   if($catarray['1'] == '') {
		   $cat2 = '';
			$cat2a = '';
			} else {
			$cat2 = $catarray['1'];
			$cat2a = ',';
			}
		} else {
		    $cat2 = '';
			$cat2a = '';
		}
		if(isset($catarray['2'])) {
		  if($catarray['2'] == '') {
		   $cat3 = '';
			$cat3a = '';
			} else {
			$cat3 = $catarray['2'];
			$cat3a = ',';
			}
		} else {
		    $cat3 = '';
			$cat3a = '';
		}
		$newcat = $cat1 . $cat1a . $cat2 . $cat2a . $cat3 . $cat3a;
		
		$data = array(
			'name' => $this->input->post('name'),
			'content' => $this->input->post('content'),
			'title' => $this->input->post('name'),
			'description' => $this->input->post('description'),
			'keywords' => $this->input->post('keywords'),
			'trash' => '0',
			'slug' => $newslug,
			'catlist' => $newcat,
			'category' => $cat1,
			'category2' => $cat2,
			'category3' => $cat3,
			'videolink' => $this->input->post('videolink'),
			'download' => $this->input->post('download'),
			'price' => $this->input->post('price'),
			'weight' => $this->input->post('weight'),
			'stock' => $this->input->post('stock'),
			'shippingname' => $this->input->post('shippingname'),
			'options' => $this->input->post('options')
		);
		
		$this->Createproduct_model->add_record($data);
		redirect('be/products');
	  }
	}
}