<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editpost extends CI_Controller {
		public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
		$this->load->model('Editpost_model');
		$this->load->helper('text');
	}

		public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('index.php');
		}		
	}
	
	public function edit()
	{
		$catlist = $this->Editpost_model->get_postscategory();
		$images = $this->Editpost_model->get_images();
		$post = $this->Editpost_model->get_post();
		$pagedata = array(
		'post' => $post,
		'images' => $images,
		'catlist' => $catlist
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/editpost', $pagedata);
		$this->load->view('be' . '/footer');
		
	}
	
	public function update()
		{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('content', 'content', 'required');
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('description', 'description','trim|required');
		$this->form_validation->set_rules('keywords', 'keywords', 'trim|required');
		
		$data['id'] = $this->input->post('id');
		$data['name'] = $this->input->post('name');
		$data['content'] = $this->input->post('content');
		$data['description'] = $this->input->post('description');
		$data['keywords'] = $this->input->post('keywords');
		$data['videolink'] = $this->input->post('videolink');
		$data['category'] = $this->input->post('category');
		
		if($this->form_validation->run() == FALSE)
		{

		$catlist = $this->Editpost_model->get_postscategory();
		$images = $this->Editpost_model->get_images();
		$pagedata = array('images' => $images, 'data' => $data, 'catlist' => $catlist);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/editpost-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		
		   $categorylist = $this->input->post('category');
		$catarray = explode(',', $categorylist);
		if(isset($catarray['0'])) {
		   if($catarray['0'] == '') {
		   $cat1 = '';
			$cat1a = '';
			} else {
			$cat1 = $catarray['0'];
			$cat1a = ',';
			}
		} else {
		    $cat1 = '';
			$cat1a = '';
		}
		if(isset($catarray['1'])) {
		   if($catarray['1'] == '') {
		   $cat2 = '';
			$cat2a = '';
			} else {
			$cat2 = $catarray['1'];
			$cat2a = ',';
			}
		} else {
		    $cat2 = '';
			$cat2a = '';
		}
		if(isset($catarray['2'])) {
		  if($catarray['2'] == '') {
		   $cat3 = '';
			$cat3a = '';
			} else {
			$cat3 = $catarray['2'];
			$cat3a = ',';
			}
		} else {
		    $cat3 = '';
			$cat3a = '';
		}
		$newcat = $cat1 . $cat1a . $cat2 . $cat2a . $cat3 . $cat3a;
		
		if($this->input->post('trash') == null){
			$trash = '0';
		} else {
			$trash = $this->input->post('trash');
		}
		if($this->input->post('comments') == null){
			$comments = '0';
		} else {
			$comments = $this->input->post('comments');
		}
		
		$data2 = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'content' => $this->input->post('content'),
			'title' => $this->input->post('name'),
			'description' => $this->input->post('description'),
			'keywords' => $this->input->post('keywords'),
			'trash' => $trash,
			'catlist' => $newcat,
			'category' => $cat1,
			'category2' => $cat2,
			'category3' => $cat3,
			'videolink' => $this->input->post('videolink'),
			'comments' => $comments
		);
		
		$this->Editpost_model->update_record($data2);
		redirect('be/posts');
	  }
	}
}