<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Messages_model');
		$this->load->library("pagination");
		$this->load->library('email');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/messages/index";
	    $config['total_rows'] = $this->Messages_model->messages_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$messagesdata['results'] = $this->Messages_model->get_messages($config['per_page'], $config['uri_segment']);
	    $messagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('messagesdata' => $messagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/messages', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function saved(){
		
		$config['base_url'] = base_url() . "be/messages/saved";
	    $config['total_rows'] = $this->Messages_model->messagessaved_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$messagesdata['results'] = $this->Messages_model->get_messagessaved($config['per_page'], $config['uri_segment']);
	    $messagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('messagesdata' => $messagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/messagessaved', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function trash(){
		
		$config['base_url'] = base_url() . "be/messages/trash";
	    $config['total_rows'] = $this->Messages_model->messagestrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$messagesdata['results'] = $this->Messages_model->get_messagestrash($config['per_page'], $config['uri_segment']);
	    $messagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('messagesdata' => $messagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/messagestrash', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function sent(){
		
		$config['base_url'] = base_url() . "be/messages/sent";
	    $config['total_rows'] = $this->Messages_model->messagessent_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$messagesdata['results'] = $this->Messages_model->get_messagessent($config['per_page'], $config['uri_segment']);
	    $messagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('messagesdata' => $messagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/messagessent', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function setsaved()
	{
		$this->Messages_model->save_row();
		redirect('be/messages/saved');
	}
	public function settrash()
	{
		$this->Messages_model->trash_row();
		redirect('be/messages/trash');
	}
	public function setrestore()
	{
		$this->Messages_model->restore_row();
		redirect('be/messages');
	}
	public function setdelete()
	{
		$this->Messages_model->delete_row();
		redirect('be/messages/trash');
	}
	public function view()
	{
		$viewmessage = $this->Messages_model->get_message();
		$pagedata = array(
		'viewmessage' => $viewmessage
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/viewmessage', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function reply()
	{
		$viewmessage = $this->Messages_model->get_message();
		$pagedata = array(
		'viewmessage' => $viewmessage
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/replymessage', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function send()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email','required');
		$this->form_validation->set_rules('message', 'message', 'required');
		
		
		if($this->form_validation->run() == FALSE)
		{
			redirect('be/messages');
		} else {
			
		$settingemail = $this->Messages_model->get_settingsemail();
		foreach ($settingemail as $row) {
			$siteemail = $row->email;
			$sitetitle = $row->title;
			$sitetimezone = $row->timezone;
		}
		date_default_timezone_set($sitetimezone);
		$odate = date("F j, Y, g:i a");
		$messagedata = array(
		    'email' => $this->input->post('email'),
			'message' => $this->input->post('message'),
			'status' => '3',
			'originaldate' => $odate
		);
		
		$this->Messages_model->send($messagedata);
		
		$emailcontent = '<!DOCTYPE html>
 <head>
  <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
  <title>order</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head><body>' . $messagedata['message'] .'</body></html>';
		
			$config['mailtype'] = 'html';
			$this->email->initialize($config);
			
			$this->email->to($messagedata['email']);
			$this->email->from($siteemail);
			$this->email->subject('reply from ' . $sitetitle);
			$this->email->message($emailcontent);
		
        $this->email->send();
	
		redirect('be/messages');
		}
	}
}