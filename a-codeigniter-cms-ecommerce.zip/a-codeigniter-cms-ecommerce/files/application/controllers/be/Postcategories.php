<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Postcategories extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Postcategories_model');
		$this->load->library("pagination");
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/postcategories/index";
	    $config['total_rows'] = $this->Postcategories_model->postcategories_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postcategoriesdata['results'] = $this->Postcategories_model->get_postcategories($config['per_page'], $config['uri_segment']);
	    $postcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postcategoriesdata' => $postcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/postcategories', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function drafts(){
		
		$config['base_url'] = base_url() . "be/postcategories/drafts";
	    $config['total_rows'] = $this->Postcategories_model->postcategoriesdrafts_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postcategoriesdata['results'] = $this->Postcategories_model->get_postcategoriesdrafts($config['per_page'], $config['uri_segment']);
	    $postcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postcategoriesdata' => $postcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/postcategoriesdrafts', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function trash(){
		
		$config['base_url'] = base_url() . "be/postcategories/trash";
	    $config['total_rows'] = $this->Postcategories_model->postcategoriestrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$postcategoriesdata['results'] = $this->Postcategories_model->get_postcategoriestrash($config['per_page'], $config['uri_segment']);
	    $postcategoriesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('postcategoriesdata' => $postcategoriesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/postcategoriestrash', $parentdata);
		$this->load->view('be' . '/footer');
    }
	public function setdraft()
	{
		$this->Postcategories_model->draft_row();
		redirect('be/postcategories/drafts');
	}
	public function settrash()
	{
		$this->Postcategories_model->trash_row();
		redirect('be/postcategories/trash');
	}
	public function setrestore()
	{
		$this->Postcategories_model->restore_row();
		redirect('be/postcategories');
	}
	public function setdelete()
	{
		$this->Postcategories_model->delete_row();
		redirect('be/postcategories/trash');
	}
}