<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Gallery extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
		$this->load->model('Functions_model');
	    $this->load->model('Galleries_model');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('index.php');
			die();		

		}		
	}
	public function index()
	{
		if($this->input->post('upload')){
		   $this->Galleries_model->do_upload();
		}
		
		$data = $this->Galleries_model->get_pics();
		$pagedata = array(
		'data' => $data
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/gallery', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function trash()
	{	
		$data = $this->Galleries_model->get_picstrash();
		$pagedata = array(
		'data' => $data
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/gallerytrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function update()
	{
		$this->load->library('form_validation');
		// field name, error message, validation rules
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('description', 'description', 'trim|required');
		
		if($this->form_validation->run() == FALSE)
		{

		if($this->input->post('upload')){
		   $this->Galleries_model->do_upload();
		}
		
		$data = $this->Galleries_model->get_pics();
		$pagedata = array(
		'data' => $data
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/gallery', $pagedata);
		$this->load->view('be' . '/footer');

		}
	else
		{
		$data2 = array(
		    'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'description' => $this->input->post('description')
		);
		
		$this->Galleries_model->update($data2);
		redirect('be/gallery');
	   }
	}
	
	public function trashpic()
	{
		$this->Galleries_model->trash_row();
		redirect('be/gallery');
	}
	public function restorepic()
	{
		$this->Galleries_model->restore_row();
		redirect('be/gallery/trash');
	}
	public function deletepic()
	{
		$this->Galleries_model->delete_row();
		redirect('be/gallery/trash');
	}
	public function submit()
	{
		   $this->Galleries_model->do_upload();
		   $this->load->view('be/submitted');		
	}
	
}