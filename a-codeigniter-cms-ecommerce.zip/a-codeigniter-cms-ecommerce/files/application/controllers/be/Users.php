<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Users_model');
		$this->load->helper('text');
	}
	
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	
	public function index()
	{
		 $users = $this->Users_model->get_users();
 		 $pagedata = array(
		 'users' => $users
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/users', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function trash()
	{
		 $users = $this->Users_model->get_userstrash();
 		 $pagedata = array(
		 'users' => $users
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/userstrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function edit()
	{
		 $user = $this->Users_model->get_user();
 		 $pagedata = array(
		 'user' => $user
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/usersedit', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function create()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		
		$useremails = $this->Users_model->get_emails();
		$emailcheck = array('email' => $this->input->post('email'));
		$emailused = FALSE;
		 if(in_array($emailcheck, $useremails, TRUE)){
			 $emailused = TRUE;
		 }
		
		if($this->form_validation->run() == FALSE or $emailused == TRUE)
		{
			$users = $this->Users_model->get_users();
			$usererror = 'please use an email address that has not been used before<br>and all fields are required.';
 		 $pagedata = array(
		 'users' => $users,
		 'usererror' => $usererror
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/users', $pagedata);
		$this->load->view('be' . '/footer');
		} else {
			$password = hash('sha256', $this->input->post('password'));
			$data = array(
			'email' => $this->input->post('email'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'password' => $password
			);
			$this->Users_model->create_user($data);
			redirect('be/users');
		}
	}
	
	public function update()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		
		$userid = $this->input->post('id');
		$useremails = $this->Users_model->get_emailsedit($userid);
		$emailcheck = array('email' => $this->input->post('email'));
		$emailused = FALSE;
		 if(in_array($emailcheck, $useremails, TRUE)){
			 $emailused = TRUE;
		 }
		
		if($this->form_validation->run() == FALSE or $emailused == TRUE)
		{
			$user['id'] = $this->input->post('id');
			$user['email'] = $this->input->post('email');
			$user['first_name'] = $this->input->post('first_name');
			$user['last_name'] = $this->input->post('last_name');
			$usererror = 'please use an email address that has not been used before<br>and all fields are required.';
 		 $pagedata = array(
		 'user' => $user,
		 'usererror' => $usererror
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/usersediterror', $pagedata);
		$this->load->view('be' . '/footer');
		} else {
			if($this->input->post('password') != null){
				$password = hash('sha256', $this->input->post('password'));	
				$data = array(
				'id' => $this->input->post('id'),
				'email' => $this->input->post('email'),
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name'),
				'password' => $password
				);
			} else {
				$data = array(
				'id' => $this->input->post('id'),
				'email' => $this->input->post('email'),
				'first_name' => $this->input->post('first_name'),
				'last_name' => $this->input->post('last_name')
				);
			}
			
			$this->Users_model->update_user($data);
			redirect('be/users');
		}
	}
	public function settrash()
	{
		$this->Users_model->trash_row();
		redirect('be/users/trash');
	}
	public function setrestore()
	{
		$this->Users_model->restore_row();
		redirect('be/users');
	}
	public function setdelete()
	{
		$this->Users_model->delete_row();
		redirect('be/users/trash');
	}
}

