<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Help extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Help_model');
	}
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	public function index()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function pages()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-pages', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function posts()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-posts', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function products()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-products', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function gallery()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-gallery', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function dash()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-dash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function shipping()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-shipping', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function discounts()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-discounts', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function invoices()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-invoices', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function customers()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-customers', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function messages()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-messages', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function stats()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-stats', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function users()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-users', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function settings()
	{
		
		$pagedata = array(
			
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be/help' . '/help-settings', $pagedata);
		$this->load->view('be' . '/footer');
	}
}