<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sessiondata extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Sessiondata_model');
		$this->load->helper('text');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	
	
	public function index()
	{
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/sessiondata');
		$this->load->view('be' . '/footer');
	}
	public function deletedata()
	{
		$this->Sessiondata_model->delete_data();
		redirect('sessiondata');
	}
}