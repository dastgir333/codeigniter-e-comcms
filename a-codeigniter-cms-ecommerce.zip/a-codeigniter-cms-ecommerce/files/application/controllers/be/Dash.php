<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dash extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Dash_model');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index()
	{	
	 $dashposts = $this->Dash_model->get_posts();
	 $dashpages = $this->Dash_model->get_pages();
	 $dashproducts = $this->Dash_model->get_products();
	 $dashmessages = $this->Dash_model->get_messages();
	 
	 $pagedata = array(
	 'dashposts' => $dashposts,
	 'dashpages' => $dashpages,
	 'dashproducts' => $dashproducts,
	 'dashmessages' => $dashmessages
	 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/dash', $pagedata);
		$this->load->view('be' . '/footer');
		
    }
}