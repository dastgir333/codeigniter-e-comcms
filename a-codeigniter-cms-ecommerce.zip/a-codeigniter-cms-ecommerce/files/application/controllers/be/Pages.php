<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pages extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Pages_model');
		$this->load->library("pagination");
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/pages/index";
	    $config['total_rows'] = $this->Pages_model->pages_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$pagesdata['results'] = $this->Pages_model->get_pages($config['per_page'], $config['uri_segment']);
	    $pagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('pagesdata' => $pagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/pages', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function drafts(){
		
		$config['base_url'] = base_url() . "be/pages/drafts";
	    $config['total_rows'] = $this->Pages_model->pagesdrafts_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$pagesdata['results'] = $this->Pages_model->get_pagesdrafts($config['per_page'], $config['uri_segment']);
	    $pagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('pagesdata' => $pagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/pagesdrafts', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function trash(){
		
		$config['base_url'] = base_url() . "be/pages/trash";
	    $config['total_rows'] = $this->Pages_model->pagestrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$pagesdata['results'] = $this->Pages_model->get_pagestrash($config['per_page'], $config['uri_segment']);
	    $pagesdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('pagesdata' => $pagesdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/pagestrash', $parentdata);
		$this->load->view('be' . '/footer');
		
    }
	public function setdraft()
	{
		$this->Pages_model->draft_row();
		redirect('be/pages/drafts');
	}
	public function settrash()
	{
		$this->Pages_model->trash_row();
		redirect('be/pages/trash');
	}
	public function setrestore()
	{
		$this->Pages_model->restore_row();
		redirect('be/pages');
	}
	public function setdelete()
	{
		$this->Pages_model->delete_row();
		redirect('be/pages/trash');
	}
}