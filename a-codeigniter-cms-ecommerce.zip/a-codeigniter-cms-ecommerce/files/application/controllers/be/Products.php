<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Products_model');
		$this->load->library("pagination");
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	

	public function index(){
		
		$config['base_url'] = base_url() . "be/products/index";
	    $config['total_rows'] = $this->Products_model->products_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productsdata['results'] = $this->Products_model->get_products($config['per_page'], $config['uri_segment']);
	    $productsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productsdata' => $productsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/products', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function drafts(){
		
		$config['base_url'] = base_url() . "be/products/drafts";
	    $config['total_rows'] = $this->Products_model->productsdrafts_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productsdata['results'] = $this->Products_model->get_productsdrafts($config['per_page'], $config['uri_segment']);
	    $productsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productsdata' => $productsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/productsdrafts', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function trash(){
		
		$config['base_url'] = base_url() . "be/products/trash";
	    $config['total_rows'] = $this->Products_model->productstrash_count();
		$config['per_page'] = 5;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$productsdata['results'] = $this->Products_model->get_productstrash($config['per_page'], $config['uri_segment']);
	    $productsdata['links'] = $this->pagination->create_links();
		
		$parentdata = array('productsdata' => $productsdata);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/productstrash', $parentdata);
		$this->load->view('be' . '/footer');
    }
	
	public function setdraft()
	{
		$this->Products_model->draft_row();
		redirect('be/products/drafts');
	}
	public function settrash()
	{
		$this->Products_model->trash_row();
		redirect('be/products/trash');
	}
	public function setrestore()
	{
		$this->Products_model->restore_row();
		redirect('be/products');
	}
	public function setdelete()
	{
		$this->Products_model->delete_row();
		redirect('be/products/trash');
	}
}