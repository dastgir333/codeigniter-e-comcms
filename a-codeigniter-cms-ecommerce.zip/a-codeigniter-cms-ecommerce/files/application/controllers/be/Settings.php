<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Settings_model');
		$this->load->helper('text');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	
	
	public function index()
	{	
	
	        $dir = $_SERVER['SCRIPT_FILENAME'];
			$dir2 = str_replace('index.php', '', $dir);
			$dir3 = $dir2 . 'css';
	        $dircontents = scandir($dir3);
	 
	 $sitemapdata = $this->Settings_model->get_sitemap();
	 $settingsdata = $this->Settings_model->get_settings();
	 $menudata = $this->Settings_model->get_menusettings();
	 $templatedata = $this->Settings_model->get_templatesettings();
	 $gallerydata = $this->Settings_model->get_images();
	 $logo = $this->Settings_model->get_logo();
	 $pagedata = array(
	 'settingsdata' => $settingsdata,
	 'sitemapdata' => $sitemapdata,
	 'menudata' => $menudata,
	 'templatedata' => $templatedata,
	 'dircontents' => $dircontents,
	 'gallerydata' => $gallerydata,
	 'logo' => $logo
	 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/settings', $pagedata);
		$this->load->view('be' . '/footer');
		
    }
	public function payment()
	{	
	 $invoiceprefix = $this->Settings_model->get_invoiceprefix();
	 $settingsdata = $this->Settings_model->get_settings();
	 $pagedata = array(
		'settingsdata' => $settingsdata,
		'invoiceprefix' => $invoiceprefix
	 );
	 
	$this->load->view('be' . '/header');
	$this->load->view('be' . '/settingspayment', $pagedata);
	$this->load->view('be' . '/footer');
		
    }
	
	public function edit()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('tagline', 'tagline', 'required');
		$this->form_validation->set_rules('status', 'status', 'required');
		$this->form_validation->set_rules('timezone', 'timezone', 'required');
		$this->form_validation->set_rules('template', 'template', 'required');
		$this->form_validation->set_rules('pagemenu', 'pagemenu', 'required');
		$this->form_validation->set_rules('postmenu', 'postmenu', 'required');
		
		
		$data['email'] = $this->input->post('email');
		$data['title'] = $this->input->post('title');
		$data['tagline'] = $this->input->post('tagline');
		$data['status'] = $this->input->post('status');
		$data['timezone'] = $this->input->post('timezone');
		$data['template'] = $this->input->post('template');
		$data['pagemenu'] = $this->input->post('pagemenu');
		$data['postmenu'] = $this->input->post('postmenu');
		$data['productmenu'] = $this->input->post('productmenu');
		
		if($this->form_validation->run() == FALSE)
		{
			$dir = $_SERVER['SCRIPT_FILENAME'];
			$dir2 = str_replace('index.php', '', $dir);
			$dir3 = $dir2 . 'css';
	        $dircontents = scandir($dir3);

		$pagedata = array(
		'data' => $data,
		'dircontents' => $dircontents
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/settings-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
			$data = array(
			'email' => $this->input->post('email'),
			'title' => $this->input->post('title'),
			'tagline' => $this->input->post('tagline'),
			'status' => $this->input->post('status'),
			'timezone' => $this->input->post('timezone')
			);
			
			$pagemenudata = array(
			'status' => $this->input->post('pagemenu')
			);
			$postmenudata = array(
			'status' => $this->input->post('postmenu')
			);
			$productmenudata = array(
			'status' => $this->input->post('productmenu')
			);
			$templatedata = array(
			'name' => $this->input->post('template')
			);
			$logodata = array(
			'image' => $this->input->post('logo')
			);
			$this->Settings_model->update_record($data);
			$this->Settings_model->update_pagemenurecord($pagemenudata);
			$this->Settings_model->update_postmenurecord($postmenudata);
			$this->Settings_model->update_productmenurecord($productmenudata);
			$this->Settings_model->update_templaterecord($templatedata);
			
			if($this->input->post('logo') != null){
			$this->Settings_model->update_logorecord($logodata);
			}
			redirect('be/settings');
		}
	}
	
	public function editpayment()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('currency', 'currency', 'required');
		$this->form_validation->set_rules('currencysign', 'currencysign', 'required');
		$this->form_validation->set_rules('invoiceprefix', 'invoiceprefix', 'required');
		
		
		$data['email'] = $this->input->post('email');
		$data['currency'] = $this->input->post('currency');
		$data['currencysign'] = $this->input->post('currencysign');
		$data['invoiceprefix'] = $this->input->post('invoiceprefix');
		
		if($this->form_validation->run() == FALSE)
		{
		$pagedata = array(
		'data' => $data
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/settingspayment-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
			$data = array(
			'paymentemail' => $this->input->post('email'),
			'currency' => $this->input->post('currency'),
			'currencysign' => $this->input->post('currencysign')
			);
			$data2 = array(
			'prefix' => $this->input->post('invoiceprefix')
			);
			$this->Settings_model->update_record($data);
			$this->Settings_model->update_invoiceprefix($data2);
			redirect('be/settings/payment');
		}
	}
	public function sitemap()
	{
		$data2 = array('updated' => gmdate('l jS \of F Y h:i:s A'));
		$this->load->library('sitemap');
		$this->sitemap->generate();
		$this->Settings_model->updatesitemap($data2); 
		redirect('be/settings');

	}
	public function slider()
	{
			$slideroption = $this->Settings_model->get_slideroption();
			$sliderinfo = $this->Settings_model->get_sliderinfo();
			$gallerydata = $this->Settings_model->get_images();
			$pagedata = array(
				'sliderinfo' => $sliderinfo,
				'slideroption' => $slideroption,
				'gallerydata' => $gallerydata
			);
			$this->load->view('be' . '/header');
			$this->load->view('be' . '/settings-slider', $pagedata);
			$this->load->view('be' . '/footer');
	}
	public function saveslideroptions()
	{
		
			$image1 = $this->input->post('image1');
			$image2 = $this->input->post('image2');
			$image3 = $this->input->post('image3');
			if($image1 == 'select image'){
				$data1 = array(
				'title' => $this->input->post('title1'),
				'description' => $this->input->post('description1'),
				'slug' => $this->input->post('link1')
				);
			} else {
				$data1 = array(
				'content' => '<img src="' . base_url() . 'images/gallery/' . $image1 . '" />',
				'title' => $this->input->post('title1'),
				'description' => $this->input->post('description1'),
				'slug' => $this->input->post('link1')
				);

			}
			if($image2 == 'select image'){
				$data2 = array(
				'title' => $this->input->post('title2'),
				'description' => $this->input->post('description2'),
				'slug' => $this->input->post('link2')
				);
			} else {
				$data2 = array(
				'content' => '<img src="' . base_url() . 'images/gallery/' . $image2 . '" />',
				'title' => $this->input->post('title2'),
				'description' => $this->input->post('description2'),
				'slug' => $this->input->post('link2')
				);
			}
			if($image3 == 'select image'){
				$data3 = array(
				'title' => $this->input->post('title3'),
				'description' => $this->input->post('description3'),
				'slug' => $this->input->post('link3')
				);
			} else {
				$data3 = array(
				'content' => '<img src="' . base_url() . 'images/gallery/' . $image3 . '" />',
				'title' => $this->input->post('title3'),
				'description' => $this->input->post('description3'),
				'slug' => $this->input->post('link3')
				);
			}
			if($this->input->post('slideroption') != 'select option'){
				$slideroption = array(
				'slideroption' => $this->input->post('slideroption')
				);
				$this->Settings_model->update_slideroption($slideroption);
			}
			
			$this->Settings_model->update_sliderone($data1);
			$this->Settings_model->update_slidertwo($data2);
			$this->Settings_model->update_sliderthree($data3);
			redirect('be/settings/slider-options');
			
	}
}