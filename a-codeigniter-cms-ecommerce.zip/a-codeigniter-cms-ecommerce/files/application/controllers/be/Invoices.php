<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Invoices extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Invoices_model');
		$this->load->library("pagination");
	}
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	public function index()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Invoices_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$config['base_url'] = base_url() . "be/invoices/index";
	    $config['total_rows'] = $this->Invoices_model->invoices_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$invoices['results'] = $this->Invoices_model->get_invoices($config['per_page'], $config['uri_segment']);
	    $invoices['links'] = $this->pagination->create_links();
		
		$pagedata = array(
			 'invoices' => $invoices,
			'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/invoices', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function view()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Invoices_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$invoice = $this->Invoices_model->get_invoice();
		foreach($invoice as $part){
			$number = $part->invoice;
		}
		$orderedproducts = $this->Invoices_model->get_orderedproducts($number);
		$pagedata = array(
			 'invoice' => $invoice,
			 'orderedproducts' => $orderedproducts,
			 'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/invoiceview', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function drafts()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Invoices_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$config['base_url'] = base_url() . "be/invoices/drafts";
	    $config['total_rows'] = $this->Invoices_model->invoices_draftscount();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$invoices['results'] = $this->Invoices_model->get_invoicesdrafts($config['per_page'], $config['uri_segment']);
	    $invoices['links'] = $this->pagination->create_links();
		
		$pagedata = array(
			 'invoices' => $invoices,
			 'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/invoicesdrafts', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function trash()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Invoices_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$config['base_url'] = base_url() . "be/invoices/trash";
	    $config['total_rows'] = $this->Invoices_model->invoices_trashcount();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$invoices['results'] = $this->Invoices_model->get_invoicestrash($config['per_page'], $config['uri_segment']);
	    $invoices['links'] = $this->pagination->create_links();
		
		$pagedata = array(
			'invoices' => $invoices,
			'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/invoicestrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function setdraft()
	{
		$this->Invoices_model->draft_row();
		redirect('be/invoices/drafts');
	}
	public function settrash()
	{
		$this->Invoices_model->trash_row();
		redirect('be/invoices/trash');
	}
	public function setrestore()
	{
		$this->Invoices_model->restore_row();
		redirect('be/invoices');
	}
	public function setdelete()
	{
		$this->Invoices_model->delete_row();
		redirect('be/invoices/trash');
	}
	public function savenotes()
	{
	$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('invoiceid', 'invoiceid', 'required');
		$this->form_validation->set_rules('adminnotes', 'adminnotes','required');
		
		if($this->form_validation->run() == FALSE)
		{
				redirect('be/invoices/view/' . $this->input->post('invoiceid') );
		}
		else
		{
			$data = array(
				'id' => $this->input->post('invoiceid'),
				'adminnotes' => $this->input->post('adminnotes')
			);
			$this->Invoices_model->save_adminnotes($data);
			redirect('be/invoices/view/' . $this->input->post('invoiceid') );
		}
	}
	public function updatenotpaid()
	{
		$this->Invoices_model->updatenotpaid();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	
	public function updatepaid()
	{
		$this->Invoices_model->updatepaid();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	
	public function updateprocessing()
	{
		$this->Invoices_model->updateprocessing();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	public function updateonroute()
	{
		$this->Invoices_model->updateonroute();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	public function updatedelivered()
	{
		$this->Invoices_model->updatedelivered();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	public function updatecancelled()
	{
		$this->Invoices_model->updatecancelled();
		redirect('be/invoices/view/' . $this->uri->segment(4));
	}
	public function customeralert()
	{	
		
		$data = $this->Invoices_model->contactcustomer();

        $parent_data = array('data' => $data);

		$this->load->view('be' . '/header');
		$this->load->view('be' . '/contactcustomer', $parent_data);
		$this->load->view('be' . '/footer');
	}
}