<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Discounts extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Discounts_model');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	
	
	public function index()
	{
		$discounts = $this->Discounts_model->get_discountcodes();
		$pagedata = array(
			 'discounts' => $discounts
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/discounts', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function trash()
	{
		$discounts = $this->Discounts_model->get_discountcodestrash();
		$pagedata = array(
			 'discounts' => $discounts
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/discountstrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function create()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Discounts_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$data = array();
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/discountscreate', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function createcode()
	{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('code', 'code','trim|required');
		
		$data['name'] = $this->input->post('name');
		$data['code'] = $this->input->post('code');
		$data['uses'] = $this->input->post('uses');
		$data['startdate'] = $this->input->post('startdate');
		$data['enddate'] = $this->input->post('enddate');
		$data['discount'] = $this->input->post('discount');
		$data['percent'] = $this->input->post('percent');
		
		if($this->form_validation->run() == FALSE)
		{

		$currency = '&pound;';
		$currencyinfo = $this->Discounts_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/discountscreate-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		$discountcodes = $this->Discounts_model->get_allcodes();
		$discountcodescheck = $this->Discounts_model->check_codes();
		$code = $this->input->post('code');
		$code2 = strtolower($code);
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â', '-');
		$change1 = '';
		$code3 = str_replace($chars, $change1, $code2);
		 $check2 = array('code' => $code3);
		 
		 if(in_array($check2, $discountcodescheck, TRUE)){
		   $n = 2;
		   foreach($discountcodes as $dc){
		   $finalcodea = explode('-', $dc['code']);
		   if(isset($finalcodea['0'])){
				$finalcode = $finalcodea['0'];
		   } else {
			   $finalcode = $dc['code'];
		   }
		     if($code3 != $finalcode){
		       $check2 = 2;
		       } else{
		       $check2 = $n++;
		     }
		    }
		   $newcode = $code3 . '-' . $check2;
		  } else {
		    $newcode = $code3;
		   }
		$data = array(
			'name' => $this->input->post('name'),
			'code' => $newcode,
			'uses' => $this->input->post('uses'),
			'start' => $this->input->post('startdate'),
			'end' => $this->input->post('enddate'),
			'discount' => $this->input->post('discount'),
			'percent' => $this->input->post('percent')
		);
		
		$this->Discounts_model->add_record($data);
		redirect('be/discounts');
	  }
	}
	public function edit()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Discounts_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$discounts = $this->Discounts_model->get_code();
		$pagedata = array(
			'discounts' => $discounts,
			'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/discountsedit', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function editcode()
	{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('code', 'code','trim|required');
		
		$data['id'] = $this->input->post('id');
		$data['name'] = $this->input->post('name');
		$data['code'] = $this->input->post('code');
		$data['uses'] = $this->input->post('uses');
		$data['startdate'] = $this->input->post('startdate');
		$data['enddate'] = $this->input->post('enddate');
		$data['discount'] = $this->input->post('discount');
		$data['percent'] = $this->input->post('percent');
		
		if($this->form_validation->run() == FALSE)
		{

		$currency = '&pound;';
		$currencyinfo = $this->Discounts_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/discountsedit-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		$editid  = $data['id'];
		$discountcodes = $this->Discounts_model->get_allcodes_edit($editid);
		$discountcodescheck = $this->Discounts_model->check_codes_edit($editid);
		$code = $this->input->post('code');
		$code2 = strtolower($code);
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â', '-');
		$change1 = '';
		$code3 = str_replace($chars, $change1, $code2);
		$search1 = ' ';
		 $replace1 = '-';
		 $check = str_replace($search1, $replace1, $code3);
		 $check2 = array('code' => $check);
		 
		 if(in_array($check2, $discountcodescheck, TRUE)){
		   $n = 2;
		   foreach($discountcodes as $dc){
		   $finalcodea = explode('-', $dc['code']);
		   if(isset($finalcodea['0'])){
				$finalcode = $finalcodea['0'];
		   } else {
			   $finalcode = $dc['code'];
		   }
		     if($code3 != $finalcode){
		       $check2 = 2;
		       } else{
		       $check2 = $n++;
		     }
		    }
		   $newcode = $check . '-' . $check2;
		  } else {
		    $newcode = $check;
		   }
		$data = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'code' => $newcode,
			'uses' => $this->input->post('uses'),
			'start' => $this->input->post('startdate'),
			'end' => $this->input->post('enddate'),
			'discount' => $this->input->post('discount'),
			'percent' => $this->input->post('percent')
		);
		
		$this->Discounts_model->update_record($data);
		redirect('be/discounts');
	  }
	}
	public function settrash()
	{
		$this->Discounts_model->trash_row();
		redirect('be/discounts/trash');
	}
	public function setrestore()
	{
		$this->Discounts_model->restore_row();
		redirect('be/discounts');
	}
	public function setdelete()
	{
		$this->Discounts_model->delete_row();
		redirect('be/discounts/trash');
	}
}