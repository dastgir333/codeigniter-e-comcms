<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Downloads extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Downloadfiles_model');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	
	
	public function index()
	{
		if($this->input->post('upload')){
		   $this->Downloadfiles_model->do_upload();
		}
		$downloads = $this->Downloadfiles_model->get_downloads();
		$pagedata = array(
			 'downloads' => $downloads
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/downloads', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function trash()
	{
		$downloads = $this->Downloadfiles_model->get_downloadstrash();
		$pagedata = array(
			 'downloads' => $downloads
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/downloadstrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function settrash()
	{
		$this->Downloadfiles_model->trash_row();
		redirect('be/downloads/trash');
	}
	public function setrestore()
	{
		$this->Downloadfiles_model->restore_row();
		redirect('be/downloads');
	}
	public function setdelete()
	{
		$this->Downloadfiles_model->delete_row();
		redirect('be/downloads/trash');
	}
}