<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Shipping extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Shipping_model');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}	
	
	public function index()
	{
		$shippingrules = $this->Shipping_model->get_shippingrules();
		$pagedata = array(
			 'shippingrules' => $shippingrules
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/shipping', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function trash()
	{
		$shippingrules = $this->Shipping_model->get_shippingrulestrash();
		$pagedata = array(
			 'shippingrules' => $shippingrules
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/shippingtrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function edit()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Shipping_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$shippingzone = $this->Shipping_model->get_shippingzone();
		$pagedata = array(
			'shippingzone' => $shippingzone,
			'currency' => $currency
		);
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/shippingedit', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function create()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Shipping_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$data = array();
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		 );
	 
	    $this->load->view('be' . '/header');
		$this->load->view('be' . '/shippingcreate', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function createzone()
	{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('zone', 'zone','trim|required');
		$this->form_validation->set_rules('country', 'country', 'trim|required');
		$this->form_validation->set_rules('postcodes', 'postcodes', 'trim|required');
		$this->form_validation->set_rules('cost', 'cost', 'trim|required');
		
		$data['name'] = $this->input->post('name');
		$data['zone'] = $this->input->post('zone');
		$data['country'] = $this->input->post('country');
		$data['postcodes'] = $this->input->post('postcodes');
		$data['cost'] = $this->input->post('cost');
		
		if($this->form_validation->run() == FALSE)
		{
		$currency = '&pound;';
		$currencyinfo = $this->Shipping_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/shippingcreate-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		
		$data = array(
			'name' => $this->input->post('name'),
			'zone' => $this->input->post('zone'),
			'country' => $this->input->post('country'),
			'postcodes' => $this->input->post('postcodes'),
			'cost' => $this->input->post('cost')
		);
		
		$this->Shipping_model->add_record($data);
		redirect('be/shipping');
	  }
	}
	public function editzone()
	{	
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('zone', 'zone','trim|required');
		$this->form_validation->set_rules('country', 'country', 'trim|required');
		$this->form_validation->set_rules('postcodes', 'postcodes', 'trim|required');
		$this->form_validation->set_rules('cost', 'cost', 'trim|required');
		
		$data['id'] = $this->input->post('id');
		$data['name'] = $this->input->post('name');
		$data['zone'] = $this->input->post('zone');
		$data['country'] = $this->input->post('country');
		$data['postcodes'] = $this->input->post('postcodes');
		$data['cost'] = $this->input->post('cost');
		
		if($this->form_validation->run() == FALSE)
		{
		$currency = '&pound;';
		$currencyinfo = $this->Shipping_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$pagedata = array(
			'data' => $data,
			'currency' => $currency
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/shippingedit-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		
		$data = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'zone' => $this->input->post('zone'),
			'country' => $this->input->post('country'),
			'postcodes' => $this->input->post('postcodes'),
			'cost' => $this->input->post('cost')
		);
		
		$this->Shipping_model->update_record($data);
		redirect('be/shipping');
	  }
	}
	public function settrash()
	{
		$this->Shipping_model->trash_row();
		redirect('be/shipping/trash');
	}
	public function setrestore()
	{
		$this->Shipping_model->restore_row();
		redirect('be/shipping');
	}
	public function setdelete()
	{
		$this->Shipping_model->delete_row();
		redirect('be/shipping/trash');
	}
}