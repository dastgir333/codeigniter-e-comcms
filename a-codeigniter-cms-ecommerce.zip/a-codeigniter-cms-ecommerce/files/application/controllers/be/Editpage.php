<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editpage extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
		$this->load->model('Editpage_model');
		$this->load->helper('text');
	}
	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('index.php');
		}		
	}
	
	public function edit()
	{
		
		$editpage = $this->Editpage_model->get_page();
		$images = $this->Editpage_model->get_images();
		$pagedata = array(
		'images' => $images,
		'editpage' => $editpage
		);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/editpage', $pagedata);
		$this->load->view('be' . '/footer');
		
	}
	public function update()
	{
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('content', 'content', 'required');
		$this->form_validation->set_rules('name', 'name','trim|required');
		$this->form_validation->set_rules('description', 'description','trim|required');
		$this->form_validation->set_rules('keywords', 'keywords', 'trim|required');
		
		$data['id'] = $this->input->post('id');
		$data['name'] = $this->input->post('name');
		$data['content'] = $this->input->post('content');
		$data['description'] = $this->input->post('description');
		$data['keywords'] = $this->input->post('keywords');
		$data['videolink'] = $this->input->post('videolink');
	    $data['sort'] = $this->input->post('sort');
		
		if($this->form_validation->run() == FALSE)
		{

		$images = $this->Editpage_model->get_images();
		$pagedata = array('images' => $images, 'data' => $data);
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/editpage-error', $pagedata);
		$this->load->view('be' . '/footer');
		}
		else
		{
		if($this->input->post('trash') == null){
			$trash = '0';
		} else {
			$trash = $this->input->post('trash');
		}
		$data2 = array(
			'id' => $this->input->post('id'),
			'name' => $this->input->post('name'),
			'content' => $this->input->post('content'),
			'title' => $this->input->post('name'),
			'description' => $this->input->post('description'),
			'keywords' => $this->input->post('keywords'),
			'trash' => $trash,
			'videolink' => $this->input->post('videolink'),
			'sort' => $this->input->post('sort')
		);
		
		$this->Editpage_model->update_record($data2);
		redirect('be/pages');
	  }
	}
	
}