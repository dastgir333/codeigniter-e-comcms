<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customers extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->is_logged_in();
	    $this->load->model('Customers_model');
		$this->load->helper('text');
		$this->load->library('pagination');
	}

	public function is_logged_in()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		if(!isset($is_logged_in) || $is_logged_in != true)
		{
			redirect('login');
		}		
	}
	
	public function index()
	{
		$config['base_url'] = base_url() . "be/customers/index";
	    $config['total_rows'] = $this->Customers_model->subscribers_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$subs['results'] = $this->Customers_model->get_subscribers($config['per_page'], $config['uri_segment']);
	    $subs['links'] = $this->pagination->create_links();	
 		 $pagedata = array(
		 'subs' => $subs
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/subscribers', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function view()
	{
		$subscriber = $this->Customers_model->get_subscriber();
		$subscriberinvoice = $this->Customers_model->get_subscriberinvoice();
 		 $pagedata = array(
		 'subscriber' => $subscriber,
		 'subscriberinvoice' => $subscriberinvoice
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/subscriberview', $pagedata);
		$this->load->view('be' . '/footer');
	}
	public function logs()
	{
		$link = $this->uri->segment(4);
		$config['base_url'] = base_url() . "be/customers/logs/" . $link;
	    $config['total_rows'] = $this->Customers_model->subscribers_logcount();
		$config['per_page'] = 20;
	    $config['uri_segment'] = 5;
		
		$this->pagination->initialize($config);
		$sublogs['results'] = $this->Customers_model->get_subscriberslogs($config['per_page'], $config['uri_segment']);
	    $sublogs['links'] = $this->pagination->create_links();	
 		 $pagedata = array(
		 'sublogs' => $sublogs
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/subscriberslogs', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function trash()
	{
		$config['base_url'] = base_url() . "be/customers/trash";
	    $config['total_rows'] = $this->Customers_model->subscriberstrash_count();
		$config['per_page'] = 9;
	    $config['uri_segment'] = 4;
		
		$this->pagination->initialize($config);
		$subs['results'] = $this->Customers_model->get_subscriberstrash($config['per_page'], $config['uri_segment']);
	    $subs['links'] = $this->pagination->create_links();	
 		 $pagedata = array(
		 'subs' => $subs
		 );
		
		$this->load->view('be' . '/header');
		$this->load->view('be' . '/subscriberstrash', $pagedata);
		$this->load->view('be' . '/footer');
	}
	
	public function settrash()
	{
		$this->Customers_model->trash_row();
		redirect('be/customers/trash');
	}
	public function setrestore()
	{
		$this->Customers_model->restore_row();
		redirect('be/customers');
	}
	public function setdelete()
	{
		$this->Customers_model->delete_row();
		redirect('be/customers/trash');
	}
}