<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Post extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Posts_model');
	    $this->load->model('Post_model');
		$this->load->library("pagination");
	    $this->load->model('Functions_model');
		$this->statuscheck();
	}
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	public function index()

	{
       $check1 = $this->Post_model->get_allposts();
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		
		$uriseg = str_replace($chars, $change1, $this->uri->segment(2));
		$check2 = $uriseg;
		
		$check3 = 'got-nothing';
		
		foreach($check1 as $part){
			if($part->slug == $check2){
				$check3 = 'got-posts';
			} 
		}
		
		if($check3 == 'got-nothing'){
			redirect('');
		}
		if($this->session->userdata('is_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => '0',
				'action' => 'viewed post: ' . $this->uri->segment(2),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} elseif($this->session->userdata('customer_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => $this->session->userdata('customerid'),
				'action' => 'viewed post: ' . $this->uri->segment(2),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} else {
			$logdata = array(
				'email' => 'not logged in',
				'customerid' => '0',
				'action' => 'viewed post: ' . $this->uri->segment(2),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		}
		$this->Functions_model->set_log($logdata);
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Post_model->get_postheader();
		$headerdata = array('headerlogo' => $headerlogo, 'pageheader' => $pageheader, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
	    $capturedata = $this->Post_model->get_capture();
		$data = $this->Post_model->get_posts();
		$comments = $this->Post_model->get_postcomments();
		$parent_data = array('data' => $data, 'capturedata' => $capturedata, 'comments' => $comments);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/post', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
	  
	 }
	 
	 public function category()
	{
		
		$check1 = $this->Post_model->get_postcats();
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		
		$uriseg = str_replace($chars, $change1, $this->uri->segment(3));
		$check2 = $uriseg;
		
		$check3 = 'got-nothing';
		
		foreach($check1 as $part){
			if($part->slug == $check2){
				$check3 = 'got-postcats';
			} 
		}
		
		if($check3 == 'got-nothing'){
			redirect('');
		}
		
	       $activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
	        $config['base_url'] = base_url() . "post/category/" . $this->uri->segment(3);
	        $config['total_rows'] = $this->Posts_model->postcat_count();
            $config['per_page'] = 5;
	        $config['uri_segment'] = 4;
			
	 
	        $this->pagination->initialize($config);
	 $data4 = array();
	        $data4['results'] = $this->Posts_model->get_postscat($config['per_page'], $config['uri_segment']);
	        $data4['links'] = $this->pagination->create_links();
		
		$menustatus = $this->Functions_model->get_menustatus();	
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();	
			
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Posts_model->get_categoryheader();
		$headerdata = array('headerlogo' => $headerlogo, 'pageheader' => $pageheader, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
		
		$catname = str_replace('-', ' ', $this->uri->segment(3));
		$subcat = $this->Posts_model->get_subcat();
		$parent_data = array('data4' => $data4, 'catname' => $catname, 'subcat' => $subcat);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/postscategories', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
		
	  
	}
	
	public function comments()
	{
		 $this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('comments_name', 'comments_name', 'required');
		$this->form_validation->set_rules('comments_message', 'comments_message', 'required');
		$this->form_validation->set_rules('capture1', 'capture1', 'required');
		$this->form_validation->set_rules('capture2', 'capture2', 'required');
		
		$checkone = $this->security->xss_clean($this->input->post('capture1'));
		$checktwo = $this->security->xss_clean($this->input->post('capture2'));
		$real = FALSE;
		if($checktwo == 'capture-one.jpg' && $checkone == 'green') {
		$real = TRUE;
		} elseif($checktwo == 'capture-two.jpg' && $checkone == 'banana') {
		$real = TRUE;
		} elseif($checktwo == 'capture-three.jpg' && $checkone == 'business') {
		$real = TRUE;
		} elseif($checktwo == 'capture-four.jpg' && $checkone == 'person') {
		$real = TRUE;
		} elseif($checktwo == 'capture-five.jpg' && $checkone == 'purple') {
		$real = TRUE;
		} elseif($checktwo == 'capture-six.jpg' && $checkone == 'minions') {
		$real = TRUE;
		}
		 
		if($this->form_validation->run() == FALSE or $real == FALSE)
		{
			
		} else {
			$data = array(
			'user' => $this->security->xss_clean($this->input->post('comments_name')),
			'comment' => $this->security->xss_clean($this->input->post('comments_message')),
			'post' => $this->security->xss_clean($this->input->post('comments_post')),
			'slug' => $this->security->xss_clean($this->input->post('comments_slug'))
			);
			$this->Post_model->save_comment($data);
			redirect('post/' . $this->input->post('comments_slug'));
		}
	}
}