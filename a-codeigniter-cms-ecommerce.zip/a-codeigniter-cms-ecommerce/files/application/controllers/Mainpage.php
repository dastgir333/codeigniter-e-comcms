<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mainpage extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Page_model');
	    $this->load->model('Functions_model');
		$this->statuscheck();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}

	public function index()
	{
		if($this->session->userdata('is_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => '0',
				'action' => 'viewed mainpage',
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} elseif($this->session->userdata('customer_logged_in')){
			$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => $this->session->userdata('customerid'),
				'action' => 'viewed mainpage',
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		} else {
			$logdata = array(
				'email' => 'not logged in',
				'customerid' => '0',
				'action' => 'viewed mainpage',
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
				);
		}
		$this->Functions_model->set_log($logdata);
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		$slidercheck = $this->Page_model->get_slideroption();
		foreach($slidercheck as $sc){
			$check = $sc->slideroption;
		}
		if($check == 'custom'){
			$slider = $this->Page_model->get_mpm_slidercustom();
		} elseif($check == 'posts') {
			$slider = $this->Page_model->get_mpm_sliderposts();
		} else {
			$slider = $this->Page_model->get_mpm_sliderproducts();
		}
		$box1 = $this->Page_model->get_mpm_post();
		$box2 = $this->Page_model->get_mpm_product();
		$box3 = $this->Page_model->get_mpm_product2();
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Page_model->get_pageheader();
		$pagetitle = $this->Page_model->get_sitetitle();
		$headerdata = array(
			'headerlogo' => $headerlogo,
			'pageheader' => $pageheader,
			'pagetitle' => $pagetitle,
			'menu' => $menu,
			'postmenu' => $postmenu,
			'productmenu' => $productmenu,
			'menustatus' => $menustatus,
			'theme' => $theme
		);
		
		$pagedata = array();
		$pagedata = $this->Page_model->get_pagedata();
		$parentdata = array(
			'pagedata' => $pagedata,
			'box1' => $box1,
			'box2' => $box2,
			'box3' => $box3,
			'check' => $check,
			'slider' => $slider,
			'currency' => $currency
		);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/mainpage', $parentdata);
		$this->load->view($theme . '/footer', $footerdata);
	}
}