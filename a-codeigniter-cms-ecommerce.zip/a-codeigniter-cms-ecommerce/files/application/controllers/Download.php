<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Download extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Download_model');
	    $this->load->model('Functions_model');
		$this->statuscheck();
		$this->customer_logged_in();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	
	public function customer_logged_in()
	{
		$customer_logged_in = $this->session->userdata('customer_logged_in');
		if(!isset($customer_logged_in) || $customer_logged_in != true)
		{
			redirect('customer-login');
		}		
	}

	public function item()
	{
		$uriarray = explode('_',$this->uri->segment(3));
		$invoicenumber = $uriarray['0'];
		$filename = $uriarray['1'];
		$iteminvoice = $this->Download_model->get_iteminvoice($invoicenumber);
		if($iteminvoice){
			foreach($iteminvoice as $invoicepart){
				$invoicedate = $invoicepart->originaldate;
				$invoicepaid = $invoicepart->paid;
			}
			// check to see if payment is less than one month ago
			date_default_timezone_set('Europe/London');
			$datechecka = strtotime($invoicedate);
			$datecheck = strtotime("+1 month", $datechecka);

				 $date_now = strtotime(date("Y-m-d"));
				 $onemonth = 'notchecked';
			if($invoicepaid == '1'){
				if ($date_now > $datecheck) {
						$onemonth = 'expired';
					} else {
						$onemonth = 'valid';
					}
			} else {
				$onemonth = 'expired';
			}
		} else {
			$onemonth = 'expired';
		}
		if($onemonth == 'expired'){
			redirect('account');
		}
		
		// check if item has been ordered
		$itemlist = $this->Download_model->get_allorderedproducts($invoicenumber);
		$downloadcheck = 'no';
		foreach($itemlist as $item){
			if($item->download == $filename){
				$downloadcheck = 'yes';
			}
		}
		if($downloadcheck == 'no'){
			redirect('account');
		}
		
		//log stats data
		$logdata = array(
				'email' => $this->session->userdata('email'),
				'customerid' => $this->session->userdata('customerid'),
				'action' => 'downloaded item: ' . $this->uri->segment(3),
				'user_agent' => $this->input->user_agent(),
				'ip_address' => $this->input->ip_address()
			);
		$this->Functions_model->set_log($logdata);
		
		//offer file for download
		$downloadfile = $filename;
		 $dir = $_SERVER['SCRIPT_FILENAME'];
			$dir2 = str_replace('index.php', '', $dir);
			$dir3 = $dir2 . 'downloads/';
		$file = $dir3 . $downloadfile;

		if (file_exists($file)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
			exit;
		} else {
			redirect('account');
		}
	}
	
}