<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cart extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Cart_model');
	    $this->load->model('Product_model');
	    $this->load->model('Functions_model');
		$this->load->library("pagination");
		$this->load->helper('text');
		$this->statuscheck();
		
	}
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function get_shippingcost()
	{
		$shippingvalid = 'no';
		$allitemsshipping = 0.00;
		$customercheck = $this->session->userdata('customer_logged_in');
		if($customercheck == TRUE){
			$customerid = $this->session->userdata('customerid');
			$address = $this->Cart_model->get_customeraddress($customerid);
			foreach($address as $row){
				$country = $row->country;
				$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â',' ','-');
				$postcode = str_replace($chars, '', $row->postcode);
				$postupper = strtoupper($postcode);
				$postlength = strlen($postcode);
				if($postlength == 6){
					$finalcode = substr($postupper, 0, 3);
				} elseif($postlength == 7){
					$finalcode = substr($postupper, 0, 4);
				} elseif($postlength == 5){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 4){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 8){
					$finalcode = substr($postupper, 0, 4);
				} else {
					$finalcode = 0;
				}
			}
			foreach($this->cart->contents() as $items){
				$courier = $items['shippingname'];
				$shippingrules = $this->Cart_model->get_shippingrules($courier, $country, $finalcode);
				if($items['qty'] == '1'){
					$shippingweight = $items['weight'];
				} else {
					$shippingweight = $items['weight'] * $items['qty'];
				}
				if($shippingrules == null){
					$shippingrules = $this->Cart_model->get_shippingruleszoneone($courier, $country);
				}
				if($items['download'] != 'none' && $items['download'] != ''){
					$itemshippingcost = 0 + $allitemsshipping;
					$allitemsshipping = $itemshippingcost;
					$shippingvalid = 'yes';
				} else {
					foreach($shippingrules as $rule){
						$codes = explode(',', $rule->postcodes);
						$shippingcosts = explode(';', $rule->cost);
						foreach($shippingcosts as $parts){
							if($parts != null){
								$individualcosts = explode(',', $parts);
								$from = $individualcosts['0'];
								$to = $individualcosts['1'];
								$price = $individualcosts['2'];
								
								if($shippingweight >= $from && $shippingweight <= $to){
									$itemshippingcost = $price + $allitemsshipping;
									$allitemsshipping = $itemshippingcost;
									$shippingvalid = 'yes';
								}
							}
						}
					}
				}
			}
		} else {
			// no postcode given, default zone one shipping estimate
			foreach($this->cart->contents() as $items){
				$courier = $items['shippingname'];
				$shippingrules = $this->Cart_model->get_shippingrulesbasic($courier);
				if($items['qty'] != '1'){
					$shippingweight = $items['weight'] * $items['qty'];
				} else {
					$shippingweight = $items['weight'];
				}
				if($items['download'] != 'none' && $items['download'] != ''){
					$itemshippingcost = 0 + $allitemsshipping;
					$allitemsshipping = $itemshippingcost;
					$shippingvalid = 'yes';
				} else {
					foreach($shippingrules as $rule){
						$codes = explode(',', $rule->postcodes);
						$shippingcosts = explode(';', $rule->cost);
						foreach($shippingcosts as $parts){
							if($parts != null){
								$individualcosts = explode(',', $parts);
								$from = $individualcosts['0'];
								$to = $individualcosts['1'];
								$price = $individualcosts['2'];
								
								if($shippingweight >= $from && $shippingweight <= $to){
									$itemshippingcost = $price + $allitemsshipping;
									$allitemsshipping = $itemshippingcost;
									$shippingvalid = 'yes';
								}
							}
						}
					}
				}
			}
		}
		if(isset($country)){
			foreach($this->cart->contents() as $itemcheck){
				$couriercheck = $itemcheck['shippingname'];
				$countrycheck = array('country' => $country);
				$itemcountry = $this->Cart_model->get_itemcountry($couriercheck);
				if(!in_array($countrycheck, $itemcountry, TRUE)){
					$shippingvalid = 'no';
				}
			}
		}
		$shipping = array('allitemsshipping' => $allitemsshipping, 'shippingvalid' => $shippingvalid);
		return $shipping;
	}
	public function get_options()
	{
		$optiontotal = 0;
		$itemextra = 0;
		foreach($this->cart->contents() as $optioncheck){
			if($optioncheck['options'] != null){
				$optionscheckarray = $optioncheck['options'];
				$optionarray = explode(',', $optionscheckarray['zero']);
				if(isset($optionarray['1'])){
					if($optioncheck['qty'] != '1'){
						$itemextra = $optionarray['1'] * $optioncheck['qty'];
					} else {
						$itemextra = $optionarray['1'];
					}
				}
				$newtotal = $optiontotal + $itemextra;
				$optiontotal = $newtotal;
			}
		}
		$options = array('optiontotal' => $optiontotal);
		return $options;
	}
	public function index()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Product_model->get_productheader();
		$headerdata = array(
		'headerlogo' => $headerlogo,
		'pageheader' => $pageheader, 
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$options = $this->get_options();
		$shipping = $this->get_shippingcost();
		$currency = $this->currency();
	    $shippingtotal = $shipping['allitemsshipping'];
		$parent_data = array('shippingtotal' => $shippingtotal, 'shippingvalid' => $shipping['shippingvalid'], 'optiontotal' => $options['optiontotal'], 'currency' => $currency);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/cart', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
	}
	
	public function estimate_result()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('postcode', 'postcode', 'trim|required');
		$this->form_validation->set_rules('country', 'country','trim|required');
		
		if($this->form_validation->run() == FALSE)
		{
			redirect('cart');
		} else {				
				$allitemsshipping = 0;
				$shippingvalid = 'no';
				$country = $this->input->post('country');
				$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', '?', 'Â£','Â',' ','-');
				$postcode = str_replace($chars, '', $this->input->post('postcode'));
				$postupper = strtoupper($postcode);
				$postlength = strlen($postcode);
				if($postlength == 6){
					$finalcode = substr($postupper, 0, 3);
				} elseif($postlength == 7){
					$finalcode = substr($postupper, 0, 4);
				} elseif($postlength == 5){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 4){
					$finalcode = substr($postupper, 0, 2);
				} elseif($postlength == 8){
					$finalcode = substr($postupper, 0, 4);
				} else {
					$finalcode = 0;
				}
				
			foreach($this->cart->contents() as $items){
				$courier = $items['shippingname'];
				$shippingrules = $this->Cart_model->get_shippingrules($courier, $country, $finalcode);
				if($items['qty'] == '1'){
					$shippingweight = $items['weight'];
				} else {
					$shippingweight = $items['weight'] * $items['qty'];
				}
				if($shippingrules == null){
					$shippingrules = $this->Cart_model->get_shippingruleszoneone($courier, $country);
				}
				if($items['download'] != 'none' && $items['download'] != ''){
					$itemshippingcost = 0 + $allitemsshipping;
					$allitemsshipping = $itemshippingcost;
					$shippingvalid = 'yes';
				} else {
					foreach($shippingrules as $rule){
						$codes = explode(',', $rule->postcodes);
						$shippingcosts = explode(';', $rule->cost);
						foreach($shippingcosts as $parts){
							if($parts != null){
								$individualcosts = explode(',', $parts);
								$from = $individualcosts['0'];
								$to = $individualcosts['1'];
								$price = $individualcosts['2'];
								
								if($shippingweight >= $from && $shippingweight <= $to){
									$itemshippingcost = $price + $allitemsshipping;
									$allitemsshipping = $itemshippingcost;
									$shippingvalid = 'yes';
								}
							}
						}
					}
				}
			}
			foreach($this->cart->contents() as $itemcheck){
				$couriercheck = $itemcheck['shippingname'];
				$countrycheck = array('country' => $country);
				$itemcountry = $this->Cart_model->get_itemcountry($couriercheck);
				if(!in_array($countrycheck, $itemcountry, TRUE)){
					$shippingvalid = 'no';
				}
			}
			$menustatus = $this->Functions_model->get_menustatus();
			$menu = $this->Functions_model->get_menu();
			$postmenu = $this->Functions_model->get_postmenu();
			$productmenu = $this->Functions_model->get_productmenu();
			$getlogo = $this->Functions_model->get_logo();
			foreach($getlogo as $logo){
				$headerlogo = $logo->image;
			}
			$pageheader = $this->Product_model->get_productheader();
			$headerdata = array(
			'headerlogo' => $headerlogo,
			'pageheader' => $pageheader, 
			'menu' => $menu, 
			'postmenu' => $postmenu, 
			'productmenu' => $productmenu, 
			'menustatus' => $menustatus
			);
			
			$shippingtotal = $allitemsshipping;
			$options = $this->get_options();
			$currency = $this->currency();
			$parent_data = array('shippingtotal' => $shippingtotal, 'shippingvalid' => $shippingvalid, 'optiontotal' => $options['optiontotal'], 'currency' => $currency);
			
			$postmenufooter = $this->Functions_model->get_postmenufooter();		
			$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
			$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
			
			$this->load->view($theme . '/header', $headerdata);
			$this->load->view($theme . '/cartestimateresult', $parent_data);
			$this->load->view($theme . '/footer', $footerdata);
		}
	}
	public function estimate()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		$pageheader = $this->Product_model->get_productheader();
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array(
		'headerlogo' => $headerlogo,
		'pageheader' => $pageheader, 
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
	    $data = array();
		$parent_data = array('data' => $data);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/cartestimate', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
	}
}