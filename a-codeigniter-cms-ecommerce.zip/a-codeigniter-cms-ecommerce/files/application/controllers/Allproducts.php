<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Allproducts extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Allproducts_model');
	    $this->load->model('Functions_model');
		$this->load->library("pagination");
		$this->statuscheck();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function index()
	{

		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		$currency = $this->currency();
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$config['base_url'] = base_url() . "allproducts/index";
	        $config['total_rows'] = $this->Allproducts_model->product_count();
            $config['per_page'] = 5;
	        $config['uri_segment'] = 3;
			
	 
	        $this->pagination->initialize($config);
	        $data4 = array();
	        $data4['results'] = $this->Allproducts_model->get_products($config['per_page'], $config['uri_segment']);
	        $data4['links'] = $this->pagination->create_links();
			
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$parent_data = array('results' => $data4['results'], 'links' => $data4['links'], 'currency' => $currency);
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/allproducts', $parent_data);
		$this->load->view($theme . '/footer', $footerdata);
		
	  
	}
}