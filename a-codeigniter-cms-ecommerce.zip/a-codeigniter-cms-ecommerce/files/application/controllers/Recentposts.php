<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Recentposts extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Recentposts_model');
		$this->load->library("pagination");
	    $this->load->model('Functions_model');
		$this->statuscheck();
	}
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}

	public function index()
	{
	
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
	 
	 $config['base_url'] = base_url() . "recentposts/index";
	        $config['total_rows'] = $this->Recentposts_model->post_count();
            $config['per_page'] = 5;
	        $config['uri_segment'] = 3;
			
	        $this->pagination->initialize($config);
	 $data4 = array();
	        $data4['results'] = $this->Recentposts_model->get_posts($config['per_page'], $config['uri_segment']);
	        $data4['links'] = $this->pagination->create_links();
		
		$menustatus = $this->Functions_model->get_menustatus();	
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();	
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$headerdata = array('headerlogo' => $headerlogo, 'menu' => $menu, 'postmenu' => $postmenu, 'productmenu' => $productmenu, 'menustatus' => $menustatus);
			
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
			
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/recentposts', $data4);
		$this->load->view($theme . '/footer', $footerdata);
		
	}
}