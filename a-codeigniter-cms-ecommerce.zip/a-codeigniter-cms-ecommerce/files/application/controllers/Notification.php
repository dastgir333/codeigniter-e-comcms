<?php
// codeigniter/controllers/example.php

/* This is an example controller showing how to use the PayPal_IPN library. This is a
 * simple example: it does not send any notification emails or similar, it simply
 * logs the order to the database.
 * 
 * This file is copyright (c) 2011 Alexander Dean, alex@keplarllp.com
 * 
 * This file is part of codeigniter-paypal-ipn
 * 
 * codeigniter-paypal-ipn is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Affero General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 * 
 * codeigniter-paypal-ipn is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE. See the GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * codeigniter-paypal-ipn. If not, see <http://www.gnu.org/licenses/>.
 */

class Notification extends CI_Controller {

    // To handle the IPN post made by PayPal (uses the Paypal_Lib library).
    public function ipn()
    {
        $this->load->library('paypal_ipn'); // Load the library

        // Try to get the IPN data.
        if ($this->paypal_ipn->validateIPN())
        {
            // Succeeded, now let's extract the order
            $this->paypal_ipn->extractOrder();

            // And we save the order now (persist and extract are separate because you might only want to persist the order in certain circumstances).
            $this->paypal_ipn->saveOrder();

            // Now let's check what the payment status is and act accordingly
            if ($this->paypal_ipn->orderStatus == PayPal_IPN::PAID)
            {
				$this->load->model('Checkout_model');
                $this->load->library('email');
				$data = $this->paypal_ipn->order;
                $data['items'] = $this->paypal_ipn->orderItems;
				
				$invoice = $data['invoice'];
				
				$this->Checkout_model->updatepaid($invoice);
				
				$sitesettings = $this->Checkout_model->get_siterecords();
				$invoicedetails	= $this->Checkout_model->get_invoice($invoice);
				
				foreach($sitesettings as $sc){
					$adminemail = $sc->email;
					$sitetitle = $sc->title;
				}
				foreach($invoicedetails as $ind){
					$invoicecustomer = $ind->customer;
					$invoicedeliveryaddress = $ind->deliveryaddress;
					$invoiceemail = $ind->email;
					$orderdate = $ind->originaldate;
				}
				
				$messagetoadmin = '
				<!DOCTYPE html>
					 <head>
						  <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
						  <title>order</title>
						  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
					</head>
					<body>
						<p>You have recieved a new order.</p>
						<p>The order details are as follows:</p>
						<ul>' .
						'<li><b>invoice no:  ' . $invoice . '</b></li>' .
						'<li>order placed:  ' . $orderdate . '</li>' .
						'<li>name:  ' . $invoicecustomer . '</li>' .  
						'</ul><br /><p>delivery address:<br />  ' . $invoicedeliveryaddress . 
						'<br />please login to admin to view full details of this purchase.<br />
						<a href="' . base_url('login') .'">click here to login</a>' .
						'</p>
					</body>
				</html>
				';
				$messagetocustomer = '
				<!DOCTYPE html>
					 <head>
						  <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
						  <title>order</title>
						  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
					</head>
					<body>
						<p>Thank you for your purchase.</p>
						<p>Your order details are as follows:</p>
						<ul>' .
						'<li><b>invoice no:  ' . $invoice . '</b></li>' .
						'<li>order placed:  ' . $orderdate . '</li>' .
						'<li>' . $invoicecustomer . '</li>' .  
						'</ul>
						<br />
						<p>delivery address:<br />  ' . $invoicedeliveryaddress . 
						'<br />please login to our website to view full details of this purchase.<br />
						<a href="' . base_url('customer-login') .'">click here to login</a>' .
						'</p>
					</body>
				</html>
				';
				
				$config['mailtype'] = 'html';
				$this->email->initialize($config);
				
				$this->email->to($adminemail);
				$this->email->from($adminemail);
				$this->email->subject('new order ' . $invoice . ' ' . $sitetitle);
				$this->email->message($messagetoadmin);
				$this->email->send();
				
				$this->email->to($invoiceemail);
				$this->email->from($adminemail);
				$this->email->subject('order confirmation from ' . $sitetitle);
				$this->email->message($messagetocustomer);
				$this->email->send();   
				
				

            }
        }
        else // Just redirect to the root URL
        {
            //$this->load->helper('url');
            redirect('/', 'refresh');
        }
    }
}
