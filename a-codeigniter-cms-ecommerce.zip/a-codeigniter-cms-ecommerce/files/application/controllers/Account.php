<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Account extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Account_model');
	    $this->load->model('Functions_model');
		$this->load->library("pagination");
		$this->statuscheck();
		$this->customer_logged_in();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}
	
	public function customer_logged_in()
	{
		$customer_logged_in = $this->session->userdata('customer_logged_in');
		if(!isset($customer_logged_in) || $customer_logged_in != true)
		{
			redirect('customer-login');
		}		
	}
	
	public function currency()
	{
		$currency = '&pound;';
		$currencyinfo = $this->Functions_model->get_currency();
		foreach($currencyinfo as $ci){
			$currency = $ci->currencysign;
		}
		return $currency;
	}
	public function index()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$currency = $this->currency();
		$config['base_url'] = base_url() . "account/index";
	    $config['total_rows'] = $this->Account_model->invoices_count();
        $config['per_page'] = 5;
	    $config['uri_segment'] = 3;
			
	    $this->pagination->initialize($config);
	    $invoices['results'] = $this->Account_model->get_invoices($config['per_page'], $config['uri_segment']);
	    $invoices['links'] = $this->pagination->create_links();
		
		$pagedata = array(
		'invoices' => $invoices,
		'currency' => $currency
		);
		
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/account', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
	}
	
	
	public function invoice()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$invoice = $this->Account_model->get_singleinvoice();
		foreach($invoice as $part){
			$invoicenumber = $part->invoice;
		}
		if(!isset($invoicenumber)){
			redirect('account');
		}
		$currency = $this->currency();
		$orderedproducts = $this->Account_model->get_orderedproducts($invoicenumber);
		$pagedata = array(
		'invoice' => $invoice,
		'orderedproducts' => $orderedproducts,
		'currency' => $currency
		);
		
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/invoice', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
	}
	
	public function downloads()
	{
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		$currency = $this->currency();
		$config['base_url'] = base_url() . "account/downloads";
	    $config['total_rows'] = $this->Account_model->downloads_count();
        $config['per_page'] = 5;
	    $config['uri_segment'] = 3;
			
	    $this->pagination->initialize($config);
	    $downloads['results'] = $this->Account_model->get_downloads($config['per_page'], $config['uri_segment']);
	    $downloads['links'] = $this->pagination->create_links();
		
		$pagedata = array(
		'downloads' => $downloads,
		'currency' => $currency
		);
		
	    $postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/downloads', $pagedata);
		$this->load->view($theme . '/footer', $footerdata);
	}
}