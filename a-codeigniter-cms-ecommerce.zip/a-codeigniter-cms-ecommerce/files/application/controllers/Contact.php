<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
	    $this->load->model('Contact_model');
	    $this->load->model('Functions_model');
		$this->load->library('email');
		$this->statuscheck();
	}
	
	public function statuscheck()
	{
		$is_logged_in = $this->session->userdata('is_logged_in');
		$statuscheck = $this->Functions_model->get_sitestatus();
		foreach($statuscheck as $sc){
			if($sc->status == '0' && $is_logged_in != TRUE){
				redirect('offline');
			}
		}
	}

	public function index()
    {

		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Contact_model->get_header();
		$headerdata = array(
		'headerlogo' => $headerlogo,
		'pageheader' => $pageheader, 
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
		$capturedata = $this->Contact_model->get_capture();
		$data = array();
		
		if($query = $this->Contact_model->get_records())
		{
			$data['records'] = $query;
		}
		
		$page_data = array('data' => $data, 'capturedata' => $capturedata);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/pagecontact', $page_data);
		$this->load->view($theme . '/footer', $footerdata);
		
    }
	
	
	public function send()
	{
	
		$activetheme = $this->Functions_model->get_template();
		foreach($activetheme as $themebit){
			$theme = $themebit->name;
		}
		
	  $this->load->library('form_validation');
		
		// field name, error message, validation rules
		$this->form_validation->set_rules('email', 'email', 'required|valid_email');
		$this->form_validation->set_rules('message', 'message', 'required');
		$this->form_validation->set_rules('capture1', 'capture1', 'required');
		$this->form_validation->set_rules('capture2', 'capture2', 'required');
		
		$checkone = $this->security->xss_clean($this->input->post('capture1'));
		$checktwo = $this->security->xss_clean($this->input->post('capture2'));
		$real = FALSE;
		if($checktwo == 'capture-one.jpg' && $checkone == 'green') {
		$real = TRUE;
		} elseif($checktwo == 'capture-two.jpg' && $checkone == 'banana') {
		$real = TRUE;
		} elseif($checktwo == 'capture-three.jpg' && $checkone == 'business') {
		$real = TRUE;
		} elseif($checktwo == 'capture-four.jpg' && $checkone == 'person') {
		$real = TRUE;
		} elseif($checktwo == 'capture-five.jpg' && $checkone == 'purple') {
		$real = TRUE;
		} elseif($checktwo == 'capture-six.jpg' && $checkone == 'minions') {
		$real = TRUE;
		}
		 
		if($this->form_validation->run() == FALSE or $real == FALSE)
		{
		  if($this->input->post('email') == '') {
		  $formemail = '';
		  } else {
		  $formemail = $this->security->xss_clean($this->input->post('email'));
		  }
		  if($this->input->post('message') == '') {
		  $formmessage = '';
		  } else {
		  $formmessage = $this->security->xss_clean($this->input->post('message'));
		  }
		$capturedata = $this->Contact_model->get_capture();
				$data = array();
		
		if($query = $this->Contact_model->get_records())
		{
			$data['records'] = $query;
		}
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
		$pageheader = $this->Contact_model->get_header();
		$headerdata = array(
		'headerlogo' => $headerlogo,
		'pageheader' => $pageheader, 
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$page_data = array('data' => $data, 'capturedata' => $capturedata, 'formemail' => $formemail, 'formmessage' => $formmessage);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/pagecontact', $page_data);
		echo '<div id="errorMessage">Error<br />please enter your email address and message,<br /> The capture field is also required.</div>';
		
		$this->load->view($theme . '/footer', $footerdata);

		}
	else
		{
		$query5 = $this->Contact_model->get_settings();
		$messagetext = $this->security->xss_clean($this->input->post('message'));
		$chars = array('\'', ',', '$', '_', '.', '/', '"', '*', '(', ')', '!', '<', '>', '^', '%', '=', '+', '@', ':', ';', '#', '[', ']', '{', '}', '~', '£', '&', 'Â£','Â',);
		$change1 = '';
		$messagetext2 = str_replace($chars, $change1, $messagetext);
		foreach ($query5 as $row)
		{
			$siteemail = $row->email;
			$sitetitle = $row->title;
			$sitetimezone = $row->timezone;
		}
		
	    date_default_timezone_set($sitetimezone);
		$odate = date("F j, Y, g:i a");
		$data4 = array(
		    'email' => $this->security->xss_clean($this->input->post('email')),
			'message' => $messagetext2,
			'originaldate' => $odate
		);
		$emailcontent = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="text/html" charset="UTF-8" />
  <title>order</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head><body>' . $messagetext2 .'</body></html>';
		$this->Contact_model->send($data4);
		$config['mailtype'] = 'html';
        $this->email->initialize($config);
		
	$this->email->to($siteemail);
    $this->email->from($data4['email']);
    $this->email->subject('sent from ' . $sitetitle);
    $this->email->message($emailcontent);
    $this->email->send();
	$data = array();
		if($query = $this->Contact_model->get_records())
		{
			$data['records'] = $query;
		}
		
		$menustatus = $this->Functions_model->get_menustatus();
		$menu = $this->Functions_model->get_menu();
		$postmenu = $this->Functions_model->get_postmenu();
		$productmenu = $this->Functions_model->get_productmenu();
		
		$getlogo = $this->Functions_model->get_logo();
		foreach($getlogo as $logo){
			$headerlogo = $logo->image;
		}
	    $headerdata = array(
		'headerlogo' => $headerlogo,
		'menu' => $menu, 
		'postmenu' => $postmenu, 
		'productmenu' => $productmenu, 
		'menustatus' => $menustatus
		);
		
		$postmenufooter = $this->Functions_model->get_postmenufooter();		
		$postmenufooterlinks = $this->Functions_model->get_postmenufooterlinks();
		$footerdata = array('postmenufooter' => $postmenufooter, 'postmenufooterlinks' => $postmenufooterlinks);
		
		$this->load->view($theme . '/header', $headerdata);
		$this->load->view($theme . '/pagecontactsent', $data);
		$this->load->view($theme . '/footer', $footerdata);
	  
	  }
	}
}

