<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'mainpage';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


//back end
$route['be/dash'] = "be/dash";
$route['be/pages'] = "be/pages";
$route['be/pages/drafts'] = "be/pages/drafts";
$route['be/pages/trash'] = "be/pages/trash";
$route['be/pages/setdraft/:any'] = "be/pages/setdraft/$1";
$route['be/pages/settrash/:any'] = "be/pages/settrash/$1";
$route['be/pages/setrestore/:any'] = "be/pages/setrestore/$1";
$route['be/pages/setdelete/:any'] = "be/pages/setdelete/$1";
$route['be/posts'] = "be/posts";
$route['be/posts/drafts'] = "be/posts/drafts";
$route['be/posts/trash'] = "be/posts/trash";
$route['be/posts/setdraft/:any'] = "be/posts/setdraft/$1";
$route['be/posts/settrash/:any'] = "be/posts/settrash/$1";
$route['be/posts/setrestore/:any'] = "be/posts/setrestore/$1";
$route['be/posts/setdelete/:any'] = "be/posts/setdelete/$1";
$route['be/postcategories'] = "be/postcategories";
$route['be/postcategories/drafts'] = "be/postcategories/drafts";
$route['be/postcategories/trash'] = "be/postcategories/trash";
$route['be/postcategories/setdraft/:any'] = "be/postcategories/setdraft/$1";
$route['be/postcategories/settrash/:any'] = "be/postcategories/settrash/$1";
$route['be/postcategories/setrestore/:any'] = "be/postcategories/setrestore/$1";
$route['be/postcategories/setdelete/:any'] = "be/postcategories/setdelete/$1";
$route['be/comments'] = "be/comments";
$route['be/comments/allow'] = "be/comments/allow";
$route['be/comments/trash'] = "be/comments/trash";
$route['be/comments/setallow/:any'] = "be/comments/setallow/$1";
$route['be/comments/settrash/:any'] = "be/comments/settrash/$1";
$route['be/comments/setwaiting/:any'] = "be/comments/setwaiting/$1";
$route['be/comments/setdelete/:any'] = "be/comments/setdelete/$1";
$route['be/products'] = "be/products";
$route['be/products/drafts'] = "be/products/drafts";
$route['be/products/trash'] = "be/products/trash";
$route['be/products/setdraft/:any'] = "be/products/setdraft/$1";
$route['be/products/settrash/:any'] = "be/products/settrash/$1";
$route['be/products/setrestore/:any'] = "be/products/setrestore/$1";
$route['be/products/setdelete/:any'] = "be/products/setdelete/$1";
$route['be/productcategories'] = "be/productcategories";
$route['be/productcategories/drafts'] = "be/productcategories/drafts";
$route['be/productcategories/trash'] = "be/productcategories/trash";
$route['be/productcategories/setdraft/:any'] = "be/productcategories/setdraft/$1";
$route['be/productcategories/settrash/:any'] = "be/productcategories/settrash/$1";
$route['be/productcategories/setrestore/:any'] = "be/productcategories/setrestore/$1";
$route['be/productcategories/setdelete/:any'] = "be/productcategories/setdelete/$1";
$route['be/gallery'] = "be/gallery";
$route['be/gallery/trash'] = "be/gallery/trash";
$route['be/gallery/trashpic/:num'] = "be/gallery/trashpic/$1";
$route['be/gallery/update/:num'] = "be/gallery/update/$1";
$route['be/gallery/update'] = "be/gallery/update";
$route['be/gallery/restorepic/:num'] = "be/gallery/restorepic/$1";
$route['be/gallery/deletepic/:any'] = "be/gallery/deletepic/$1";
$route['be/createpage'] = "be/createpage";
$route['be/createpage/create'] = "be/createpage/create";
$route['be/editpage/edit/:any'] = "be/editpage/edit/$1";
$route['be/editpage/update'] = "be/editpage/update";
$route['be/createpost'] = "be/createpost";
$route['be/editpost/edit/:any'] = "be/editpost/edit/$1";
$route['be/editpost/update'] = "be/editpost/update";
$route['be/createpost/create'] = "be/createpost/create";
$route['be/createpostcat/create'] = "be/createpostcat/create";
$route['be/editpostcat/edit/:any'] = "be/editpostcat/edit/$1";
$route['be/editpostcat/update'] = "be/editpostcat/update";
$route['be/createpostcat'] = "be/createpostcat";
$route['be/createproduct'] = "be/createproduct";
$route['be/editproduct/edit/:any'] = "be/editproduct/edit/$1";
$route['be/editproduct/update'] = "be/editproduct/update";
$route['be/createproduct/create'] = "be/createproduct/create";
$route['be/createproductcat/create'] = "be/createproductcat/create";
$route['be/editproductcat/edit/:any'] = "be/editproductcat/edit/$1";
$route['be/editproductcat/update'] = "be/editproductcat/update";
$route['be/createproductcat'] = "be/createproductcat";
$route['be/messages'] = "be/messages";
$route['be/messages/reply/:any'] = "be/messages/reply/$1";
$route['be/messages/send'] = "be/messages/send";
$route['be/messages/view/:any'] = "be/messages/view/$1";
$route['be/messages/saved'] = "be/messages/saved";
$route['be/messages/trash'] = "be/messages/trash";
$route['be/messages/sent'] = "be/messages/sent";
$route['be/messages/setsaved/:any'] = "be/messages/setsaved/$1";
$route['be/messages/settrash/:any'] = "be/messages/settrash/$1";
$route['be/messages/setrestore/:any'] = "be/messages/setrestore/$1";
$route['be/messages/setdelete/:any'] = "be/messages/setdelete/$1";
$route['be/settings/edit'] = "be/settings/edit";
$route['be/settings/payment'] = "be/settings/payment";
$route['be/settings/saveslideroptions'] = "be/settings/saveslideroptions";
$route['be/settings/slider-options'] = "be/settings/slider";
$route['be/settings'] = "be/settings";
$route['be/users'] = "be/users";
$route['be/users/create'] = "be/users/create";
$route['be/users/trash'] = "be/users/trash";
$route['be/users/edit/:any'] = "be/users/edit/$1";
$route['be/users/update'] = "be/users/update";
$route['be/users/settrash/:any'] = "be/users/settrash/$1";
$route['be/users/setrestore/:any'] = "be/users/setrestore/$1";
$route['be/users/setdelete/:any'] = "be/users/setdelete/$1";
$route['be/invoices/view/:any'] = "be/invoices/view/$1";
$route['be/invoices'] = "be/invoices";
$route['be/invoices/savenotes'] = "be/invoices/savenotes";
$route['be/invoices/drafts'] = "be/invoices/drafts";
$route['be/invoices/trash'] = "be/invoices/trash";
$route['be/invoices/setdraft/:any'] = "be/invoices/setdraft/$1";
$route['be/invoices/settrash/:any'] = "be/invoices/settrash/$1";
$route['be/invoices/setrestore/:any'] = "be/invoices/setrestore/$1";
$route['be/invoices/setdelete/:any'] = "be/invoices/setdelete/$1";
$route['be/invoices/updatenotpaid/:any'] = "be/invoices/updatenotpaid/$1";
$route['be/invoices/updatepaid/:any'] = "be/invoices/updatepaid/$1";
$route['be/invoices/updateprocessing/:any'] = "be/invoices/updateprocessing/$1";
$route['be/invoices/updateonroute/:any'] = "be/invoices/updateonroute/$1";
$route['be/invoices/updatedelivered/:any'] = "be/invoices/updatedelivered/$1";
$route['be/invoices/updatecancelled/:any'] = "be/invoices/updatecancelled/$1";
$route['be/invoices/customeralert/:any'] = "be/invoices/customeralert/$1";
$route['be/stats/all'] = "be/stats/all";
$route['be/stats'] = "be/stats";
$route['be/shipping/settrash/:any'] = "be/shipping/settrash/$1";
$route['be/shipping/setrestore/:any'] = "be/shipping/setrestore/$1";
$route['be/shipping/setdelete/:any'] = "be/shipping/setdelete/$1";
$route['be/shipping/edit/:any'] = "be/shipping/edit/$1";
$route['be/shipping/create'] = "be/shipping/create";
$route['be/shipping/trash'] = "be/shipping/trash";
$route['be/discounts/edit/:any'] = "be/discounts/edit/$1";
$route['be/discounts/create'] = "be/discounts/create";
$route['be/downloads/trash'] = "be/downloads/trash";
$route['be/downloads/settrash/:any'] = "be/downloads/settrash/$1";
$route['be/downloads/setrestore/:any'] = "be/downloads/setrestore/$1";
$route['be/downloads/setdelete/:any'] = "be/downloads/setdelete/$1";
$route['be/downloads'] = "be/downloads";
$route['be/customers/view/:any'] = "be/customers/view/$1";
$route['be/customers/logs/:any/:any'] = "be/customers/logs/$1/$2";
$route['be/customers/trash'] = "be/customers/trash";
$route['be/customers/settrash/:any'] = "be/customers/settrash/$1";
$route['be/customers/setrestore/:any'] = "be/customers/setrestore/$1";
$route['be/customers/setdelete/:any'] = "be/customers/setdelete/$1";
$route['be/customers'] = "be/customers";
$route['be/sessiondata/deletedata'] = "be/sessiondata/deletedata";
$route['be/sessiondata'] = "be/sessiondata";
$route['be/help'] = "be/help";

//front end
$route['shop/category/:any'] = "shop/category/$1";
$route['shop/category'] = "shop/category";
$route['post/category/:any'] = "post/category/$1";
$route['post/category'] = "post/category";
$route['contact/send'] = "contact/send";
$route['contact'] = "contact/index";
$route['paypalreturn'] = "paypalreturn/success";
$route['page/contact'] = "contact/index";
$route['search/result'] = "search/result";
$route['search'] = "search";
$route['recentposts/index/:num'] = "recentposts/index/$1";
$route['recentposts'] = "recentposts/index";
$route['allproducts/index/:num'] = "allproducts/index/$1";
$route['allproducts'] = "allproducts/index";
$route['login'] = "login";
$route['login/check_user'] = "login/check_user";
$route['login/logout'] = "login/logout";
$route['shop/add_item'] = "shop/add_item";
$route['shop/empty_cart'] = "shop/empty_cart";
$route['shop/update_item'] = "shop/update_item";
$route['shop/:any'] = "shop/index";
$route['customer-login'] = "customer/login";
$route['customer/check_user'] = "customer/check_user";
$route['customer/create_user'] = "customer/create_user";
$route['customer/logout'] = "customer/logout";
$route['checkout/edit_details'] = "checkout/edit_details";
$route['checkout/customer_update'] = "checkout/customer_update";
$route['notification'] = "notification/ipn";
$route['checkout'] = "checkout";
$route['account/invoice/:any'] = "account/invoice/$1";
$route['account'] = "account";
$route['download/item/:any'] = "download/item/$1";
$route['cart/estimate_result'] = "cart/estimate_result";
$route['cart/estimate'] = "cart/estimate";
$route['cart'] = "cart";
$route['post/comments'] = "post/comments";
$route['post/:any'] = "post/index";
$route['home'] = "mainpage";
$route['offline'] = "offline";
$route[':any'] = "page/index";