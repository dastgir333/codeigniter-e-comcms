<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sitemap {
    // here define as constants the header and footer for the XML sitemap and sitemap index
    const SITEMAP_HEADER = "<\x3Fxml version=\"1.0\" encoding=\"UTF-8\"\x3F>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"\n\t xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n\t xsi:schemaLocation=\"http://www.sitemaps.org/schemas/sitemap/0.9\n\t\t\t http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd\">";
    const SITEMAP_FOOTER = "</urlset>\n";
    const SITEMAP_INDEX_HEADER = "<\x3Fxml version=\"1.0\" encoding=\"UTF-8\"\x3F>\n <sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">";
    const SITEMAP_INDEX_FOOTER = "</sitemapindex>\n";

    public function generate()
    {
$CI =& get_instance();
 // load in the model that handles all my blog data
$CI->load->model('Settings_model');
$posts = $CI->Settings_model->get_postdata(); // this gets the id, title and date of all my published posts
$post_items = array();
 // step through all the posts and assemble a single item for each with URL location and date
foreach($posts AS $post)
{
$post_items[] = array(
"loc" => site_url("post/" . $post->slug),
"lastmod" => date($post->date),
"priority" => '0.6',
"changefreq" => 'monthly'
);
}

$items = $post_items;

 //begin assembling the sitemap starting with the header

$sitemap = self::SITEMAP_HEADER . "\n";

 // and then each item in the array with additional attributes (date etc) if defined

foreach($items as $item)
{

   $item['loc'] = htmlentities($item['loc'], ENT_QUOTES);
   $sitemap .= "\t<url>\n\t\t<loc>" . $item['loc'] . "</loc>\n";
   if(isset($item["lastmod"]))
{
   $sitemap .= "\t\t<lastmod>" . $item["lastmod"] . "</lastmod>\n";
}
  if(isset($item["priority"]))
{
   $sitemap .= "\t\t<priority>" . $item["priority"] . "</priority>\n";
}
   if(isset($item["changefreq"]))
{
   $sitemap .= "\t\t<changefreq>" . $item["changefreq"] . "</changefreq>\n";
}
    $sitemap .= "\t</url>\n\n";
}

// and finally the footer

$sitemap .= self::SITEMAP_FOOTER;

// now write the sitemap to file

$fh = fopen('sitemap_blog.xml', 'w');
fwrite($fh, $sitemap);
fclose($fh);

// do products 
$CI =& get_instance();
 // load in the model that handles all my blog data
$CI->load->model('Settings_model');
$products = $CI->Settings_model->get_productdata(); // this gets the id, title and date of all my published products
$product_items = array();
 // step through all the products and assemble a single item for each with URL location and date
foreach($products AS $product)
{
$product_items[] = array(
"loc" => site_url("shop/" . $product->slug),
"lastmod" => date($product->date),
"priority" => '0.6',
"changefreq" => 'monthly'
);
}

$items = $product_items;

 //begin assembling the sitemap starting with the header

$sitemap = self::SITEMAP_HEADER . "\n";

 // and then each item in the array with additional attributes (date etc) if defined

foreach($items as $item)
{

   $item['loc'] = htmlentities($item['loc'], ENT_QUOTES);
   $sitemap .= "\t<url>\n\t\t<loc>" . $item['loc'] . "</loc>\n";
   if(isset($item["lastmod"]))
{
   $sitemap .= "\t\t<lastmod>" . $item["lastmod"] . "</lastmod>\n";
}
  if(isset($item["priority"]))
{
   $sitemap .= "\t\t<priority>" . $item["priority"] . "</priority>\n";
}
   if(isset($item["changefreq"]))
{
   $sitemap .= "\t\t<changefreq>" . $item["changefreq"] . "</changefreq>\n";
}
    $sitemap .= "\t</url>\n\n";
}

// and finally the footer

$sitemap .= self::SITEMAP_FOOTER;

// now write the sitemap to file

$fh = fopen('sitemap_products.xml', 'w');
fwrite($fh, $sitemap);
fclose($fh);

 // do pages
 
 $CI =& get_instance();
 // load in the model that handles all my blog data
$CI->load->model('Settings_model');
$pages = $CI->Settings_model->get_pagedata(); // this gets the id, title and date of all my published posts
$pagetags = $CI->Settings_model->get_slugnames(); // while this gets all the tags in use as I have pages accessible by tag name
$page_items = array();
$pagetag_items = array();

 // step through all the pages and assemble a single item for each with URL location and date

foreach($pages AS $page)
{
$page_items[] = array(
"loc" => site_url($page->slug),
"priority" => '1',
"changefreq" => 'monthly'
);
}

$pageitems = $page_items;

 //begin assembling the sitemap starting with the header

$sitemap = self::SITEMAP_HEADER . "\n";

 // and then each item in the array with additional attributes (date etc) if defined

foreach($pageitems as $pageitem)
{

   $pageitem['loc'] = htmlentities($pageitem['loc'], ENT_QUOTES);
   $sitemap .= "\t<url>\n\t\t<loc>" . $pageitem['loc'] . "</loc>\n";
   if(isset($pageitem["priority"]))
{
   $sitemap .= "\t\t<priority>" . $pageitem["priority"] . "</priority>\n";
}
   if(isset($pageitem["changefreq"]))
{
   $sitemap .= "\t\t<changefreq>" . $pageitem["changefreq"] . "</changefreq>\n";
}
    $sitemap .= "\t</url>\n\n";
}

// and finally the footer

$sitemap .= self::SITEMAP_FOOTER;
 
// now write the sitemap to file

$fh = fopen('sitemap_pages.xml', 'w');
fwrite($fh, $sitemap);
fclose($fh);


// now generate the index

$sitemaps = array(
   array("loc" => site_url("sitemap_blog.xml"), "lastmod" => gmdate("c")),
   array("loc" => site_url("sitemap_products.xml"), "lastmod" => gmdate("c")),
   array("loc" => site_url("sitemap_pages.xml")) // this is the pages map that rarely changes
);

// same process as for the sitemap

$index = self::SITEMAP_INDEX_HEADER."\n";

foreach($sitemaps as $sitemap)
{
   $sitemap['loc'] = htmlentities($sitemap['loc'], ENT_QUOTES);
   $index .= "\t<sitemap>\n\t\t<loc>" . $sitemap['loc'] . "</loc>\n";

   if(isset($sitemap['lastmod']))
   {
$index .= "\t\t<lastmod>" . $sitemap['lastmod'] . "</lastmod>\n";
   }
   $index .= "\t</sitemap>\n\n";
}
$index .= self::SITEMAP_INDEX_FOOTER;
$fh = fopen('sitemap.xml', 'w');
fwrite($fh, $index);
fclose($fh);

 // now ping Google via http request, you could add other search engines in here

$sitemap = site_url('sitemap_index.xml');
$url = "http://www.google.com/webmasters/sitemaps/ping?sitemap=".$sitemap;
$ch=curl_init();
curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,2);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt ($ch, CURLOPT_URL, $url);
$response = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

 // really basic success or fail check, returns a status I can use in updating my blog post page

if (substr($http_status, 0, 1) == 2) 
{
   $status= "Google sitemap was successfully updated";
}
else
{
   $status= "Google sitemap submission failed, please try later";
}
return $status;
}

} 
?>