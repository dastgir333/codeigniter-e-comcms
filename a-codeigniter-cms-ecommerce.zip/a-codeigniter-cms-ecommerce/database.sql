-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 30, 2019 at 05:54 PM
-- Server version: 10.2.26-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jcwebdev_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_template`
--

CREATE TABLE `active_template` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `active_template`
--

INSERT INTO `active_template` (`id`, `name`) VALUES
(1, 'vision-highway');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first_name`, `last_name`, `email`, `password`, `status`) VALUES
(5, 'test', 'user', 'test@email.com', 'b9c950640e1b3740e98acb93e669c65766f6670dd1609ba91ff41052ba48c6f3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `capture`
--

CREATE TABLE `capture` (
  `id` int(11) NOT NULL,
  `one` text NOT NULL,
  `two` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `capture`
--

INSERT INTO `capture` (`id`, `one`, `two`) VALUES
(1, 'capture-one.jpg', 'green'),
(2, 'capture-two.jpg', 'banana'),
(3, 'capture-three.jpg', 'business'),
(4, 'capture-four.jpg', 'person'),
(5, 'capture-five.jpg', 'purple'),
(6, 'capture-six.jpg', 'minions');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `user` text NOT NULL,
  `comment` text NOT NULL,
  `post` text NOT NULL,
  `slug` text NOT NULL,
  `moderate` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user`, `comment`, `post`, `slug`, `moderate`) VALUES
(4, 'a user', 'comments are held till approved by a moderator.', 'how to use', 'how-to-use', 2),
(5, 'another user', 'you can approve or delete comments in admin / posts / comments', 'how to use', 'how-to-use', 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `phone` varchar(100) NOT NULL,
  `street_one` text NOT NULL,
  `street_two` text NOT NULL,
  `city` text NOT NULL,
  `county` text NOT NULL,
  `postcode` text NOT NULL,
  `country` text NOT NULL,
  `password` varchar(1000) NOT NULL,
  `email` varchar(200) NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `phone`, `street_one`, `street_two`, `city`, `county`, `postcode`, `country`, `password`, `email`, `status`) VALUES
(1, 'Jamie', 'Cairney', '1234567', 'Spitalfields Arts Market, 112 Brick Lane,', 'Stickney', 'London', 'London', 'E1 6RL', 'United Kingdom', 'b9c950640e1b3740e98acb93e669c65766f6670dd1609ba91ff41052ba48c6f3', 'jamie@jcwebdev.co.uk', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `discountcodes`
--

CREATE TABLE `discountcodes` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `code` text NOT NULL,
  `uses` int(11) NOT NULL,
  `start` text NOT NULL,
  `end` text NOT NULL,
  `discount` text NOT NULL,
  `percent` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discountcodes`
--

INSERT INTO `discountcodes` (`id`, `name`, `code`, `uses`, `start`, `end`, `discount`, `percent`, `status`) VALUES
(1, 'test', 'test1', 1, '03-06-2019', '11-12-2019', '1.98', '0', 0),
(2, 'percent', 'percent', 5, '01-01-2019', '17-07-2019', '0', '25', 0);

-- --------------------------------------------------------

--
-- Table structure for table `discountstemp`
--

CREATE TABLE `discountstemp` (
  `id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `code` text NOT NULL,
  `discount` text NOT NULL,
  `percent` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` int(11) NOT NULL,
  `file` text NOT NULL,
  `trash` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloads`
--

INSERT INTO `downloads` (`id`, `file`, `trash`) VALUES
(6, 'example.zip', 0);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  `url` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `name`, `description`, `status`, `url`) VALUES
(8, 'nopic.png', 'nopic.png', 0, 'nopic.png'),
(16, 'small-logo.png', 'small-logo.png', 0, 'small-logo.png'),
(33, 'cilogo3.png', 'cilogo3.png', 0, 'cilogo3.png');

-- --------------------------------------------------------

--
-- Table structure for table `invoicenumber`
--

CREATE TABLE `invoicenumber` (
  `id` int(11) NOT NULL,
  `number` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoicenumber`
--

INSERT INTO `invoicenumber` (`id`, `number`) VALUES
(1, '100');

-- --------------------------------------------------------

--
-- Table structure for table `invoiceprefix`
--

CREATE TABLE `invoiceprefix` (
  `id` int(11) NOT NULL,
  `prefix` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoiceprefix`
--

INSERT INTO `invoiceprefix` (`id`, `prefix`) VALUES
(1, 'DEMO');

-- --------------------------------------------------------

--
-- Table structure for table `ipn_log`
--

CREATE TABLE `ipn_log` (
  `id` int(11) NOT NULL,
  `listener_name` varchar(3) DEFAULT NULL COMMENT 'Either IPN or API',
  `transaction_type` varchar(16) DEFAULT NULL COMMENT 'The type of call being made to the listener',
  `transaction_id` varchar(19) DEFAULT NULL COMMENT 'The unique transaction ID generated by PayPal',
  `status` varchar(16) DEFAULT NULL COMMENT 'The status of the call',
  `message` varchar(512) DEFAULT NULL COMMENT 'Explanation of the call status',
  `ipn_data_hash` varchar(32) DEFAULT NULL COMMENT 'MD5 hash of the IPN post data',
  `detail` text DEFAULT NULL COMMENT 'Detail text (potentially JSON) on this call',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ipn_orders`
--

CREATE TABLE `ipn_orders` (
  `id` int(11) NOT NULL,
  `notify_version` varchar(64) DEFAULT NULL COMMENT 'IPN Version Number',
  `verify_sign` varchar(127) DEFAULT NULL COMMENT 'Encrypted string used to verify the authenticityof the tansaction',
  `test_ipn` int(11) DEFAULT NULL,
  `protection_eligibility` varchar(24) DEFAULT NULL COMMENT 'Which type of seller protection the buyer is protected by',
  `charset` varchar(127) DEFAULT NULL COMMENT 'Character set used by PayPal',
  `btn_id` varchar(40) DEFAULT NULL COMMENT 'The PayPal buy button clicked',
  `address_city` varchar(40) DEFAULT NULL COMMENT 'City of customers address',
  `address_country` varchar(64) DEFAULT NULL COMMENT 'Country of customers address',
  `address_country_code` varchar(2) DEFAULT NULL COMMENT 'Two character ISO 3166 country code',
  `address_name` varchar(128) DEFAULT NULL COMMENT 'Name used with address (included when customer provides a Gift address)',
  `address_state` varchar(40) DEFAULT NULL COMMENT 'State of customer address',
  `address_status` varchar(20) DEFAULT NULL COMMENT 'confirmed/unconfirmed',
  `address_street` varchar(200) DEFAULT NULL COMMENT 'Customer''s street address',
  `address_zip` varchar(20) DEFAULT NULL COMMENT 'Zip code of customer''s address',
  `first_name` varchar(64) DEFAULT NULL COMMENT 'Customer''s first name',
  `last_name` varchar(64) DEFAULT NULL COMMENT 'Customer''s last name',
  `payer_business_name` varchar(127) DEFAULT NULL COMMENT 'Customer''s company name, if customer represents a business',
  `payer_email` varchar(127) DEFAULT NULL COMMENT 'Customer''s primary email address. Use this email to provide any credits',
  `payer_id` varchar(13) DEFAULT NULL COMMENT 'Unique customer ID.',
  `payer_status` varchar(20) DEFAULT NULL COMMENT 'verified/unverified',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT 'Customer''s telephone number.',
  `residence_country` varchar(2) DEFAULT NULL COMMENT 'Two-Character ISO 3166 country code',
  `business` varchar(127) DEFAULT NULL COMMENT 'Email address or account ID of the payment recipient (that is, the merchant). Equivalent to the values of receiver_email (If payment is sent to primary account) and business set in the Website Payment HTML.',
  `receiver_email` varchar(127) DEFAULT NULL COMMENT 'Primary email address of the payment recipient (that is, the merchant). If the payment is sent to a non-primary email address on your PayPal account, the receiver_email is still your primary email.',
  `receiver_id` varchar(13) DEFAULT NULL COMMENT 'Unique account ID of the payment recipient (i.e., the merchant). This is the same as the recipients referral ID.',
  `custom` varchar(255) DEFAULT NULL COMMENT 'Custom value as passed by you, the merchant. These are pass-through variables that are never presented to your customer.',
  `invoice` varchar(127) DEFAULT NULL COMMENT 'Pass through variable you can use to identify your invoice number for this purchase. If omitted, no variable is passed back.',
  `memo` varchar(255) DEFAULT NULL COMMENT 'Memo as entered by your customer in PayPal Website Payments note field.',
  `tax` decimal(10,2) DEFAULT NULL COMMENT 'Amount of tax charged on payment',
  `auth_id` varchar(19) DEFAULT NULL COMMENT 'Authorization identification number',
  `auth_exp` varchar(28) DEFAULT NULL COMMENT 'Authorization expiration date and time, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `auth_amount` int(11) DEFAULT NULL COMMENT 'Authorization amount',
  `auth_status` varchar(20) DEFAULT NULL COMMENT 'Status of authorization',
  `num_cart_items` int(11) DEFAULT NULL COMMENT 'If this is a PayPal shopping cart transaction, number of items in the cart',
  `parent_txn_id` varchar(19) DEFAULT NULL COMMENT 'In the case of a refund, reversal, or cancelled reversal, this variable contains the txn_id of the original transaction, while txn_id contains a new ID for the new transaction.',
  `payment_date` varchar(28) DEFAULT NULL COMMENT 'Time/date stamp generated by PayPal, in the following format: HH:MM:SS DD Mmm YY, YYYY PST',
  `payment_status` varchar(20) DEFAULT NULL COMMENT 'Payment status of the payment',
  `payment_type` varchar(10) DEFAULT NULL COMMENT 'echeck/instant',
  `pending_reason` varchar(20) DEFAULT NULL COMMENT 'This variable is only set if payment_status=pending',
  `reason_code` varchar(20) DEFAULT NULL COMMENT 'This variable is only set if payment_status=reversed',
  `remaining_settle` int(11) DEFAULT NULL COMMENT 'Remaining amount that can be captured with Authorization and Capture',
  `shipping_method` varchar(64) DEFAULT NULL COMMENT 'The name of a shipping method from the shipping calculations section of the merchants account profile. The buyer selected the named shipping method for this transaction',
  `shipping` decimal(10,2) DEFAULT NULL COMMENT 'Shipping charges associated with this transaction. Format unsigned, no currency symbol, two decimal places',
  `transaction_entity` varchar(20) DEFAULT NULL COMMENT 'Authorization and capture transaction entity',
  `txn_id` varchar(19) DEFAULT NULL COMMENT 'A unique transaction ID generated by PayPal',
  `txn_type` varchar(20) DEFAULT NULL COMMENT 'cart/express_checkout/send-money/virtual-terminal/web-accept',
  `exchange_rate` decimal(10,2) DEFAULT NULL COMMENT 'Exchange rate used if a currency conversion occured',
  `mc_currency` varchar(3) DEFAULT NULL COMMENT 'Three character country code. For payment IPN notifications, this is the currency of the payment, for non-payment subscription IPN notifications, this is the currency of the subscription.',
  `mc_fee` decimal(10,2) DEFAULT NULL COMMENT 'Transaction fee associated with the payment, mc_gross minus mc_fee equals the amount deposited into the receiver_email account. Equivalent to payment_fee for USD payments. If this amount is negative, it signifies a refund or reversal, and either ofthose p',
  `mc_gross` decimal(10,2) DEFAULT NULL COMMENT 'Full amount of the customer''s payment',
  `mc_handling` decimal(10,2) DEFAULT NULL COMMENT 'Total handling charge associated with the transaction',
  `mc_shipping` decimal(10,2) DEFAULT NULL COMMENT 'Total shipping amount associated with the transaction',
  `payment_fee` decimal(10,2) DEFAULT NULL COMMENT 'USD transaction fee associated with the payment',
  `payment_gross` decimal(10,2) DEFAULT NULL COMMENT 'Full USD amount of the customers payment transaction, before payment_fee is subtracted',
  `settle_amount` decimal(10,2) DEFAULT NULL COMMENT 'Amount that is deposited into the account''s primary balance after a currency conversion',
  `settle_currency` varchar(3) DEFAULT NULL COMMENT 'Currency of settle amount. Three digit currency code',
  `auction_buyer_id` varchar(64) DEFAULT NULL COMMENT 'The customer''s auction ID.',
  `auction_closing_date` varchar(28) DEFAULT NULL COMMENT 'The auction''s close date. In the format: HH:MM:SS DD Mmm YY, YYYY PSD',
  `auction_multi_item` int(11) DEFAULT NULL COMMENT 'The number of items purchased in multi-item auction payments',
  `for_auction` varchar(10) DEFAULT NULL COMMENT 'This is an auction payment - payments made using Pay for eBay Items or Smart Logos - as well as send money/money request payments with the type eBay items or Auction Goods(non-eBay)',
  `subscr_date` varchar(28) DEFAULT NULL COMMENT 'Start date or cancellation date depending on whether txn_type is subcr_signup or subscr_cancel',
  `subscr_effective` varchar(28) DEFAULT NULL COMMENT 'Date when a subscription modification becomes effective',
  `period1` varchar(10) DEFAULT NULL COMMENT '(Optional) Trial subscription interval in days, weeks, months, years (example a 4 day interval is 4 D',
  `period2` varchar(10) DEFAULT NULL COMMENT '(Optional) Trial period',
  `period3` varchar(10) DEFAULT NULL COMMENT 'Regular subscription interval in days, weeks, months, years',
  `amount1` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for Trial period 1 for USD',
  `amount2` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for Trial period 2 for USD',
  `amount3` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for regular subscription  period 1 for USD',
  `mc_amount1` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for trial period 1 regardless of currency',
  `mc_amount2` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for trial period 2 regardless of currency',
  `mc_amount3` decimal(10,2) DEFAULT NULL COMMENT 'Amount of payment for regular subscription period regardless of currency',
  `recurring` varchar(1) DEFAULT NULL COMMENT 'Indicates whether rate recurs (1 is yes, blank is no)',
  `reattempt` varchar(1) DEFAULT NULL COMMENT 'Indicates whether reattempts should occur on payment failure (1 is yes, blank is no)',
  `retry_at` varchar(28) DEFAULT NULL COMMENT 'Date PayPal will retry a failed subscription payment',
  `recur_times` int(11) DEFAULT NULL COMMENT 'The number of payment installations that will occur at the regular rate',
  `username` varchar(64) DEFAULT NULL COMMENT '(Optional) Username generated by PayPal and given to subscriber to access the subscription',
  `password` varchar(24) DEFAULT NULL COMMENT '(Optional) Password generated by PayPal and given to subscriber to access the subscription (Encrypted)',
  `subscr_id` varchar(19) DEFAULT NULL COMMENT 'ID generated by PayPal for the subscriber',
  `case_id` varchar(28) DEFAULT NULL COMMENT 'Case identification number',
  `case_type` varchar(28) DEFAULT NULL COMMENT 'complaint/chargeback',
  `case_creation_date` varchar(28) DEFAULT NULL COMMENT 'Date/Time the case was registered',
  `order_status` enum('PAID','WAITING','REJECTED') DEFAULT NULL COMMENT 'Additional variable to make payment_status more actionable',
  `discount` decimal(10,2) DEFAULT NULL COMMENT 'Additional variable to record the discount made on the order',
  `shipping_discount` decimal(10,2) DEFAULT NULL COMMENT 'Record the discount made on the shipping',
  `ipn_track_id` varchar(127) DEFAULT NULL COMMENT 'Internal tracking variable added in April 2011',
  `transaction_subject` varchar(255) DEFAULT NULL COMMENT 'Describes the product for a button-based purchase',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ipn_order_items`
--

CREATE TABLE `ipn_order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `item_name` varchar(127) DEFAULT NULL COMMENT 'Item name as passed by you, the merchant. Or, if not passed by you, as entered by your customer. If this is a shopping cart transaction, Paypal will append the number of the item (e.g., item_name_1,item_name_2, and so forth).',
  `item_number` varchar(127) DEFAULT NULL COMMENT 'Pass-through variable for you to track purchases. It will get passed back to you at the completion of the payment. If omitted, no variable will be passed back to you.',
  `quantity` varchar(127) DEFAULT NULL COMMENT 'Quantity as entered by your customer or as passed by you, the merchant. If this is a shopping cart transaction, PayPal appends the number of the item (e.g., quantity1,quantity2).',
  `mc_gross` decimal(10,2) DEFAULT NULL COMMENT 'Full amount of the customer''s payment',
  `mc_handling` decimal(10,2) DEFAULT NULL COMMENT 'Total handling charge associated with the transaction',
  `mc_shipping` decimal(10,2) DEFAULT NULL COMMENT 'Total shipping amount associated with the transaction',
  `tax` decimal(10,2) DEFAULT NULL COMMENT 'Amount of tax charged on payment',
  `cost_per_item` decimal(10,2) DEFAULT NULL COMMENT 'Cost of an individual item',
  `option_name_1` varchar(64) DEFAULT NULL COMMENT 'Option 1 name as requested by you',
  `option_selection_1` varchar(200) DEFAULT NULL COMMENT 'Option 1 choice as entered by your customer',
  `option_name_2` varchar(64) DEFAULT NULL COMMENT 'Option 2 name as requested by you',
  `option_selection_2` varchar(200) DEFAULT NULL COMMENT 'Option 2 choice as entered by your customer',
  `option_name_3` varchar(64) DEFAULT NULL COMMENT 'Option 3 name as requested by you',
  `option_selection_3` varchar(200) DEFAULT NULL COMMENT 'Option 3 choice as entered by your customer',
  `option_name_4` varchar(64) DEFAULT NULL COMMENT 'Option 4 name as requested by you',
  `option_selection_4` varchar(200) DEFAULT NULL COMMENT 'Option 4 choice as entered by your customer',
  `option_name_5` varchar(64) DEFAULT NULL COMMENT 'Option 5 name as requested by you',
  `option_selection_5` varchar(200) DEFAULT NULL COMMENT 'Option 5 choice as entered by your customer',
  `option_name_6` varchar(64) DEFAULT NULL COMMENT 'Option 6 name as requested by you',
  `option_selection_6` varchar(200) DEFAULT NULL COMMENT 'Option 6 choice as entered by your customer',
  `option_name_7` varchar(64) DEFAULT NULL COMMENT 'Option 7 name as requested by you',
  `option_selection_7` varchar(200) DEFAULT NULL COMMENT 'Option 7 choice as entered by your customer',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`id`, `image`) VALUES
(1, 'cilogo3.png');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `status`) VALUES
(1, 'pagemenu', 1),
(2, 'postmenu', 0),
(3, 'productmenu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `message` varchar(2000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL,
  `originaldate` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`id`, `email`, `message`, `date`, `status`, `originaldate`) VALUES
(13, 'test@email.com', 'a test message', '2019-07-16 18:22:55', 0, 'July 16, 2019, 7:22 pm');

-- --------------------------------------------------------

--
-- Table structure for table `orderedproducts`
--

CREATE TABLE `orderedproducts` (
  `id` int(11) NOT NULL,
  `quantity` text NOT NULL,
  `options` text DEFAULT NULL,
  `price` text NOT NULL,
  `invoice` text NOT NULL,
  `weight` text NOT NULL,
  `productid` text NOT NULL,
  `product` text NOT NULL,
  `download` text NOT NULL,
  `customerid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderedproducts`
--

INSERT INTO `orderedproducts` (`id`, `quantity`, `options`, `price`, `invoice`, `weight`, `productid`, `product`, `download`, `customerid`) VALUES
(156, '1', NULL, '12.99', 'JCTX-935', '', '14', '19 inch toolbox', 'none', 1),
(157, '1', NULL, '11.99', 'JCTX-936', '', '19', 'A download example', 'example.zip', 1),
(158, '1', 'example extra,1.00', '11.99', 'JCTX-936', '', '20', 'another example', 'none', 1),
(159, '2', 'example standard,0.00', '11.99', 'JCTX-936', '', '20', 'another example', 'none', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `invoice` text NOT NULL,
  `quantity` text NOT NULL,
  `cost` text NOT NULL,
  `customer` text NOT NULL,
  `deliveryaddress` longtext NOT NULL,
  `paid` text NOT NULL,
  `email` text NOT NULL,
  `customerid` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `originaldate` text NOT NULL,
  `status` text NOT NULL,
  `adminnotes` longtext NOT NULL,
  `comments` longtext NOT NULL,
  `shippingcost` text NOT NULL,
  `totalextracost` text NOT NULL,
  `qtydiscount` text NOT NULL,
  `trash` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `invoice`, `quantity`, `cost`, `customer`, `deliveryaddress`, `paid`, `email`, `customerid`, `date`, `originaldate`, `status`, `adminnotes`, `comments`, `shippingcost`, `totalextracost`, `qtydiscount`, `trash`) VALUES
(170, 'JCTX-936', '4', '48.96', 'Jamie Cairney', 'Spitalfields Arts Market, 112 Brick Lane,<br>Stickney<br>London<br>London<br>E1 6RL<br>United Kingdom<br>', '1', 'jamie@jcwebdev.co.uk', '1', '2019-08-30 16:12:00', 'August 30, 2019, 4:17 pm', 'processing', '<p>this is a test order with a test delivery address.</p><p>these details are for testing only.<br></p>', 'a test order', '3.5', '1', 'no code', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `description` text NOT NULL,
  `trash` int(11) NOT NULL,
  `name` text NOT NULL,
  `keywords` text NOT NULL,
  `slug` text NOT NULL,
  `videolink` varchar(100) NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `content`, `description`, `trash`, `name`, `keywords`, `slug`, `videolink`, `sort`) VALUES
(1, 'home', 'some page content here', 'a home page test', 0, 'home', 'home', 'home', '', 0),
(2, 'contact us', 'the contact page content can be edited in admin / pages<br>', 'contact description', 0, 'contact us', 'contact', 'contact', '', 1),
(3, 'about us', '<p>an about us page</p><p>pages can be created, edited and deleted in admin.</p><p>More information is available in admin / help<br></p>', 'about us description', 0, 'about us', 'about', 'about-us', '', 1),
(5, 'terms', '<p>terms and conditions</p><p><p>pages can be created, edited and deleted in admin.</p>More information in available in admin / help</p>', 'terms description', 0, 'terms', 'terms, ts and cs', 'terms', '', 1),
(18, 'search', 'search', 'search', 0, 'search', 'search', 'search', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `postcategory`
--

CREATE TABLE `postcategory` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `tags` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trash` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `slug` text NOT NULL,
  `sub` text NOT NULL,
  `videolink` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postcategory`
--

INSERT INTO `postcategory` (`id`, `name`, `content`, `title`, `description`, `keywords`, `tags`, `date`, `trash`, `sort`, `slug`, `sub`, `videolink`) VALUES
(1, 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', '2018-06-18 11:43:07', 0, 0, 'uncategorised', 'none', ''),
(12, 'example sub category', 'example sub category', 'example sub category', 'example sub category', 'example sub category', '', '2019-08-30 14:49:49', 0, 0, 'example-sub-category', 'example category', ''),
(11, 'example category', 'example category', 'example category', 'example category', 'example category', '', '2019-08-30 14:49:18', 0, 0, 'example-category', 'none', '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `description` text NOT NULL,
  `trash` int(11) NOT NULL,
  `name` text NOT NULL,
  `keywords` text NOT NULL,
  `slug` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `originaldate` text NOT NULL,
  `catlist` text NOT NULL,
  `category` text NOT NULL,
  `category2` text NOT NULL,
  `category3` text NOT NULL,
  `videolink` varchar(200) NOT NULL,
  `comments` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `description`, `trash`, `name`, `keywords`, `slug`, `date`, `originaldate`, `catlist`, `category`, `category2`, `category3`, `videolink`, `comments`) VALUES
(18, 'how to use', '<a class=\"image-popup-no-margins\" href=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\"><img src=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\" width=\"150px\"></a>How to use A CodeIgniter CMS ecommerce edition<br><p><br></p><p>Just sign in to the admin panel and add your products and post some content.</p><p>The main page slider will use the last three posts to display or three products or three custom images, links and text, this can be set in admin / settings. </p><p>The three main page small boxes will show, on the top the most recent post and the bottom two boxes will each display one random product each.</p><p>Just add content and the rest will be taken care of for you.</p><p>You also have the ability to switch on and off menus in your site\'s header.</p><p>More info is available in admin / help<br></p><p>Sign in to your admin panel, click settings, add in your own email address , set your payment settings and time zone settings, add content to your pages, products and posts and your set up is done!</p><p>Easy <img src=\"https://www.jcwebdev.co.uk/zzzz/images/smileys/wink.gif\" alt=\"wink\" style=\"width: 19; height: 19; border: 0;\"> </p>', 'How to use A CodeIgniter CMS ecommerce edition, click here for more info', 0, 'how to use', 'How to use A CodeIgniter CMS ecommerce edition', 'how-to-use', '2019-08-30 14:51:49', 'August 30, 2019, 3:48 pm', 'uncategorised,example-category,example-sub-category,', 'uncategorised', 'example-category', 'example-sub-category', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `productcategory`
--

CREATE TABLE `productcategory` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `keywords` text NOT NULL,
  `tags` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trash` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `slug` text NOT NULL,
  `sub` text NOT NULL,
  `videolink` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productcategory`
--

INSERT INTO `productcategory` (`id`, `name`, `content`, `title`, `description`, `keywords`, `tags`, `date`, `trash`, `sort`, `slug`, `sub`, `videolink`) VALUES
(1, 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', 'uncategorised', '2019-07-16 21:50:15', 0, 0, 'uncategorised', 'none', ''),
(13, 'example sub category', 'example sub category', 'example sub category', 'example sub category', 'example sub category', '', '2019-08-30 14:09:27', 0, 0, 'example-sub-category', 'example category', ''),
(11, 'downloads', 'downloads', 'downloads', 'downloads', 'downloads', '', '2019-08-17 14:16:12', 0, 9, 'downloads', 'none', ''),
(12, 'example category', 'example category', 'example category', 'example category', 'example category', '', '2019-08-30 14:08:46', 0, 0, 'example-category', 'none', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` longtext NOT NULL,
  `description` text NOT NULL,
  `trash` int(11) NOT NULL,
  `name` text NOT NULL,
  `keywords` text NOT NULL,
  `slug` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `catlist` text NOT NULL,
  `category` text NOT NULL,
  `category2` text NOT NULL,
  `category3` text NOT NULL,
  `price` varchar(11) NOT NULL,
  `weight` varchar(11) NOT NULL,
  `stock` text NOT NULL,
  `videolink` varchar(100) NOT NULL,
  `download` text NOT NULL,
  `shippingname` text NOT NULL,
  `options` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `content`, `description`, `trash`, `name`, `keywords`, `slug`, `date`, `catlist`, `category`, `category2`, `category3`, `price`, `weight`, `stock`, `videolink`, `download`, `shippingname`, `options`) VALUES
(19, 'A download example', '<a class=\"image-popup-no-margins\" href=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/small-logo.png\"><img src=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/small-logo.png\" width=\"150px\"></a><br><p>A download example.</p><p></p><p>For information on how to set the site currency, create and edit products and product categories and subcategories and downloadable products and product options and shipping rules and everything else, log in to the admin panel and click the help button in the header menu.<br></p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p></p>', 'An example downloadable product description.', 0, 'A download example', 'download', 'a-download-example', '2019-08-30 15:14:21', 'downloads,', 'downloads', '', '', '11.99', '0', 'no limit', '', 'example.zip', 'basic', ''),
(20, 'another example', '<a class=\"image-popup-no-margins\" href=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\"><img src=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\" width=\"150px\"></a><br>Another example product.<p>For information on how to set the site currency, create and edit products and product categories and subcategories and downloadable products and product options and shipping rules and everything else, log in to the admin panel and click the help button in the header menu.<br></p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'An example product with options, description.', 0, 'another example', 'An example product, example', 'another-example', '2019-08-30 15:14:07', 'example-sub-category,uncategorised,', 'example-sub-category', 'uncategorised', '', '11.99', '1000', 'no limit', '', 'none', 'basic', 'example standard,0.00;example extra,1.00;'),
(18, 'an example product', '<p><a class=\"image-popup-no-margins\" href=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\"><img src=\"https://www.jcwebdev.co.uk/demo-store/images/gallery/cilogo3.png\" width=\"150px\"></a><br><br>An example product.</p><p>For information on how to set the site currency, create and edit products and product categories and subcategories and downloadable products and product options and shipping rules and everything else, log in to the admin panel and click the help button in the header menu.<br></p><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><br>', 'This is an example of a product description.', 0, 'an example product', 'An example product, example', 'an-example-product', '2019-08-30 15:13:40', 'uncategorised,example-sub-category,', 'uncategorised', 'example-sub-category', '', '11.99', '1000', 'no limit', '', 'none', 'basic', '');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `title` text NOT NULL,
  `tagline` text NOT NULL,
  `status` int(11) NOT NULL,
  `timezone` varchar(200) NOT NULL,
  `currency` text NOT NULL,
  `currencysign` text NOT NULL,
  `paymentemail` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `email`, `title`, `tagline`, `status`, `timezone`, `currency`, `currencysign`, `paymentemail`) VALUES
(1, 'test@email.com', 'A CodeIgniter CMS', 'ecommerce edition', 1, 'Europe/London', 'GBP', '£', 'test@email.com');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `country` text NOT NULL,
  `zones` text NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`id`, `name`, `country`, `zones`, `active`) VALUES
(1, 'basic', 'United Kingdom', '3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shippingzones`
--

CREATE TABLE `shippingzones` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `zone` text NOT NULL,
  `postcodes` text NOT NULL,
  `cost` text NOT NULL,
  `country` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shippingzones`
--

INSERT INTO `shippingzones` (`id`, `name`, `zone`, `postcodes`, `cost`, `country`, `status`) VALUES
(1, 'basic', '1', 'all others', '0,1,0.00;2,1000,1.50;1001,2000,2.00;2001,3000,2.50;3001,4000,3.00;4001,5000,3.50;5001,20000,5.50', 'United Kingdom', 0),
(2, 'basic', '2', 'IV,HS,KA27,KA28,KW,PA20,PA21,PA22,PA23,PA24,PA25,PA26,PA27,PA28,PA29,PA30,PA31,PA32,PA33,PA34,PA35,PA36,PA37,PA38,PA39,PA40,PA41,PA42,PA43,PA44,PA45,PA46,PA47,PA48,PA49,PA60,PA61,PA62,PA63,PA64,PA65,PA66,PA67,PA68,PA69,PA70,PA71,PA72,PA73,PA74,PA75,PA76,PA77,PA78,PH17,PH18,PH19,PH20,PH21,PH22,PH23,PH24,PH25,PH26,PH30,PH31,PH32,PH33,PH34,PH35,PH36,PH37,PH38,PH39,PH40,PH41,PH42,PH43,PH44,ZE', '0,1,0.00;2,1000,2.50;1001,2000,3.00;2001,3000,3.50;3001,4000,4.00;4001,5000,4.50;5001,20000,6.50', 'United Kingdom', 0),
(3, 'basic', '3', 'BT,IM,TR21,TR22,TR23,TR24,TR25', '0,1,0.00;2,1000,3.50;1001,2000,4.00;2001,3000,4.50;3001,4000,5.00;4001,5000,5.50;5001,20000,7.50', 'United Kingdom', 0),
(12, 'test', '1', 'all others', '0,1,0.00;1,1000,1.50;1001,2000,2.50;2001,3000,3.50;3001,4000,4.50;4001,200000,7.50;', 'United Kingdom', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sitemap`
--

CREATE TABLE `sitemap` (
  `id` int(11) NOT NULL,
  `updated` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sitemap`
--

INSERT INTO `sitemap` (`id`, `updated`) VALUES
(1, 'not updated yet');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `content` text NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `slug` text NOT NULL,
  `type` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `content`, `title`, `description`, `slug`, `type`) VALUES
(1, '<img src=\"https://www.jcwebdev.co.uk/themes/images/gallery/pexels-lighbulb.jpeg\" />', 'image one', 'some text here', 'https://www.jcwebdev.co.uk/', 'custom'),
(2, '<img src=\"https://www.jcwebdev.co.uk/themes/images/gallery/pexels-lighbulb.jpeg\" />', 'image two', 'more text here', 'https://www.jcwebdev.co.uk/', 'custom'),
(3, '<img src=\"https://www.jcwebdev.co.uk/themes/images/gallery/pexels-lighbulb.jpeg\" />', 'image three', 'even more text here', 'https://www.jcwebdev.co.uk/', 'custom');

-- --------------------------------------------------------

--
-- Table structure for table `slideroption`
--

CREATE TABLE `slideroption` (
  `id` int(11) NOT NULL,
  `slideroption` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slideroption`
--

INSERT INTO `slideroption` (`id`, `slideroption`) VALUES
(1, 'products');

-- --------------------------------------------------------

--
-- Table structure for table `statslog`
--

CREATE TABLE `statslog` (
  `id` int(11) NOT NULL,
  `customerid` text DEFAULT NULL,
  `email` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `action` text NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `user_agent` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_template`
--
ALTER TABLE `active_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `capture`
--
ALTER TABLE `capture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discountcodes`
--
ALTER TABLE `discountcodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discountstemp`
--
ALTER TABLE `discountstemp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoicenumber`
--
ALTER TABLE `invoicenumber`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoiceprefix`
--
ALTER TABLE `invoiceprefix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ipn_log`
--
ALTER TABLE `ipn_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ipn_orders`
--
ALTER TABLE `ipn_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UniqueTransactionID` (`txn_id`);

--
-- Indexes for table `ipn_order_items`
--
ALTER TABLE `ipn_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderedproducts`
--
ALTER TABLE `orderedproducts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `postcategory`
--
ALTER TABLE `postcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productcategory`
--
ALTER TABLE `productcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shippingzones`
--
ALTER TABLE `shippingzones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sitemap`
--
ALTER TABLE `sitemap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideroption`
--
ALTER TABLE `slideroption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `statslog`
--
ALTER TABLE `statslog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_template`
--
ALTER TABLE `active_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `capture`
--
ALTER TABLE `capture`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `discountcodes`
--
ALTER TABLE `discountcodes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `discountstemp`
--
ALTER TABLE `discountstemp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `invoicenumber`
--
ALTER TABLE `invoicenumber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `invoiceprefix`
--
ALTER TABLE `invoiceprefix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ipn_log`
--
ALTER TABLE `ipn_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=267;

--
-- AUTO_INCREMENT for table `ipn_orders`
--
ALTER TABLE `ipn_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=199;

--
-- AUTO_INCREMENT for table `ipn_order_items`
--
ALTER TABLE `ipn_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orderedproducts`
--
ALTER TABLE `orderedproducts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `postcategory`
--
ALTER TABLE `postcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `productcategory`
--
ALTER TABLE `productcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `shippingzones`
--
ALTER TABLE `shippingzones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sitemap`
--
ALTER TABLE `sitemap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `slideroption`
--
ALTER TABLE `slideroption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `statslog`
--
ALTER TABLE `statslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2407;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
